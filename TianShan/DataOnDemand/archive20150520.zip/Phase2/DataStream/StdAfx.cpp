// stdafx.cpp : source file that includes just the standard includes
//	DataStream.pch will be the pre-compiled header
//	stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"

#pragma comment(lib, "ws2_32.lib")
#pragma comment(lib, "winmm.lib")

// TODO: reference any additional headers you need in STDAFX.H
// and not in this file
