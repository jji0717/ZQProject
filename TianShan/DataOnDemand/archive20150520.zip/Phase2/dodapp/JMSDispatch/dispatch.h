#include "jms.h"
#include "queuemanagement.h"
#include "receivejmsmsg.h"
#include <Ice/Ice.h>
#include <DODapp.h>
#include "Locks.h"
typedef struct 
{
	std::string ChannelName;
	std::string		Tag;
	::DataOnDemand::ChannelType     nDataExchangeType;	
	int		nstreamId;			/// PID
	::DataOnDemand::EncryptMode    nEncrypted;
	std::string  strSendMsgDataType;
	int     nSendMsgExpiredTime;
	int	    nChannelType;	/// default 1
	int     nStreamCount;
	std::string  strdataType;
	int		streamType;
	int     nSendWithDestination;
	int     nMessageCode;
	std::string  strQueueName;
	std::string  strCacheDir;
}CHANNELINFO;
typedef ::std::map<std::string , CHANNELINFO*> CHANNELMAP;

typedef struct  
{
   std::string ChannelName;
   int     nRepeatetime;
   int     nChannelRate; 
   ::DataOnDemand::ChannelType     nDataExchangeType;
}CHANNELATTACHINFO;
typedef ::std::map<std::string, CHANNELATTACHINFO*>CHANNELATTACHINFOMAP;

typedef struct 
{
	std::string IpPortName;
	int nSendType;
	std::string strIp;
	int nPort;
}IPPORT;

typedef std::vector<IPPORT*>IPPORTVECTOR;
typedef struct
{
	std::string  portdir;
	std::string  portname;
	std::string  DestinationName;
	int		pmtPid;			/// ����� TS �е� PMT pid
	int		totalBandWidth;	/// destination �� bandwidth in bps
	std::string	destAddress;	/// Ŀ���ַ, in the format of "<IP>:<port>[; <IP>:<port>]"
	int		groupId;	/// ��id
	CHANNELATTACHINFOMAP channelattachMap;
	IPPORTVECTOR  ipportvector;
}DODPORT;
typedef std::vector<DODPORT *> CPORTVECTOR;

typedef struct
{
	std::string  IpPortName;
	int		pmtPid;			/// ����� TS �е� PMT pid
	int		totalBandWidth;	/// destination �� bandwidth in bps
	std::string	destAddress;	/// Ŀ���ַ, in the format of "<IP>:<port>[; <IP>:<port>]"
	int		groupId;	/// ��id
	CHANNELATTACHINFOMAP channelattachMap;
}DODFAILPORT;
typedef std::vector<DODFAILPORT> CFAILPORTVECTOR;


typedef struct ZQMsgParser
{
   CString QueueName;
   CReceiveJmsMsg *MsgReceive;
}ZQMSGPARSER, *PZQMSGPARSER;
class  CJMSPortManager {
public:
	
	CJMSPortManager();
	~CJMSPortManager();

	BOOL Initialize();
	BOOL UnInitialize();
  	BOOL ConnectionJBoss(void);
	BOOL Create(std::string strJBossIPPort, std::string ConfigQueueName,
		int ConfigMsgTimeOut,std::string strCacheDir,int nUsingJBoss);
    void stop();
private:
	int m_nUsingJBoss;
	BOOL SetMessage();
	BOOL AddChannelQueue();
	BOOL CheckSyn();
	BOOL CreateChannels();
	BOOL CreatePorts();
	BOOL AttachChannel();
	BOOL DirectoryExist(LPCTSTR lpszpathame);
	BOOL ParserChannelType(::TianShanIce::IValues *dataTypes, std::string strDataType);
	int ConvertTag(std::string strTag); 
	
	BOOL ConventChannelName();
	BOOL ConvertPortName();
	::TianShanIce::StrValues  listPortChannels(DODPORT * pPort);
	BOOL RetryCreatPort();
	BOOL CreateFailPort(DODFAILPORT* pfailport);

public:	
	CJMS   *m_jms;
	CString m_sDataTypeInitial;
	CString m_ProviderValue;
	std::string  m_strConfigQueueName;
	int m_nConfigTimeOut;
	BOOL m_bReSetMsgListener;

    CHANNELMAP m_channels;
    CPORTVECTOR	m_portManager;
	CFAILPORTVECTOR m_FailPort;
	std::vector<ZQMSGPARSER> m_VecParser;
	
private:
    std::string m_strCacheDir;
	CQueueManageMent m_QueueManagement;
	CReceiveJmsMsg * m_ParsePortConfig;
	CJmsProcThread *m_Pjmsprocthread;
	ZQ::common::Mutex _mutex;
};
