#pragma once 

// resource for creating stream
#define RESKEY_SPACENAME		"SpaceName"
#define RESKEY_STREAMNAME		"streamName"
#define RESKEY_DESTADDRESS		"destAddress"
#define RESKEY_GROUPID			"groupId"
#define RESKEY_PMTPID			"pmtPid"
#define RESKEY_TOTALBANDWIDTH	"totalBandWidth"
