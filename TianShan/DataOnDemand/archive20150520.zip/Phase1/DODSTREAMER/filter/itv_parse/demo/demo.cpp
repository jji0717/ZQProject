// demo.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

int Test_Parser();

int main(int argc, _TCHAR* argv[])
{
	Test_Parser();
	return 0;
}

