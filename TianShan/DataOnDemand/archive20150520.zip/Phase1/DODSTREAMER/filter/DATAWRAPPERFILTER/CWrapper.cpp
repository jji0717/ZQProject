
#include "stdafx.h"
#include "CWrapper.h"

CWrapper::CWrapper()
{

}

CWrapper::~CWrapper()
{

}
