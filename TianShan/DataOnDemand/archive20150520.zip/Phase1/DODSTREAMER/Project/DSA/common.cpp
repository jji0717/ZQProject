
//#include "stdafx.h"
#include "common.h"

TCHAR g_szRichText[256];
TCHAR g_szErrorText[256];
TCHAR g_szControllerStatusText[256];
