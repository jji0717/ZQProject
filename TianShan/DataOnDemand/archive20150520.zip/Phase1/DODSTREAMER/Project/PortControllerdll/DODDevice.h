pragma once

class CDODDevice
{
public:
	CDODDevice(void);
	~CDODDevice(void);
};
