#include "StdAfx.h"
#include ".\dodcard.h"

CDODCard::CDODCard(void)
{
}

CDODCard::~CDODCard(void)
{
}
