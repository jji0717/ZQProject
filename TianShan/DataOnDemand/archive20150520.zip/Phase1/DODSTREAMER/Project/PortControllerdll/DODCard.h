#pragma once

class CDODCard
{
public:
	CDODCard(void);
	~CDODCard(void);
};
