#pragma once

class CDODSubChannel
{
public:
	CDODSubChannel(void);
	~CDODSubChannel(void);
};
