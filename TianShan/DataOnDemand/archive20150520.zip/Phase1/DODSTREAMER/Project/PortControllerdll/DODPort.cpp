#include "StdAfx.h"
#include ".\dodport.h"

CDODPort::CDODPort(void)
{
}

CDODPort::~CDODPort(void)
{
}
