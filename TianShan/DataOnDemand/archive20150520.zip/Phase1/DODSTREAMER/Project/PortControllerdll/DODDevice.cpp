#include "StdAfx.h"
#include ".\doddevice.h"

CDODDevice::CDODDevice(void)
{
}

CDODDevice::~CDODDevice(void)
{
}
