#pragma once

class CDODPort
{
public:
	CDODPort(void);
	~CDODPort(void);
};
