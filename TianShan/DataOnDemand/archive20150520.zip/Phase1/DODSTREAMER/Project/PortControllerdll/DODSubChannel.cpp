#include "StdAfx.h"
#include ".\dodsubchannel.h"

CDODSubChannel::CDODSubChannel(void)
{
}

CDODSubChannel::~CDODSubChannel(void)
{
}
