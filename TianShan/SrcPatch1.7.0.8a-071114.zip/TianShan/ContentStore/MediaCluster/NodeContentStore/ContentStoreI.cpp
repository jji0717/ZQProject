#include "MCNodeStoreServ.h"
#include "TimeUtil.h"
#include "TianShanDefines.h"
#include "ContentProcessing.h"
#include "ProvisionEventSink.h"
#include "PropertyKeyDef.h"
#include <sstream>
#include <shlwapi.h>
#include <Ice/IdentityUtil.h>


#ifndef MCCS 
#include "vstrmuser.h"
#include "VstrmProc.h"
#include "StatusUpdater.h"
#include "VV2Parser.h"
#endif


extern MCNodeStoreServ server;
extern ContentStoreConfig config;


namespace {
	const std::string ContentCategory = "content";

	const short ACTIVE		= 0x0001;
	const short PASSIVE		= 0x0002;
	const short INGEST_CARD = 0x0004;
}


__BEGIN_TIANSHAN_STORAGE


ContentFactory::ContentFactory(){
}

Ice::ObjectPtr ContentFactory::create(const std::string& type){
	if(type == ContentI::ice_staticId()){
		return new ContentI(server.getStore());
	}
	else if(type == StatusMsgI::ice_staticId()) {
		return new StatusMsgI();
	}
	else{
		ZQTianShan::_IceThrow<TianShanIce::InvalidStateOfArt>(
			glog, 
			"ContentStoreI", 
			csexpCodeInvalidParam, 
			"invalid object type (%s)", type.c_str()
		);
	}

	/* dummy code, never reach here. */
	throw;
}




ContentI::ContentI(const ContentStoreIPtr& store):
_store(store) {
	_storage = ContentStorage::getStorage();
}


ContentStorePrx ContentI::getStore(const Ice::Current& current){
	return ContentStorePrx::checkedCast(
			server.adapter()->createProxy(Ice::stringToIdentity("ContentStore")));
}

std::string ContentI::getName(const Ice::Current& current) const{
	return name;
}

bool ContentI::isProvisioned(const Ice::Current& current) const {
	bool available = _storage->getAttrs(name, _attrs);

	return (available && _attrs.status == ContentDictData::stPROVISIONED);
}

std::string ContentI::getProvisionTime(const Ice::Current&) const {
	bool available = _storage->getAttrs(name, _attrs);

	if(!available) {
		return "";
	}

	char provTime[256] = {0};
	
	time_t stamp = static_cast<long>(_attrs.stampProvision);
	
	if(config.useUTC) {
		ZQ::common::TimeUtil::Time2Iso(stamp, provTime, 255);
	}
	else {
		ZQ::common::TimeUtil::Time2Str(stamp, provTime, 255);
	}
	
	return provTime;
}

std::string ContentI::getLocaltype(const Ice::Current& current) const{
	bool available = _storage->getAttrs(name, _attrs);

	return available ? _attrs.localType : "";
}

std::string ContentI::getSubtype(const Ice::Current& current) const {
	bool available = _storage->getAttrs(name, _attrs);

	return available ? _attrs.subType : "";
}

Ice::Float ContentI::getFramerate(const Ice::Current& current) const {
	bool available = _storage->getAttrs(name, _attrs);

	return available ? _attrs.fps : 0;
}

void ContentI::getResolution(Ice::Int& pixelHorizontal, Ice::Int& pixelVertical, const Ice::Current&) const {
	bool available = _storage->getAttrs(name, _attrs);

	pixelHorizontal = available ? _attrs.resolutionH : 0;
	pixelVertical   = available ? _attrs.resolutionV : 0;
}

Ice::Long ContentI::getFilesize(const Ice::Current&) const {
	bool available = _storage->getAttrs(name, _attrs);
    
	return available ? _attrs.fileSize : 0;
}

Ice::Long ContentI::getPlayTime(const Ice::Current&) const {
	bool available = _storage->getAttrs(name, _attrs);

	return available ? 
		   (_attrs.playtime / 1000) + ((_attrs.playtime % 1000 > 500) ? 1 : 0) : 0;
}

Ice::Long ContentI::getPlayTimeEx(const Ice::Current&) const {
	bool available = _storage->getAttrs(name, _attrs);

	return available ? _attrs.playtime : 0;
}


Ice::Int ContentI::getBitRate(const Ice::Current&) const {
	bool available = _storage->getAttrs(name, _attrs);

	return available ? _attrs.bitrate : 0;
}

std::string ContentI::getExportURL(
				const std::string& targetContentType, 
				const std::string& protocol, 
				TianShanIce::Properties& prop, 
				const Ice::Current&) const {
				
	if(server.serverType() == server.MediaCluster){
		MediaClusterContentStorePrx slaveNode = server.selectSlaveNode();

		if(!slaveNode) {
			glog(ZQ::common::Log::L_ERROR, "failed to get export url for (%s): (no slave nodes available)", name.c_str());
			return "";
		}
		
		ContentPrx mcContent = slaveNode->openContent(name, getLocaltype(), false);
		
		return mcContent->getExportURL(targetContentType, protocol, prop);
	}

	
	/* invalidate the protocol. */
	if(protocol != TianShanIce::Storage::potoFTP){
		ZQTianShan::_IceThrow<InvalidParameter>(
			csexpCategory.c_str(),
			csexpCodeUnsupportProto, 
			"Protocol not supported."
		);
	}
	
	if(!_store->isContentInDisk(name)){
		ZQTianShan::_IceThrow<InvalidStateOfArt>(
			csexpCategory.c_str(), 
			csexpCodeContentNotFound, 
			"Content not ready."
		);
	}

	std::string url;
	
#ifndef MCCS 
	using namespace TianShanIce::Storage;

	std::string user, pass, session;

	_store->_contentExport.CreateSession(
			name.c_str(), config.exportTTL, config.exportBitrate, url, user, pass, session);

	bool available = _storage->getAttrs(name, _attrs);
	
	if(available) {
		prop[expFileCount] = _attrs.extAttrs[CNTPRY_FILE_COUNT];
		
		int count = atoi(_attrs.extAttrs[CNTPRY_FILE_COUNT].c_str());
		
		std::ostringstream os;		
		for(short i = 1; i <= count; ++i) {
			os << CNTPRY_FILE_NAME << i;
			prop[os.str()] = _attrs.extAttrs[os.str()];
			os.str("");
		}
		
		prop[expUserName]		 = user;
		prop[expPassword]		 = pass;

		os << config.exportTTL;
		prop[expTTL] = os.str();

		os.str("");
		os << config.exportBitrate;
		prop[expTransferBitrate] = os.str();
	}
#endif

	return url;
}

std::string ContentI::getMD5Checksum(const Ice::Current&) const {
	bool available = _storage->getAttrs(name, _attrs);

	return available ? _attrs.extAttrs[CNTPRY_MD5_CHECKSUM] : "";
}

void ContentI::getTrickSpeedCollection(TrickSpeedCollection& speeds, const Ice::Current&) const {
	bool available = _storage->getAttrs(name, _attrs);

	if(available) {
		speeds.push_back(7.5);
		speeds.push_back(-7.5);
	}
	else {
		ZQTianShan::_IceThrow<TianShanIce::InvalidStateOfArt>(
			"Content", 
			csexpCodeContentNotFound, 
			"trick speed not availabe for (%s)",
			name.c_str()
		);
	}
}

std::string ContentI::getSourceUrl(const Ice::Current& current) const{
	bool available = _storage->getAttrs(name, _attrs);

	return available ? _attrs.sourceUrl : "";
}


void ContentI::provision(
			const std::string& sourceUrl, 
			const std::string& sourceContentType, 
			bool overwrite, 
			const std::string& startTimeUTC, 
			const std::string& stopTimeUTC, 
			Ice::Int maxTransferBitrate, 
			const Ice::Current&) {

	glog(ZQ::common::Log::L_INFO, "provision content (%s) [source: (%s) type: (%s) bitrate: (%d)]", 
			name.c_str(), sourceUrl.c_str(), sourceContentType.c_str(), maxTransferBitrate);
	
	
	if(server.serverType() != server.SlaveNode && !config.isActive){
		ZQTianShan::_IceThrow<NoResourceException>(
			glog,
			"ContentStorI",
			csexpCodeNoResource,
			"ContentStore is not running in active mode"
		);
	}

	if (startTimeUTC.empty() || stopTimeUTC.empty()){
		ZQTianShan::_IceThrow<TianShanIce::InvalidParameter>(
			glog,
			"ContentStorI",
			csexpCodeNoResource,
			"provision time is not specified"
		);
	}

	
	char utcStartTime[255] = {0}; 
	char utcStopTime[255]  = {0};

	strcpy(utcStartTime, startTimeUTC.c_str());
	strcpy(utcStopTime, stopTimeUTC.c_str());

	if(!config.useUTC) {	
		if(!ZQ::common::TimeUtil::Local2Iso(startTimeUTC.c_str(), utcStartTime, 250)){
			ZQTianShan::_IceThrow<TianShanIce::InvalidParameter>(
				glog,
				"ContentStorI",
				csexpCodeInvalidParam,
				"failed to parse local provision time (%s) for (%s)",
				startTimeUTC.c_str(),
				name.c_str()
			);
		}

		glog(ZQ::common::Log::L_INFO, "local start time [%s]  UTC start time [%s]", startTimeUTC.c_str(), utcStartTime);

		if(!ZQ::common::TimeUtil::Local2Iso(stopTimeUTC.c_str(), utcStopTime, 250)){
			ZQTianShan::_IceThrow<TianShanIce::InvalidParameter>(
				glog,
				"ContentStorI",
				csexpCodeInvalidParam,
				"failed to parse local provision time (%s) for (%s)",
				stopTimeUTC.c_str(),
				name.c_str()
			);
		}

		glog(ZQ::common::Log::L_INFO, "local stop time [%s]  UTC stop time [%s]", stopTimeUTC.c_str(), utcStopTime);
	}

	time_t tStartTime, tEndTime;

	if (!ZQ::common::TimeUtil::Iso2Time(utcStartTime, tStartTime)){
		ZQTianShan::_IceThrow<TianShanIce::InvalidParameter>(
				glog,
				"ContentStorI",
				csexpCodeInvalidParam,
				"failed to parse local provision time (%s) for (%s)",
				utcStartTime,
				name.c_str()
		);
	}

	SYSTEMTIME st_utc;
	if (!ZQ::common::TimeUtil::Iso2Time(utcStartTime, st_utc)) {
		ZQTianShan::_IceThrow<TianShanIce::InvalidParameter>(
			glog,
			"ContentStorI",
			csexpCodeInvalidParam,
			"failed to parse UTC time (%s) for (%s)",
			utcStartTime,
			name.c_str()
		);
	}
	
	if (!ZQ::common::TimeUtil::Iso2Time(utcStopTime, tEndTime)){
		ZQTianShan::_IceThrow<TianShanIce::InvalidParameter>(
			glog,
			"ContentStorI",
			csexpCodeInvalidParam,
			"failed to parse UTC time (%s) for (%s)",
			utcStopTime,
			name.c_str()
		);
	}
	
	int transferBitrate = maxTransferBitrate;
	if (!maxTransferBitrate){
		transferBitrate = 3750000;
	}

	if(server.serverType() != server.SlaveNode) {
		using namespace TianShanIce::Storage::ContentProcess;

		CPManagerRoutine::bookSession(
					cptRTFWorkstation, 
					sourceUrl, 
					name, 
					getLocaltype(), 
					tStartTime, 
					tEndTime, 
					transferBitrate);

		CPManagerRoutine::startSession(st_utc, sourceUrl, name);
	}

	_attrs.sourceUrl = sourceUrl;
	_attrs.sourceType = sourceContentType;
	_storage->setAttrs(name, _attrs);

	if(server.serverType() != server.SlaveNode){
		EventDispatcher* dispatcher = EventDispatcher::getDispatcher();
		dispatcher->notifyProvisionStatusChange(name.c_str(), cpsSetup, cpsSetup);
	}
 }


std::string ContentI::provisionPassive(
			const std::string& sourceContentType, 
			bool overwrite, 
			const std::string& startTimeUTC, 
			const ::std::string& stopTimeUTC,
			Ice::Int maxTransferBitrate, 
			const Ice::Current&) {

	if(server.serverType() == server.MediaCluster){
		if(!server.slaveAvailable()) {
			ZQTianShan::_IceThrow<NoResourceException>(
				glog,
				"ContentStoreI",
				csexpCodeNoResource,
				"no active slave nodes available"
			);
		}
	}
	
	if(server.serverType() == server.SlaveNode) {
		ZQTianShan::_IceThrow<NoResourceException>(
			glog,
			"ContentStoreI", 
			csexpCodeNoResource,
			"can not perform provision request on a slave node"
		);
	}

	
	if (startTimeUTC.empty() || stopTimeUTC.empty()){
		ZQTianShan::_IceThrow<TianShanIce::InvalidParameter>(
			glog,
			"ContentStorI",
			csexpCodeNoResource,
			"provision time is not specified"
		);
	}

	char utcStartTime[255] = {0}; 
	char utcStopTime[255] = {0};

	strcpy(utcStartTime, startTimeUTC.c_str());
	strcpy(utcStopTime, stopTimeUTC.c_str());

	if(!config.useUTC) {
		if(!ZQ::common::TimeUtil::Local2Iso(startTimeUTC.c_str(), utcStartTime, 250)) {
			ZQTianShan::_IceThrow<TianShanIce::InvalidParameter>(
				glog,
				"ContentStorI",
				csexpCodeInvalidParam,
				"failed to parse local provision time (%s) for (%s)",
				startTimeUTC.c_str(),
				name.c_str()
			);
		}

		glog(ZQ::common::Log::L_INFO, "local start time [%s]  UTC start time [%s]", startTimeUTC.c_str(), utcStartTime);

		if(!ZQ::common::TimeUtil::Local2Iso(stopTimeUTC.c_str(), utcStopTime, 250)) {
			ZQTianShan::_IceThrow<TianShanIce::InvalidParameter>(
				glog,
				"ContentStorI",
				csexpCodeInvalidParam,
				"failed to parse local provision time (%s) for (%s)",
				stopTimeUTC.c_str(),
				name.c_str()
			);
		}

		glog(ZQ::common::Log::L_INFO, "local stop time [%s]  UTC stop time [%s]", stopTimeUTC.c_str(), utcStopTime);
	}

	time_t tStartTime, tEndTime;

	if (!ZQ::common::TimeUtil::Iso2Time(utcStartTime, tStartTime)) {
		ZQTianShan::_IceThrow<TianShanIce::InvalidParameter>(
			glog,
			"ContentStorI",
			csexpCodeInvalidParam,
			"failed to parse UTC time (%s) for (%s)",
			utcStartTime,
			name.c_str()
		);
	}

	if (!ZQ::common::TimeUtil::Iso2Time(utcStopTime, tEndTime)) {
		ZQTianShan::_IceThrow<TianShanIce::InvalidParameter>(
			glog,
			"ContentStorI",
			csexpCodeInvalidParam,
			"failed to parse UTC time (%s) for (%s)",
			utcStopTime,
			name.c_str()
		);
	}
	
	int transferBitrate = maxTransferBitrate;
	if (!maxTransferBitrate){
		transferBitrate = 3750000;
	}
	
	using namespace TianShanIce::Storage::PushContentModule; 
	char pushUrl[256] = {0};
	char errorMsg[256] = {0};
	
	if(config.isPassive) {
		bool result = PM_TryBookSession(tStartTime, tEndTime, transferBitrate);
		
		if(!result)	{
			ZQTianShan::_IceThrow<NoResourceException>(
				glog,
				"ContentStoreI",
				csexpCodeNoResource,
				"failed to book RDS session for (%s)",
				name.c_str()
			);
		}		
	
		glog(ZQ::common::Log::L_INFO, "book RDS session for (%s) successfully", name.c_str());
		
		result = PM_CreateSession(
					name.c_str(), 
					tStartTime, 
					tEndTime, 
					transferBitrate, 
					pushUrl, 
					255, 
					errorMsg, 
					255);

		if(!result)	{
			ZQTianShan::_IceThrow<NoResourceException>(
				glog,
				"ContentStoreI",
				csexpCodeNoResource,
				"failed to create RDS session for (%s): (%s)",
				name.c_str(),
				errorMsg
			);
		}

		glog(ZQ::common::Log::L_INFO, "create RDS session for (%s) successfully", name.c_str());
	} /* if(config.isPassive) */

	else if(config.isIngestCard) {
		bool result = RM_TryBookSession(tStartTime, tEndTime, transferBitrate);
		
		if(!result)	{
			ZQTianShan::_IceThrow<NoResourceException>(
				glog,
				"ContentStoreI",
				csexpCodeNoResource,
				"failed to book RDA session for (%s)",
				name.c_str()
			);
		}		
	
		glog(ZQ::common::Log::L_INFO, "book RDA session for (%s) successfully", name.c_str());
		
		result = RM_CreateSession(
					name.c_str(), 
					tStartTime, 
					tEndTime, 
					transferBitrate, 
					pushUrl, 
					255, 
					errorMsg, 
					255);

		if(!result)	{
			ZQTianShan::_IceThrow<NoResourceException>(
				glog,
				"ContentStoreI",
				csexpCodeNoResource,
				"failed to create RDA session for (%s): (%s)",
				name.c_str(),
				errorMsg
			);
		}

		glog(ZQ::common::Log::L_INFO, "create RDA session for (%s) successfully", name.c_str());
	} /* if(config.isIngestCard) */

	_attrs.sourceUrl = pushUrl;
	_attrs.sourceType = sourceContentType;
	_storage->setAttrs(name, _attrs);

	if(server.serverType() != server.SlaveNode) {
		EventDispatcher* dispatcher = EventDispatcher::getDispatcher();
		dispatcher->notifyProvisionStatusChange(name.c_str(), cpsSetup, cpsSetup);
	}

	return pushUrl;
}

void ContentI::cancelProvision(const Ice::Current&) {

	glog(ZQ::common::Log::L_INFO, "cancel provision of content (%s)", name.c_str());

	if(server.serverType() != server.SlaveNode) {
		if(config.isActive) {
 			TianShanIce::Storage::ContentProcess::CPManagerRoutine::removeSession(name);
		}
		if(config.isPassive) {
			if(!TianShanIce::Storage::PushContentModule::PM_RemoveSession(name.c_str())) {
				ZQTianShan::_IceThrow<InvalidStateOfArt>(
					csexpCategory.c_str(), 
					0, 
					"failed to cancel provision for (%s).", 
					name.c_str()
				);
			}
		}
		if(config.isIngestCard) {
			if(!TianShanIce::Storage::PushContentModule::RM_RemoveSession(name.c_str())) {
				ZQTianShan::_IceThrow<InvalidStateOfArt>(
					csexpCategory.c_str(), 
					0, 
					"failed to cancel provision for (%s).", 
					name.c_str()
				);
			}
		} /* if(config.isIngestCard) */
	}
}

void ContentI::destroy(const Ice::Current& current) {
	glog(ZQ::common::Log::L_INFO, "destroy content (%s)", name.c_str());


	/*
	* remove the content from storage
	*/
	if (server.serverType() != server.MediaCluster) {
		glog(ZQ::common::Log::L_INFO, "removing (%s) from storage", name.c_str());

		if(_store->type() == csNTFS) {
			if(!DeleteFileA(getName().c_str())) {
				glog(ZQ::common::Log::L_WARNING, "failed to remove (%s) from storage", getName().c_str());
			}
		}
		else if(_store->type() == csSCMediaCluster){
#ifndef MCCS
			VSTRM_FIND_DATA findData;
			VHANDLE fileHandle = VstrmFindFirstFile(
							_store->_vstrm, getName().c_str(), &findData);
				
			if(fileHandle != INVALID_HANDLE_VALUE && 
			  ((findData.ActiveReaderCount > 0    ||
			    findData.ActiveWriterCount > 0 ))) {
				
				VstrmFindClose(_store->_vstrm, fileHandle);
					
				ZQTianShan::_IceThrow<TianShanIce::InvalidStateOfArt>(
							glog, 
							"ContentStoreI", 
							csexpCodeContentInUse,
							"content (%s) in use [reader: (%d) writer: (%d)]",
							name.c_str(), 
							findData.ActiveReaderCount, 
							findData.ActiveWriterCount
				);
			}
			VstrmFindClose(_store->_vstrm, fileHandle);


			try	{
				_store->destroyContent(name);
			}
			catch(...) {
				glog(ZQ::common::Log::L_ERROR, "failed to add (%s) for removal.", getName().c_str());					
			}
#endif
		}			
		else {
			glog(ZQ::common::Log::L_WARNING, 
					"storage type (%s) for content (%s) not supported", 
					_store->type().c_str(),
					name.c_str());
		}
	} /* if serverType != MediaCluster */
	else {
		MediaClusterContentStorePrx slaveNode =  server.selectSlaveNode();
			
		if(!slaveNode) {
			glog(ZQ::common::Log::L_WARNING, 
				"no active slave node available, abort destroy (%s)", 
				name.c_str());
	
			return;
		}

		ContentPrx mcContent = 0;
		try {
			mcContent = slaveNode->openContent(name, getLocaltype(), false);
		}
		catch(const TianShanIce::InvalidStateOfArt& ex) {
			glog(ZQ::common::Log::L_WARNING, 
				"failed to open (%s) on node (%s): (%s)", 
				getName().c_str(), 
				slaveNode->getNetId().c_str(),
				ex.message);
		}
		
		if(mcContent) {
			mcContent->destroy();
		}
	}

	/*
	*	remove the servant object from evictor
	*/
	glog(ZQ::common::Log::L_INFO, "removing (%s) from object pool", getName().c_str());

	try	{
		server.adapter()->remove(current.id);
	}
	catch(const Ice::Exception& ex)	{
		glog(ZQ::common::Log::L_ERROR, 
					"failed to remove (%s) from object pool: (%s)",
					getName().c_str(), ex.ice_name().c_str()); 
	}
	
	
	/*
	*	remove active/passive session list
	*/
	if(server.serverType() != server.SlaveNode)	{
		glog(ZQ::common::Log::L_INFO, "removing (%s) from session list", getName().c_str());

		if(config.isPassive) {
			BOOL bRet = TianShanIce::Storage::PushContentModule::PM_RemoveSession(getName().c_str());
			if(bRet) {
				glog(ZQ::common::Log::L_INFO, "passive session (%s) removed", getName().c_str());
			}
			else {
				glog(ZQ::common::Log::L_WARNING, "remove passive session (%s) but not found", getName().c_str());
			}
		}
		if(config.isActive)	{
			try {
				TianShanIce::Storage::ContentProcess::CPManagerRoutine::removeSession(getName().c_str());
			}
			catch(TianShanIce::InvalidStateOfArt& ex) {
				glog(ZQ::common::Log::L_WARNING, "%s", ex.message.c_str());
			}
		}
	}

		
	/* 
	*	remove from safestore 
	*/
	glog(ZQ::common::Log::L_INFO, "removing (%s) from safestore", name.c_str());
	_storage->removeAttrs(name);
	
	/*
	*	fire content destroy event
	*/
	if(server.serverType() != server.SlaveNode) {
		EventDispatcher* dispatcher = EventDispatcher::getDispatcher();
		dispatcher->notifyProvisionStatusChange(name.c_str(), cpsProvisioned, cpsDestroyed);
	}
}



/*
*  Implementation of ContentStoreI			        
*/

ContentStoreI::ContentStoreI():
#ifndef MCCS 
_vstrm(0),
_statusUpdater(0),
_contentCleaner(0),
#endif
_pmEventTrigger(0),
_cpEventListener(0),
_rdaEventListener(0) {

	ContentFactoryPtr factory = new ContentFactory();

	server.communicator()->addObjectFactory(
				factory, ContentI::ice_staticId());
	
	server.communicator()->addObjectFactory(
				factory, StatusMsgI::ice_staticId());

	
#ifndef MCCS 
	initVstream();
	vsm_Initialize(_vstrm);
	VV2Parser::vsmInit(_vstrm);
#endif

	if(server.serverType() != server.SlaveNode) {
		bool isCluster = 
			(server.serverType() == server.MediaCluster) ? true : false;

		if(config.isPassive) {
			/*
			* Initialize PushManager
			*/
			using namespace TianShanIce::Storage::PushContentModule; 
			bool result = PM_Initialize(config.dbPath, 
									  server.configDir().c_str(), 
									  server.logDir().c_str(), 
									  isCluster);

			if(!result){
				ZQTianShan::_IceThrow<NoResourceException>(
					glog,
					"ContentStoreI",
					csexpCodeNoResource,
					"failed to initialize PushManager"
				);
			}
			
			/*
			*	Standalone node must subscribe to rds.
			*/
			if(server.serverType() == server.StandaloneNode) {
				result = PM_AddClusterNode(MEDIA_CLUSTER_ID, config.propagationIP);
				if(!result) {			
					ZQTianShan::_IceThrow<NoResourceException>(
						glog,
						"ContentStoreI",
						csexpCodeNoResource,
						"failed to add cluster node to PushManager"
					);
				}
			}
	
			/*
			* create & register event sink for PushManager
			*/
			_pmEventTrigger = new NodePushSessionEventSink();
			PM_RegSessionCallBack(_pmEventTrigger);
		} /* if (config.isPassive) */
		
		if(config.isActive)	{
			using namespace TianShanIce::Storage::ContentProcess; 
			
			CPManagerRoutine::initialize(
						server.configDir(), 
						server.logDir(), 
						config.dbPath, 
						isCluster);

			short iii = __getRef();
	
			_cpEventListener = new NodeCPEventSink();
			CPManagerRoutine::setEventListener(_cpEventListener);

			short iiiiiiiiii = __getRef();
		}

		if(config.isIngestCard) {
			using namespace TianShanIce::Storage::PushContentModule; 
			
			bool result = RM_Initialize(
						config.dbPath,
						server.configDir().c_str(),
						isCluster?"ClusterContentStore.xml":"NodeContentStore.xml",
						server.logDir().c_str());

			if(!result){
				ZQTianShan::_IceThrow<NoResourceException>(
					glog,
					"ContentStoreI",
					csexpCodeNoResource,
					"failed to initialize RDAManager"
				);
			}
			
			_rdaEventListener = new RDASessionEventSink();
			RM_RegSessionCallBack(_rdaEventListener);
		}
	} /* serverType != SlaveNode */
		

#ifndef MCCS
	_statusUpdater = new StatusUpdater();
	_statusUpdater->start();

	_contentExport.Init(server.configDir().c_str(), 
						"NodeContentStore.xml", 
						server.logDir().c_str());


	_contentCleaner = new ContentCleaner(config.dbPath);
	_contentCleaner->initialize(_vstrm);
	_contentCleaner->start();

//	for (short v = 10; v <= 30; v += 10) {
//		config.mode = getProvisionMode();
//
//		if(config.mode) {
//			break;
//		}
//		else {
//			Sleep(v*1000);
//		}
//	}

//	if(config.mode & ACTIVE) {
	if(config.enableVstrmCPNode) {
		_vstrmCPNode.initialize(server.configDir(), server.logDir(), _vstrm);
	}
//	}

#endif

	short iiiiiiiiiiiii = __getRef();
}

ContentStoreI::~ContentStoreI() {
}


void ContentStoreI::uninitialize() {

	if(config.isPassive){
		if(_pmEventTrigger != NULL)	{
			delete _pmEventTrigger;
			_pmEventTrigger = NULL;
		}
		
		try {
			using namespace TianShanIce::Storage::PushContentModule;
			PM_UnInitialize();
		}
		catch(...) {
		}
	}
	if(config.isIngestCard) {
		if(_rdaEventListener) {
			delete _rdaEventListener;
			_rdaEventListener = 0;
		}
		try {
			using namespace TianShanIce::Storage::PushContentModule;
			RM_UnInitialize();
		}
		catch(...) {
		}
	}
	if(config.isActive){
		if(_cpEventListener){
			delete _cpEventListener;
			_cpEventListener = 0;
		}

		try {
			using namespace TianShanIce::Storage::ContentProcess;
			CPManagerRoutine::uninitialize();
		}
		catch(...){
		}
	}


#ifndef MCCS
	if(_statusUpdater) {
		_statusUpdater->stop();
		_statusUpdater->waitHandle(2000);

		delete _statusUpdater;
		_statusUpdater = 0;
	}

	if(_contentCleaner)	{
		_contentCleaner->stop();
		_contentCleaner->waitHandle(2000);

		delete _contentCleaner;
		_contentCleaner = 0;
	}

	if(config.enableVstrmCPNode) {
		_vstrmCPNode.uninitialize();
	}

	if(_vstrm){
		VstrmClassCloseEx(_vstrm);
		_vstrm = 0;
	}
#endif
}


std::string ContentStoreI::getAdminUri(const Ice::Current& current){
	ZQTianShan::_IceThrow<NotImplemented>("ContentStoreI", 0, "not implemented");
	return "";
}

TianShanIce::State ContentStoreI::getState(const Ice::Current& current){
	ZQTianShan::_IceThrow<NotImplemented>("ContentStoreI", 0, "not implemented");
	throw;
}

std::string ContentStoreI::getNetId(const Ice::Current& current) const {
	return config.netID;
}

std::string ContentStoreI::type(const Ice::Current& current) const{
	return csSCMediaCluster;
}

bool ContentStoreI::isValid(const Ice::Current& current) const{
	return true;
}

#ifndef MCCS 
void ContentStoreI::initVstream() {
	VSTATUS vStatus;

	vStatus = VstrmClassOpenEx(&_vstrm);
	if (vStatus != VSTRM_SUCCESS){
		char szBuf[255] = {0};
		VstrmClassGetErrorText(_vstrm, vStatus, szBuf, sizeof(szBuf));

		ZQTianShan::_IceThrow<TianShanIce::InvalidStateOfArt>(
			glog,
			"ContentStoreI",
			esexpCodeInternalError,
			"failed to initializ vstream driver: (%s)",
			szBuf
		);
	}
}
#endif

void ContentStoreI::getCapacity(Ice::Long& freeMB, Ice::Long& totalMB, const Ice::Current&){
	
	if(server.serverType() == server.MediaCluster){
		MediaClusterContentStorePrx slaveNode = server.selectSlaveNode();

		if(!slaveNode) {
			ZQTianShan::_IceThrow<TianShanIce::InvalidStateOfArt>(
				glog,
				"ContentStoreI",
				csexpCodeNoResource,
				"failed to get storage info: (no active slave nodes available)"
			);
		}

		slaveNode->getCapacity(freeMB, totalMB);

		return;
	}


#ifndef MCCS

	VSTATUS vStatus;
	
	LARGE_INTEGER freeSpace, totalSpace;

	vStatus = VstrmClassGetStorageData(_vstrm, &freeSpace, &totalSpace);

	if (vStatus != VSTRM_SUCCESS) {
		char msg[512] = {0};
		VstrmClassGetErrorText(_vstrm, vStatus, msg, sizeof(msg));

		ZQTianShan::_IceThrow<TianShanIce::InvalidStateOfArt>(
			glog,
			"ContentStoreI",
			esexpCodeInternalError,
			"failed to get storage info: (%s)",
			msg
		);
	}

	freeMB  = freeSpace.QuadPart /  (1024 * 1024);
	totalMB = totalSpace.QuadPart / (1024 * 1024);

#endif
}

TianShanIce::StrValues ContentStoreI::listContent(const std::string& condition, const Ice::Current&) const {
	if(condition.empty() || condition.size() > 250)	{
		ZQTianShan::_IceThrow<TianShanIce::InvalidParameter>(
			glog,
			"ContentStoreI",
			csexpCodeInvalidParam,
			"the requested name must be shorter than 250"	
		);
	}

	TianShanIce::StrValues values;	
	
	ContentStorage* storage = ContentStorage::getStorage();
	if(condition.find('?') == std::string::npos && 
		condition.find('*') == std::string::npos) {
		
		ContentDictData::ContentAttrs attrs;

		bool available = storage->getAttrs(condition, attrs);

		if(available) {
			values.push_back(condition);

			return values;
		}

		ZQTianShan::_IceThrow<TianShanIce::InvalidStateOfArt>(
			glog,
			"ContentStoreI",
			csexpCodeContentNotFound,
			"failed to list content (%s)",
			condition
		);
	}
	
	std::vector<std::string> names;
	storage->getContentNames(names);

	while(names.size() > 0)	{
		std::string contentName = names.back();
		names.pop_back();
		
		if(PathMatchSpecA(contentName.c_str(), condition.c_str())) {
			values.push_back(contentName);
		}
	}
	
	if(values.empty()) {
		ZQTianShan::_IceThrow<TianShanIce::InvalidStateOfArt>(
			glog,
			"ContentStoreI",
			csexpCodeContentNotFound,
			"failed to list content (%s)",
			condition
		);
	}

	return values;
}


ContentPrx ContentStoreI::openContent(
				const std::string& name, 
				const std::string& destType, 
				bool create, 
				const Ice::Current& current) {
	
	if (name.empty()) {
		ZQTianShan::_IceThrow<TianShanIce::InvalidParameter>(
			glog,
			"ContentStoreI",
			csexpCodeInvalidParam,
			"open content with empty name."
		);
	}

	glog(ZQ::common::Log::L_INFO, "opening content (%s) [type: (%s) create: (%s)]", 
							name.c_str(), destType.c_str(), create?"true":"false");

	
	ContentDictData::ContentAttrs attrs;
	ContentStorage* storage = ContentStorage::getStorage();

	bool inDict = storage->getAttrs(name, attrs);
	bool inDisk = isContentInDisk(name);

    Ice::Identity identity;
    identity.name = name; 
    identity.category = "content";

	if(!inDict && !inDisk) {
		if(!create && server.serverType() != server.MediaCluster) {
			ZQTianShan::_IceThrow<InvalidStateOfArt>(
				glog,
				"ContentStoreI", 
				csexpCodeContentNotFound,
				"content (%s) does not exist in the ContentStore server.",
				name.c_str()
			);
		}

		if(!create) {
			glog(ZQ::common::Log::L_WARNING, "(%s) not found in Cluster, trying to open from a slave node.", name.c_str());

			MediaClusterContentStorePrx slaveNode = server.selectSlaveNode();
				
			if(!slaveNode) {
				ZQTianShan::_IceThrow<InvalidStateOfArt>(
					glog,
					"ContentStoreI", 
					csexpCodeContentNotFound,
					"failed to open (%s) from slave node",
					name.c_str()
				);
			}

			ContentPrx content = slaveNode->openContent(name, destType, create);
			MediaClusterContentPrx mcContent = MediaClusterContentPrx::uncheckedCast(content);

			attrs.name = name;
			attrs.localType = mcContent->getLocaltype();

			time_t stamp = static_cast<long>(attrs.stampProvision);
			ZQ::common::TimeUtil::Str2Time(mcContent->getProvisionTime().c_str(), stamp);
			mcContent->getResolution(attrs.resolutionH, attrs.resolutionV); 
			attrs.bitrate = mcContent->getBitRate();
			attrs.playtime = mcContent->getPlayTimeEx();
			attrs.fps = mcContent->getFramerate();
			attrs.fileSize = mcContent->getFilesize();
			attrs.sourceUrl = mcContent->getSourceUrl();
			attrs.subType = mcContent->getSubtype();
			if(mcContent->isProvisioned()) {
				attrs.status = ContentDictData::stPROVISIONED;
			}
		}
		else {
			attrs.localType = destType;
			attrs.resolutionH = attrs.resolutionV = 0;
			attrs.bitrate = 0;
			attrs.fps = 0.0f;
			attrs.playtime = 0;
			attrs.fileSize = 0;
			attrs.fps = 0.0;
			attrs.sourceUrl = "";
			attrs.status = ContentDictData::stCREATED;
		}
		storage->setAttrs(name, attrs);
		
		goto end;
	}
	
	if((inDict && attrs.status == ContentDictData::stPROVISIONED) ||
		inDict && !inDisk && attrs.status != ContentDictData::stPROVISIONED) {
		goto end;
	}

	if((!inDict && inDisk) ||
		(inDict && inDisk && attrs.status != ContentDictData::stPROVISIONED)) {

		if(!storage->getAttrsFromIndex(name, attrs)) {
//			ZQTianShan::_IceThrow<InvalidStateOfArt>(
//				glog,
//				"ContentStoreI", 
//				csexpCodeContentNotFound,
//				"error loading VVX/VV2 for content (%s)",
//				name.c_str()
//			);
			glog(ZQ::common::Log::L_WARNING, "error loading VVX/VV2 for content (%s)", name.c_str()); 

			goto end;
		}
		if(server.serverType() == server.SlaveNode) {
			if(isContentProvisioned(name)) {
				attrs.status = ContentDictData::stPROVISIONED;
			}
		}
		storage->setAttrs(name, attrs);
	}

end:
	ContentIPtr content = new ContentI(this);
	content->name = name;
	
	if(!server.adapter()->find(identity)) {
		server.adapter()->add(content, identity);
	}


	return ContentPrx::uncheckedCast(server.adapter()->createProxy(identity));

}


bool ContentStoreI::sinkStateChangeEvent(const ProvisionStateChangeSinkPrx& event, const Ice::Current& current) {
	EventDispatcher* dispatcher = EventDispatcher::getDispatcher();

	return dispatcher->sinkStateChange(event);
}

bool ContentStoreI::sinkProgressEvent(const ProvisionProgressSinkPrx& event, const Ice::Current&) {
	EventDispatcher* dispatcher = EventDispatcher::getDispatcher();

	return dispatcher->sinkProgress(event);
}

bool ContentStoreI::unsinkEvent(const TianShanIce::Events::BaseEventSinkPrx& event, const Ice::Current&) {
	EventDispatcher* dispatcher = EventDispatcher::getDispatcher();

	return dispatcher->unsinkEvent(event);
}

void ContentStoreI::registerSlaveNode(
				const std::string& netID, 
				const std::string& endpoint, 
				const std::string& propagationIP, 
				const Ice::Current& current) {

	server.registerSlaveNode(netID, endpoint, propagationIP);
}

bool ContentStoreI::isContentProvisioned(const std::string& name, const Ice::Current&) {

#ifndef MCCS
	glog(ZQ::common::Log::L_INFO, "query cluster if session (%s) provisioned", name.c_str()); 

	MediaClusterContentStorePrx cluster = server.getCluster();
		
	if(!cluster) {
		return false;
	}

	try {
		return cluster->isContentProvisioned(name);
	}
	catch(const Ice::Exception& ex) {
		glog(ZQ::common::Log::L_WARNING, 
			"failed to query cluter (%s) for the status of (%s): (%s)", 
			config.clusterEndpoint,
			name.c_str(),
			ex.ice_name().c_str());
	}

#else
	ContentDictData::ContentAttrs attrs;
	ContentStorage* storage = ContentStorage::getStorage();

	bool available = false;
	
	available = storage->getAttrs(name, attrs);
	
	if(available) {
		return (attrs.status == ContentDictData::stPROVISIONED);
	}
	else {
		bool passive = false;
		bool active = false;
		bool card = false;

		if(config.isPassive) {
			using namespace TianShanIce::Storage::PushContentModule;
			passive = PM_QuerySession(name);
		}
		if(config.isActive) {
			using namespace TianShanIce::Storage::ContentProcess;
			active = CPManagerRoutine::querySession(name);
		}
		if(config.isIngestCard) {
			using namespace TianShanIce::Storage::PushContentModule;
			card = RM_QuerySession(name.c_str());
		}

		return !(passive || active || card);
	}

#endif

	return false;

}


void ContentStoreI::notifyContentProvisioned(const std::string& name, const Ice::Current&) {
#ifdef MCCS
	glog(ZQ::common::Log::L_INFO, "notify provisioned content (%s) to slave nodes", name.c_str()); 
	
	std::map<std::string, MediaClusterContentStorePrx> slaveNodes;
	
	server.getSlaveNodes(slaveNodes);

	std::map<std::string, MediaClusterContentStorePrx>::iterator iter = slaveNodes.begin();
	for(; iter != slaveNodes.end(); ++iter) {
		try {
			iter->second->notifyContentProvisioned(name);
		}
		catch(const Ice::Exception& e) {
			glog(ZQ::common::Log::L_WARNING, 
					"failed to dispatch provisioned message of (%s) to (%s): (%s)", 
					name.c_str(),
					iter->first.c_str(),
					e.ice_name().c_str());
		}
	}

#else
	glog(ZQ::common::Log::L_INFO, "updating properties of provisioned content (%s)", name.c_str()); 

	_statusUpdater->updateStatus(name);
#endif
 }


short ContentStoreI::getProvisionMode(const Ice::Current&) {
	short mode = 0x0000;
	std::ostringstream os;

	if(server.serverType() == server.SlaveNode) {
	
		MediaClusterContentStorePrx cluster = server.getCluster();
		
		if(!cluster) {
			return mode;
		}

		try {
			mode = cluster->getProvisionMode();
		}
		catch(const Ice::Exception& ex) {
			glog(ZQ::common::Log::L_WARNING, 
				"failed to get provisione mode of cluster (%s): (%s)", 
				config.clusterEndpoint,
				ex.ice_name().c_str());
		}
	}
	else {

		if(config.isActive) {
			mode |= ACTIVE;

			os << "active";
		}
		if(config.isPassive) {
			mode |= PASSIVE;
			
			os << ((!os.str().empty()) ? ", passive" : "passive");
		}
		if(config.isIngestCard) {
			mode |= INGEST_CARD;

			os << ((!os.str().empty()) ? ", ingest card" : "ingest card");
		}
	}
	
	if(mode) {
		glog(ZQ::common::Log::L_INFO, 
				"ContentStore is running in (%s) provision mode",
				os.str().c_str());
	}

	return mode;
}

bool ContentStoreI::isContentInDisk(const std::string& name) const {
	
#ifndef MCCS

	bool found = true;

	DLL_FIND_DATA_LONG findData = {0};
	VHANDLE fileHandle = VstrmFindFirstFileEx(_vstrm, name.c_str(), &findData);

	found = (fileHandle != INVALID_HANDLE_VALUE);
	
	VstrmFindClose(_vstrm, fileHandle);
	
	return found;

#endif
	
	return false;
}

void ContentStoreI::destroyContent(const std::string& name) {
#ifndef MCCS
	_contentCleaner->cleanContent(name);
#endif
}



__END_TIANSHAN_STORAGE
