#include "SsmTianShan.h"
#include "Log.h"
#include "stroprt.h"

extern "C"
{
#include <time.h>
#include <stdarg.h>
#include <string.h>
#include <stdio.h>
}


// -----------------------------
// class SsmTianShan
// -----------------------------

void SsmTianShan::setConfigPath(std::string path)
{
	m_configFile = path;
}

bool SsmTianShan::openSessCtx(const std::string& clientSessId, WeiwooSession& sessCtx)
{
	if (clientSessId.empty())
	{
		m_Log(ZQ::common::Log::L_DEBUG, CLOGFMT(SsmTianShan, "openSessCtx() no client session Id was provided"));
		return false;
	}

	ZQ::common::MutexGuard gd(_lockSessCtx);
	if (m_cwMap.end() != m_cwMap.find(clientSessId))
	{
		sessCtx = m_cwMap[clientSessId];
		m_Log(ZQ::common::Log::L_DEBUG, CLOGFMT(SsmTianShan, "openSessCtx() clientsess[%s] seversess[%s] opened"), clientSessId.c_str(), sessCtx._sessID.c_str());
		return true;
	}
	else
	{
		m_Log(ZQ::common::Log::L_ERROR, CLOGFMT(SsmTianShan, "openSessCtx() clientsess[%s] could not find session context"), clientSessId.c_str());
		return false;
	}
}

bool SsmTianShan::saveSessCtx(const std::string& clientSessId, WeiwooSession& sessCtx)
{
	if (clientSessId.empty())
	{
		m_Log(ZQ::common::Log::L_DEBUG, CLOGFMT(SsmTianShan, "saveSessCtx() no client session Id was provided"));
		return false;
	}

	sessCtx._lastAccessTime = ::time(NULL);

	if (sessCtx._sessPrx)
	{
		try
		{
			sessCtx._sessPrx->renew(3000 * _config._sessionTimeout);
		}
		catch (const TianShanIce::BaseException& ex)
		{
			m_Log(ZQ::common::Log::L_ERROR, CLOGFMT(SsmTianShan, "saveSessCtx() sess[%s] renew caught exception[%s]:%s"), sessCtx._sessID.c_str(), ex.ice_name().c_str(), ex.message.c_str());
			return false;
		}
		catch (const Ice::Exception& ex)
		{
			m_Log(ZQ::common::Log::L_ERROR, CLOGFMT(SsmTianShan, "saveSessCtx() sess[%s] renew caught exception[%s]"), sessCtx._sessID.c_str(), ex.ice_name().c_str());
			return false;
		}
		catch (...)
		{
			m_Log(ZQ::common::Log::L_ERROR, CLOGFMT(SsmTianShan, "saveSessCtx() sess[%s] renew caught unknown exception"), sessCtx._sessID.c_str());
			return false;
		}
	}

	ZQ::common::MutexGuard gd(_lockSessCtx);
	m_cwMap[clientSessId] = sessCtx;
	m_Log(ZQ::common::Log::L_DEBUG, CLOGFMT(SsmTianShan, "openSessCtx() clientsess[%s] seversess[%s] saved"), clientSessId.c_str(), sessCtx._sessID.c_str());

	return true;
}

bool SsmTianShan::deleteSessCtx(const std::string& clientSessId, std::string reason)
{
	if (clientSessId.empty())
	{
		m_Log(ZQ::common::Log::L_DEBUG, CLOGFMT(SsmTianShan, "deleteSessCtx() no client session Id was provided"));
		return false;
	}

	std::string strmStr;
	{
		ZQ::common::MutexGuard gd(_lockSessCtx);
		ClientSessToWeiwooSessMap::iterator tItor = m_cwMap.find(clientSessId);
		if (m_cwMap.end() != tItor)
		{
			strmStr = tItor->second._streamID;
			m_cwMap.erase(clientSessId);
			m_Log(ZQ::common::Log::L_DEBUG, CLOGFMT(SsmTianShan, "deleteSessCtx(), reason: [%s] clientsess: [%s] removed from map"), reason.c_str(), clientSessId.c_str());
		}
		else
			m_Log(ZQ::common::Log::L_WARNING, CLOGFMT(SsmTianShan, "deleteSessCtx(), reason: [%s] clientsess: [%s] could not find in map"), reason.c_str(), clientSessId.c_str());
	}

	{
		ZQ::common::MutexGuard lk(_lockStreamIdx);
		StreamToClientSessMap::iterator tItor = m_scMap.find(strmStr);
		if (m_scMap.end() != tItor)
		{
			m_scMap.erase(tItor);
			m_Log(ZQ::common::Log::L_DEBUG, CLOGFMT(SsmTianShan, "deleteSessCtx(), reason: [%s] stream: [%s] removed from map"), reason.c_str(), strmStr.c_str());
		}
		else 
			m_Log(ZQ::common::Log::L_WARNING, CLOGFMT(SsmTianShan, "deleteSessCtx(), reason: [%s] stream: [%s] could not find in map"), reason.c_str(), strmStr.c_str());
	}

	return true;
}

RequestProcessResult SsmTianShan::doContentHandle(IStreamSmithSite* pSite, IClientRequestWriter* pReq)
{
	m_Log(ZQ::common::Log::L_DEBUG, CLOGFMT(SsmTianShan, "doContentHandle()"));

	RequestProcessResult ret = RequestUnrecognized;

	// switch by method
	switch(pReq->getVerb())
	{
	case RTSP_MTHD_SETUP: 
		{
			::TianShanIce::SRM::SessionPrx retSessPrx = NULL;
			std::string retSession;
			ret = SetupHandler(*this, pSite, pReq).process(retSession, retSessPrx);
			if (RequestPhaseDone == ret)
			{
				deleteSessCtx(retSession, "setup-failed");
				if (true == m_pSite->destroyClientSession(retSession.c_str()))
					m_Log(ZQ::common::Log::L_DEBUG, CLOGFMT(SsmTianShan, "Session: [%s], rtsproxy session: %s destroyed."), retSession.c_str(), retSession.c_str());
				try
				{
					::Ice::Context ctx;
					ctx["caller"] = "Session-Timeout";
					retSessPrx->destroy(ctx);
					m_Log(ZQ::common::Log::L_DEBUG, CLOGFMT(SsmTianShan, "Session: [%s], weiwoo session: [%s] destoryed."), retSession.c_str(), m_communicator->proxyToString(retSessPrx).c_str());
				}
				catch (TianShanIce::BaseException& ex)
				{
					m_Log(ZQ::common::Log::L_WARNING, CLOGFMT(SsmTianShan, "Session: [%s], destory weiwoo session: [%s] cought %s:%s exception."), retSession.c_str(), m_communicator->proxyToString(retSessPrx).c_str(), ex.ice_name().c_str(), ex.message.c_str());
				}
				catch (Ice::Exception& ex)
				{
					m_Log(ZQ::common::Log::L_WARNING, CLOGFMT(SsmTianShan, "Session: [%s], destory weiwoo session: [%s] cought %s exception."), retSession.c_str(), m_communicator->proxyToString(retSessPrx).c_str(), ex.ice_name().c_str());
				}
				catch(...)
				{
					m_Log(ZQ::common::Log::L_WARNING, CLOGFMT(SsmTianShan, "Session: [%s], destory weiwoo session: [%s] cought unexpect exception."), retSession.c_str(), m_communicator->proxyToString(retSessPrx).c_str());
				}
			}
		}
		break;

	case RTSP_MTHD_PLAY:
		ret = PlayHandler(*this, pSite, pReq).process();
		break;

	case RTSP_MTHD_PAUSE:
		ret = PauseHandler(*this, pSite, pReq).process();
		break;

	case RTSP_MTHD_TEARDOWN:
		ret = TeardownHandler(*this, pSite, pReq).process();
		break;

	case RTSP_MTHD_GET_PARAMETER:
		ret = GetParameterHandler(*this, pSite, pReq).process();
		break;

	case RTSP_MTHD_PING:
		ret = PingHandler(*this, pSite, pReq).process();
		break;

	default:
		ret = SsmMethodHandler(*this, pSite, pReq).process();
		break;
	}

	m_Log(ZQ::common::Log::L_DEBUG, CLOGFMT(SsmTianShan, "doContentHandle() finished"));
	return ret;
}


// -----------------------------
// class SsmMethodHandler
// -----------------------------
SsmMethodHandler::SsmMethodHandler(SsmTianShan& ssm, IStreamSmithSite* pSite, IClientRequestWriter* pReq, const std::string& method)
: _ssm(ssm), _pSite(pSite), _pReq(pReq), _pResponse(NULL), _method(method), _bCRPrivateDataCopied(false)
{
	char buf[1024]; uint16 len = sizeof(buf) -2;

	if (NULL != _pReq)
	{
		if (NULL != _pReq ->getHeader(HEADER_SEQ, buf, &len))
			_cseq = buf;

		len = sizeof(buf) -2;
		if (NULL != _pReq ->getHeader(HEADER_USERAGENT, buf, &len))
			_userAgent = buf;
		
		const char* sessid = _pReq ->getClientSessionId();
		_clientSessId = sessid ? sessid: "";
		
		_pResponse = _pReq->getResponse();

		if (_pResponse)
		{
			_pResponse->setHeader(HEADER_SEQ, _cseq.c_str());
			_pResponse->setHeader(HEADER_SESSION, _clientSessId.c_str());
			_pResponse->setHeader(HEADER_MTHDCODE, _method.c_str());
			_pResponse->setHeader(HEADER_SERVER, _ssm.m_headerServer.c_str());
		}
	}

	handlerlog(ZQ::common::Log::L_DEBUG, HANDLERLOGFMT(SsmMethodHandler, "handle for " HEADER_USERAGENT ": %s"), _userAgent.c_str());
}

SsmMethodHandler::~SsmMethodHandler()
{
}
	
RequestProcessResult SsmMethodHandler::process()
{
	handlerlog(ZQ::common::Log::L_ERROR, HANDLERLOGFMT(SsmMethodHandler, "process() unsupported RTSP method"));
	composeErrorResp(RESPONSE_BAD_REQUEST, "Unsupported RTSP method");

	return RequestPhaseDone;
}

const char* SsmMethodHandler::getClientSessionId()
{
	return _clientSessId.c_str();
}

const char* SsmMethodHandler::setError(const char *fmt, ...)
{
	char msg[2048];
	va_list args;

#pragma message(__MSGLOC__"TODO: Can I use vsnprintf here?")
	
	va_start(args, fmt);
	int nCount = vsprintf(msg, fmt, args);
	va_end(args);

	if(nCount == -1)
		msg[sizeof(msg) -2] = '\0';
	else
		msg[nCount] = '\0';
	
	_lastError = msg;
	handlerlog(ZQ::common::Log::L_ERROR, HANDLERLOGFMT(SsmMethodHandler, "setError() %s"), _lastError.c_str());
	
	return _lastError.c_str();
}


::TianShanIce::SRM::SessionPrx SsmMethodHandler::getServerSession()
{
	if (!_serverSessCtx._sessPrx)
	{
		handlerlog(ZQ::common::Log::L_ERROR, HANDLERLOGFMT(SsmMethodHandler, "getServerSession() server session unassociated"));
		return NULL;
	}

	if (!_bCRPrivateDataCopied && NULL != _pReq)
	{
		handlerlog(ZQ::common::Log::L_DEBUG, HANDLERLOGFMT(SsmMethodHandler, "getServerSession() flush the client request headers into server session privatedata"));
		try
		{
			::TianShanIce::Variant value;
			::TianShanIce::ValueMap attrs;

			value.type=::TianShanIce::vtStrings;
			value.bRange = false;
			char buf[2048]; uint16 bufsize = sizeof(buf) -2;
			static const char* knownHeaders[] = {
				"Session", "User-Agent", "Range", "Scale", "Transport", "x-reason", 
				"SeaChange-Version", "SeaChange-MayNotify", "SeaChange-Server-Data", "SeaChange-Notice",
				"TianShan-Transport", "TianShan-Version", "TianShan-ServiceGroup", "TianShan-AppData", "TianShan-Notice", 
				NULL
			};
			
			for (int idx = 0; _serverSessCtx._sessPrx && NULL != knownHeaders[idx]; idx ++)
			{

				if (NULL != _pReq->getHeader(knownHeaders[idx], buf, &bufsize))
				{
					value.strs.clear();
					value.strs.push_back(buf);
					std::string key_str(CLIENTREQ_PRIVATEDATA_PREFIX);
					key_str += knownHeaders[idx];
					attrs.insert(::TianShanIce::ValueMap::value_type(key_str, value));
				}

			}

			_serverSessCtx._sessPrx->setPrivateData2(attrs);
			_bCRPrivateDataCopied = true;
		}
		catch (const ::TianShanIce::BaseException& ex)
		{
			handlerlog(ZQ::common::Log::L_ERROR, HANDLERLOGFMT(SsmMethodHandler, "getServerSession() flush privateData of serversession[%s] exception[%s]:%s"), _serverSessCtx._sessID.c_str(), ex.ice_name().c_str(), ex.message.c_str());
		}
		catch (const ::Ice::Exception& ex)
		{
			handlerlog(ZQ::common::Log::L_ERROR, HANDLERLOGFMT(SsmMethodHandler, "getServerSession() flush privateData of serversession[%s] exception[%s]"), _serverSessCtx._sessID.c_str(), ex.ice_name().c_str());
		}
		catch (...)
		{
			handlerlog(ZQ::common::Log::L_ERROR, HANDLERLOGFMT(SsmMethodHandler, "getServerSession() flush privateData of serversession[%s] unknown exception"), _serverSessCtx._sessID.c_str());
		}
	}

	return _serverSessCtx._sessPrx;
}

TianShanIce::Streamer::StreamPrx SsmMethodHandler::getStream()
{
	if (_serverSessCtx._stream)
		return _serverSessCtx._stream;

	if (!getServerSession())
	{
		handlerlog(ZQ::common::Log::L_ERROR, HANDLERLOGFMT(SsmMethodHandler, "getStream() server session unassociated"));
		return NULL;
	}

	try
	{
		_serverSessCtx._stream = _serverSessCtx._sessPrx->getStream();
		_serverSessCtx._streamID = _serverSessCtx._stream->getIdent().name;
	}
	catch(const ::TianShanIce::BaseException& ex)
	{
		setError("getStream() access stream exception[%s]:%s", ex.ice_name().c_str(), ex.message.c_str());
		return NULL;
	}
	catch(const ::Ice::Exception& ex)
	{
		setError("getStream() access stream exception[%s]", ex.ice_name().c_str());
		return NULL;
	}

	handlerlog(ZQ::common::Log::L_INFO, HANDLERLOGFMT(SsmMethodHandler, "getStream() stream[%s] associated"), _serverSessCtx._streamID.c_str());
	return _serverSessCtx._stream;
}

TianShanIce::Application::PurchasePrx SsmMethodHandler::getPurchase()
{
	if (_serverSessCtx._purchase)
		return _serverSessCtx._purchase;

	if (!getServerSession())
	{
		handlerlog(ZQ::common::Log::L_ERROR, HANDLERLOGFMT(SsmMethodHandler, "getPurchase() server session unassociated"));
		return NULL;
	}

	try
	{
		_serverSessCtx._purchase = _serverSessCtx._sessPrx->getPurchase();
		_serverSessCtx._purchaseID = _ssm.m_communicator->proxyToString(_serverSessCtx._purchase);
	}
	catch(const ::TianShanIce::BaseException& ex)
	{
		setError("getPurchase() access purchase exception[%s]:%s", ex.ice_name().c_str(), ex.message.c_str());
		return NULL;
	}
	catch(const ::Ice::Exception& ex)
	{
		setError("getPurchase() access purchase exception[%s]", ex.ice_name().c_str());
		return NULL;
	}

	handlerlog(ZQ::common::Log::L_INFO, HANDLERLOGFMT(SsmMethodHandler, "getPurchase() purchase[%s] associated"), _serverSessCtx._purchaseID.c_str());
	return _serverSessCtx._purchase;
}

bool SsmMethodHandler::getPosScaleFromApplication(std::string& scale, std::string& pos, const std::string& pos_descriptor /*="npt"*/)
{
	handlerlog(ZQ::common::Log::L_DEBUG, HANDLERLOGFMT(SsmMethodHandler, "getPosScaleFromApplication(), pos_descriptior=%s"), pos_descriptor.c_str());
	scale = pos = ""; // clean the outputs first

	if (!getPurchase())
	{
		handlerlog(ZQ::common::Log::L_ERROR, HANDLERLOGFMT(SsmMethodHandler, "getPosScaleFromApplication() failed to address purchase"));
		return false;
	}

	std::vector<std::string> param_strs;
	/*std::string posvar = (pos_descriptor.empty() || 0==pos_descriptor.compare("npt")) ? "Position" : (std::string("Position.") +pos_descriptor);*/
	std::string posvar = (pos_descriptor.empty() || stricmp(pos_descriptor.c_str(), "npt") == 0) ? "Position" : (std::string("Position.") +pos_descriptor);
	param_strs.push_back(posvar);
	param_strs.push_back("Scale");

	TianShanIce::ValueMap val_in, val_out;
	try
	{
		_serverSessCtx._purchase->getParameters(param_strs, val_in, val_out);
	}
	catch (const TianShanIce::BaseException& ex)
	{
		setError("getPosScaleFromApplication() access purchase[%s].getParameters() exception[%s]: %s", _serverSessCtx._purchaseID.c_str(), ex.ice_name().c_str(), ex.message.c_str());
		return false;
	}
	catch (const Ice::Exception& ex)
	{
		setError("getPosScaleFromApplication() access purchase[%s].getParameters() exception[%s]", _serverSessCtx._purchaseID.c_str(), ex.ice_name().c_str());
		return false;
	}
	catch (...)
	{
		setError("getPosScaleFromApplication() access purchase[%s].getParameters() unknown exception", _serverSessCtx._purchaseID.c_str());
		return false;
	}

	if (val_out.end() != val_out.find(posvar) && ::TianShanIce::vtStrings == val_out[posvar].type)
		pos = val_out[posvar].strs[0];

	if (val_out.end() != val_out.find("Scale") && ::TianShanIce::vtStrings == val_out["Scale"].type)
		scale = val_out["Scale"].strs[0];

	handlerlog(ZQ::common::Log::L_INFO, HANDLERLOGFMT(SsmMethodHandler, "getPosScaleFromApplication() pos=%s; scale=%s"), pos.c_str(), scale.c_str());

	return true;
}

bool SsmMethodHandler::calculatePlaylistPos(OUT ::Ice::Int& userCtrlNum, OUT ::Ice::Int& offset, ::Ice::Int& from, const std::string pos, const std::string& pos_descriptor /*= "npt"*/)
{
	handlerlog(ZQ::common::Log::L_DEBUG, HANDLERLOGFMT(SsmMethodHandler, "calculatePlaylistPos(), pos_descriptior=%s"), pos_descriptor.c_str());
	userCtrlNum = offset = 0; // clean the outputs first
	from =1;

	if (!getPurchase())
	{
		handlerlog(ZQ::common::Log::L_ERROR, HANDLERLOGFMT(SsmMethodHandler, "calculatePlaylistPos() failed to address purchase"));
		return false;
	}

	std::vector<std::string> expected_params;
	expected_params.push_back("UserCtrlNum");
	expected_params.push_back("Offset");
	expected_params.push_back("StartPos");

	::TianShanIce::ValueMap val_in, val_out;
	if (!pos.empty())
	{
		::TianShanIce::Variant value;
		value.type = ::TianShanIce::vtStrings;
		value.bRange = false;
		value.strs.push_back(pos);

		/*std::string posvar = (pos_descriptor.empty() || 0==pos_descriptor.compare("npt")) ? "Position" : (std::string("Position.") +pos_descriptor);*/
		std::string posvar = (pos_descriptor.empty() || stricmp(pos_descriptor.c_str(), "npt") == 0) ? "Position" : (std::string("Position.") +pos_descriptor);
		val_in[posvar] = value;
	}

	try
	{
		_serverSessCtx._purchase->getParameters(expected_params, val_in, val_out);
	}
	catch (const TianShanIce::BaseException& ex)
	{
		setError("calculatePlaylistPos() invoke purchase[%s].getParameters() exception[%s]: %s", _serverSessCtx._purchaseID.c_str(), ex.ice_name().c_str(), ex.message.c_str());
		return false;
	}
	catch (const Ice::Exception& ex)
	{
		setError("calculatePlaylistPos() invoke purchase[%s].getParameters() exception[%s]", _serverSessCtx._purchaseID.c_str(), ex.ice_name().c_str());
		return false;
	}
	catch (...)
	{
		setError("calculatePlaylistPos() invoke purchase[%s].getParameters() unknown exception", _serverSessCtx._purchaseID.c_str());
		return false;
	}

	if (val_out.end() != val_out.find("UserCtrlNum") && ::TianShanIce::vtInts == val_out["UserCtrlNum"].type)
		userCtrlNum = val_out["UserCtrlNum"].ints[0];

	if (val_out.end() != val_out.find("Offset") && ::TianShanIce::vtInts == val_out["Offset"].type)
		offset = val_out["Offset"].ints[0];

	if (val_out.end() != val_out.find("StartPos") && ::TianShanIce::vtInts == val_out["StartPos"].type)
		from = val_out["StartPos"].ints[0];

	handlerlog(ZQ::common::Log::L_INFO, HANDLERLOGFMT(SsmMethodHandler, "calculatePlaylistPos() userCtrlNum=%x; offset=%d; from=%d"), userCtrlNum, offset, from);

	return true;
}

bool SsmTianShan::getPositionAndScaleForAnnounce2(WeiwooSession& ws_struct, Ice::Int& curPos)
{
	try
	{
		TianShanIce::ValueMap vMap;
		TianShanIce::Streamer::StreamPrx strmPrx = ws_struct._sessPrx->getStream();
		TianShanIce::Streamer::PlaylistPrx playlist = TianShanIce::Streamer::PlaylistPrx::checkedCast(strmPrx);
		playlist->getInfo(::TianShanIce::Streamer::infoSTREAMNPTPOS, vMap);
		if (vMap.end() != vMap.find("playposition") && vMap["playposition"].type == TianShanIce::vtInts && vMap["playposition"].ints.size() > 0)
			curPos= vMap["playposition"].ints[0];
	}
	catch (TianShanIce::BaseException& ex)
	{
		m_Log(ZQ::common::Log::L_ERROR, CLOGFMT(SsmMethodHandler, "getPositionAndScaleForAnnounce2() caught(%s: %s)"), ex.ice_name().c_str(), ex.message.c_str());
		return false;
	}
	catch (Ice::Exception& ex)
	{
		m_Log(ZQ::common::Log::L_ERROR, CLOGFMT(SsmMethodHandler, "getPositionAndScaleForAnnounce2() caught(%s)"), ex.ice_name().c_str());
		return false;
	}
	catch (...)
	{
		m_Log(ZQ::common::Log::L_ERROR, CLOGFMT(SsmMethodHandler, ""));
		return false;
	}
	return true;
}

bool SsmMethodHandler::getPosScaleFromStream(std::string& scale, std::string& pos)
{
	handlerlog(ZQ::common::Log::L_DEBUG, HANDLERLOGFMT(SsmMethodHandler, "getPosScaleFromStream()"));
	scale = pos = ""; // clean the outputs first

	if (!getStream())
	{
		handlerlog(ZQ::common::Log::L_ERROR, HANDLERLOGFMT(SsmMethodHandler, "getPosScaleFromStream() failed to address stream"));
		return false;
	}

	TianShanIce::ValueMap valMap;
	try
	{
		TianShanIce::Streamer::PlaylistPrx playlist = TianShanIce::Streamer::PlaylistPrx::checkedCast(_serverSessCtx._stream);
		playlist->getInfo(::TianShanIce::Streamer::infoPLAYPOSITION, valMap);
	}
	catch(const ::TianShanIce::BaseException& ex)
	{
		setError(HANDLERLOGFMT(SsmMethodHandler, "getPosScaleFromStream() failed to query playlist: exception[%s]:%s"), ex.ice_name().c_str(), ex.message.c_str());
		return false;
	}
	catch(const ::Ice::Exception& ex)
	{
		setError(HANDLERLOGFMT(SsmMethodHandler, "getPosScaleFromStream() failed to query playlist: exception[%s]"), ex.ice_name().c_str());
		return false;
	}
	catch(...)
	{
		setError(HANDLERLOGFMT(SsmMethodHandler, "getPosScaleFromStream() failed to query playlist: unknown exception"));
		return false;
	}

	if (valMap.end() != valMap.find("playposition") && ::TianShanIce::vtInts == valMap["playposition"].type)
	{
		char	szBuf[256];
		ZeroMemory(szBuf,sizeof(szBuf));
		snprintf(szBuf,255,"%d.%d", valMap["playposition"].ints[0] / 1000, valMap["playposition"].ints[0] % 1000);
		pos =szBuf;
	}

	if (valMap.end() != valMap.find("scale") && ::TianShanIce::vtStrings == valMap["scale"].type)
		scale = valMap["scale"].strs[0];

	handlerlog(ZQ::common::Log::L_INFO, HANDLERLOGFMT(SsmMethodHandler, "getPosScaleFromStream() pos=%s; scale=%s"), pos.c_str(), scale.c_str());

	return true;
}

IServerResponse* SsmMethodHandler::composeErrorResp(const char* statusCodeLine, const char* szNotice/* = NULL*/)
{
	if (NULL == _pResponse)
	{
		handlerlog(ZQ::common::Log::L_ERROR, HANDLERLOGFMT(SsmMethodHandler, "composeErrorResp() NULL response"));
		return NULL;
	}
	
	const char* notice = (NULL != szNotice) ? szNotice:_lastError.c_str();
	handlerlog(ZQ::common::Log::L_DEBUG, HANDLERLOGFMT(SsmMethodHandler, "composeErrorResp(%s)"), notice);

	_pResponse->printf_preheader(statusCodeLine);
	std::string toSettopNotice;
	if (_ssm._config._maxNoticeLen > 0)
	{
		toSettopNotice = ZQ::StringOperation::nLeftStr(notice, _ssm._config._maxNoticeLen);
		if (toSettopNotice.size() == _ssm._config._maxNoticeLen)
		{
			toSettopNotice[_ssm._config._maxNoticeLen - 3] = '.';
			toSettopNotice[_ssm._config._maxNoticeLen - 2] = '.';
			toSettopNotice[_ssm._config._maxNoticeLen - 1] = '.';
		}
	}
	else 
		toSettopNotice = notice;

	_pResponse->setHeader(HEADER_TS_NOTICE, toSettopNotice.c_str());
	_pResponse->setHeader(HEADER_SESSION, _clientSessId.c_str());

	if (NULL != _pReq)
		_pReq->setHeader(HEADER_TS_NOTICE, (char*) toSettopNotice.c_str());

	return _pResponse;
}

bool SsmMethodHandler::getPrivateDataFromSess()
{
	
	if(_serverSessCtx._sessPrx)
	{
		handlerlog(ZQ::common::Log::L_DEBUG,HANDLERLOGFMT(SsmMethodHandler,"get privatedata from weiwoo session"));
		try
		{
			_pvData.clear();
			_pvData = _serverSessCtx._sessPrx->getPrivateData();
		}
		catch (TianShanIce::BaseException& ex ) 
		{
			setError("catch an %s:%s when getPrivateData from weiwoo session",ex.ice_name().c_str(),ex.message.c_str());
			return false;
		}
		catch (Ice::Exception& ex) 
		{
			setError("catch an %s when getPrivateData from weiwoo session",ex.ice_name().c_str());
			return false;
		}
		handlerlog(ZQ::common::Log::L_INFO,HANDLERLOGFMT(SsmMethodHandler,"get privatedata from weiwoo session ok"));
	}
	else
	{
		setError("no available weiwoo session proxy");
		return false;
	}

	return true;
}
bool SsmMethodHandler::retrievePrivateData(const char* pKey ,std::string& strValue,bool bGetFromSess)
{
	if (! ( pKey&&strlen(pKey)>0 ) ) 
	{
		handlerlog(ZQ::common::Log::L_WARNING, HANDLERLOGFMT(SsmMethodHandler, "Null parameter when calling retrievePrivateData"));
		return false;
	}
	if (bGetFromSess) 
	{
		if (!getPrivateDataFromSess()) 
		{
			return false;
		}
	}
	TianShanIce::ValueMap::iterator it = _pvData.find(pKey);
	if ( it ==_pvData.end() || it->second.type != TianShanIce::vtStrings || it->second.strs.size() == 0) 
	{
		setError("can't find privateData with key[%s] and type[vtStrings]", pKey);
		return false;
	}
	strValue  = it->second.strs[0];
	return true;
}
bool SsmMethodHandler::retrievePrivateData(const char* pKey ,int& iValue,bool bGetFromSess)
{
	if (! ( pKey&&strlen(pKey)>0 ) ) 
	{
		handlerlog(ZQ::common::Log::L_WARNING, HANDLERLOGFMT(SsmMethodHandler, "Null parameter when calling retrievePrivateData"));
		return false;
	}
	if (bGetFromSess) 
	{
		if (!getPrivateDataFromSess()) 
		{
			return false;
		}
	}
	TianShanIce::ValueMap::iterator it = _pvData.find(pKey);
	if ( it ==_pvData.end() || it->second.type != TianShanIce::vtInts || it->second.ints.size() == 0) 
	{
		setError("can't find privateData with key[%s] and type[vtInts]");
		return false;
	}
	iValue  = it->second.ints[0];
	return true;
}
bool SsmMethodHandler::retrievePrivateData(const char* pKey ,long& lValue,bool bGetFromSess)
{
	if (! ( pKey&&strlen(pKey)>0 ) ) 
	{
		handlerlog(ZQ::common::Log::L_WARNING, HANDLERLOGFMT(SsmMethodHandler, "Null parameter when calling retrievePrivateData"));
		return false;
	}
	if (bGetFromSess) 
	{
		if (!getPrivateDataFromSess()) 
		{
			return false;
		}
	}
	
	TianShanIce::ValueMap::iterator it = _pvData.find(pKey);
	if ( it ==_pvData.end() || it->second.type != TianShanIce::vtLongs || it->second.lints.size() == 0) 
	{
		setError("can't find privateData with key[%s] and type[vtLongs]");
		return false;
	}
	lValue  = (long)it->second.lints[0];
	return true;
}
	
bool SsmMethodHandler::addPrivateData(const char* pKey ,  const char* pValue)
{
	if( !(pKey&&strlen(pKey)>0&&pValue&&strlen(pValue)>0) )
	{
		handlerlog(ZQ::common::Log::L_WARNING, HANDLERLOGFMT(SsmMethodHandler, "Null parameter when calling AddPrivateData"));
		return false;
	}
	::TianShanIce::Variant val;
	val.type = TianShanIce::vtStrings;
	val.strs.push_back(pValue);
	_pvData[pKey]=val;
	handlerlog(ZQ::common::Log::L_INFO, HANDLERLOGFMT(SsmMethodHandler, "Add string PrivateData %s:%s"),pKey,pValue);	
	return true;
}
bool SsmMethodHandler::addPrivateData(const char* pKey , const std::string& strValue)
{
	if( !(pKey&&strlen(pKey)>0) )
	{
		handlerlog(ZQ::common::Log::L_WARNING, HANDLERLOGFMT(SsmMethodHandler, "Null parameter when calling AddPrivateData"));
		return false;
	}
	::TianShanIce::Variant val;
	val.type = TianShanIce::vtStrings;
	val.strs.push_back(strValue);
	_pvData[pKey]=val;
	handlerlog(ZQ::common::Log::L_INFO, HANDLERLOGFMT(SsmMethodHandler, "Add string PrivateData %s:%s"),pKey,strValue.c_str());
	return true;
}
bool SsmMethodHandler::addPrivateData(const char* pKey , const int& iValue)
{
	if( !(pKey&&strlen(pKey)>0) )
	{
		handlerlog(ZQ::common::Log::L_WARNING, HANDLERLOGFMT(SsmMethodHandler, "Null parameter when calling AddPrivateData"));
		return false;
	}
	::TianShanIce::Variant val;
	val.type = TianShanIce::vtInts;
	val.ints.push_back(iValue);
	_pvData[pKey]=val;
	handlerlog(ZQ::common::Log::L_INFO, HANDLERLOGFMT(SsmMethodHandler, "Add int PrivateData %s:%d"),pKey,iValue);
	return true;
}
bool SsmMethodHandler::addPrivateData(const char* pKey , const long& lValue)
{
	if( !(pKey&&strlen(pKey)>0) )
	{
		handlerlog(ZQ::common::Log::L_WARNING, HANDLERLOGFMT(SsmMethodHandler, "Null parameter when calling AddPrivateData"));
		return false;
	}
	::TianShanIce::Variant val;
	val.type = TianShanIce::vtInts;
	val.lints.push_back(lValue);
	_pvData[pKey]=val;
	handlerlog(ZQ::common::Log::L_INFO, HANDLERLOGFMT(SsmMethodHandler, "Add int PrivateData %s:%d"),pKey,lValue);
	return true;
}
bool SsmMethodHandler::flushPrivateData(::TianShanIce::SRM::SessionPrx sessPrx)
{
	if (sessPrx)
	{
		try
		{
			sessPrx->setPrivateData2(_pvData);
			_pvData.clear();
			handlerlog(ZQ::common::Log::L_INFO, HANDLERLOGFMT(SsmMethodHandler, "flushPrivateData() successfully."));
		}
		catch (const TianShanIce::BaseException& ex)
		{
			handlerlog(ZQ::common::Log::L_ERROR, HANDLERLOGFMT(SsmMethodHandler, "flushPrivateData() catch an %s:%s "), ex.ice_name().c_str(), ex.message.c_str());
			return false;
		}
		catch (const Ice::Exception& ex)
		{
			handlerlog(ZQ::common::Log::L_ERROR, HANDLERLOGFMT(SsmMethodHandler, "flushPrivateData() catch an %s "), ex.ice_name().c_str());
			return false;
		}
		catch (...)
		{
			handlerlog(ZQ::common::Log::L_ERROR, HANDLERLOGFMT(SsmMethodHandler, "flushPrivateData() catch an unexpect error."));
			return false;
		}
		return true;
	}
	else
	{
		handlerlog(ZQ::common::Log::L_ERROR, HANDLERLOGFMT(SsmMethodHandler, "flushPrivateData() no weiwoo session is available."));
		return false;
	}
}

void SsmMethodHandler::setHeaderType()
{
	if (NULL ==_pReq)
		return;
	if (_serverSessCtx._headerType == SsmTianShan::RTSP_HEADER_TYPE_TIANSHAN)
		_pReq->setHeader(HEADER_TYPE, HEADER_TYPE_TIANSHAN);
	else 
		_pReq->setHeader(HEADER_TYPE, HEADER_TYPE_SEACHANGE);
}

