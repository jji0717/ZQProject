
#ifndef __SsmTianShan_H_
#define __SsmTianShan_H_

#include "TianShanDefines.h"
#include "Log.h"
#include "StreamSmithModule.h"
#include "descCode.h"
#include "thrdConnService.h"
#include "thrdCleanupSession.h"

#include "TsSRM.h"
#include "TsStreamer.h"
#include "TsApplication.h"

#include "EventChannel.h"
#include "FileLog.h"
#include "locks.h"

#include "./ZQResource.h"

#include <IceStorm/IceStorm.h>

#include <string>
#include <map>

// SeaChange announce code
#define SC_ANNOUNCE_ENDOFSTREAM				"2101"
#define SC_ANNOUNCE_ENDOFSTREAM_STRING		"\"End-of-Stream Reached\""
#define SC_ANNOUNCE_BEGINOFSTREAM			"2104"
#define SC_ANNOUNCE_BEGINOFSTREAM_STRING	"\"Beginning-of-Stream Reached\""
#define SC_ANNOUNCE_ITEMSTEPPED				"8803"
#define SC_ANNOUNCE_ITEMSTEPPED_STRING		"\"End-of-Item Reached\""
#define SC_ANNOUNCE_SCALECHANGED			"8801"
#define SC_ANNOUNCE_SCALECHANGED_STRING		"\"Scale Changed\""
#define SC_ANNOUNCE_STATECHANGED			""
#define SC_ANNOUNCE_STATECHANGED_STRING		""
#define SC_ANNOUNCE_STREAMEXIT				""
#define SC_ANNOUNCE_STREAMEXIT_STRING		""
#define SC_ANNOUNCE_PING					""
#define SC_ANNOUNCE_PING_STRING				""

// TianShan announce code
#define NUMERIC_CATEGORY
#ifdef NUMERIC_CATEGORY
#  define TS_ANNOUNCE_ENDOFSTREAM			"0001::0001 End-of-Stream Reached"
#  define TS_ANNOUNCE_BEGINOFSTREAM			"0001::0002 Beginning-of-Stream Reached"
#  define TS_ANNOUNCE_STATECHANGED			"0001::0003 State Changed"
#  define TS_ANNOUNCE_SCALECHANGED			"0001::0004 Scale Changed"
#  define TS_ANNOUNCE_ITEMSTEPPED			"0002::0001 Item Stepped"
#  define TS_ANNOUNCE_SESSIONTIMEOUT		"0100::0001 client-session-timeout"
#  define TS_ANNOUNCE_STREAMEXIT			""
#  define TS_ANNOUNCE_PING					""
#else
#  define TS_ANNOUNCE_ENDOFSTREAM			"Stream::0001 End-of-Stream Reached"
#  define TS_ANNOUNCE_BEGINOFSTREAM			"Stream::0002 Beginning-of-Stream Reached"
#  define TS_ANNOUNCE_STATECHANGED			"Stream::0003 State Changed"
#  define TS_ANNOUNCE_SCALECHANGED			"Stream::0004 Scale Changed"
#  define TS_ANNOUNCE_ITEMSTEPPED			"Playlist::0001 Item Stepped"
#  define TS_ANNOUNCE_SESSIONTIMEOUT		"Session::0001 client-session-timeout"
#  define TS_ANNOUNCE_STREAMEXIT			""
#  define TS_ANNOUNCE_PING					""
#endif // NUMERIC_CATEGORY
// default log file properties
#define DEFAULT_LOGFILE_NAME "C:\\TianShan\\log\\ssm_tianshan_s1.log"
#define DEFAULT_LOGFILE_NUM 10
#define DEFAULT_LOGFILE_SIZE 1024*1024*20 // 20MB
#define DEFAULT_LOGFILE_LEVEL 6
#define DEFAULT_LISTEN_EVENT_ENDPOINT "tcp -h 127.0.0.1 -p 4728"
#define	DEFAULT_RECONNECT_INTERVAL 10 // 10 seconds
#define	DEFAULT_SESSION_TIMEOUT 600 // 600 seconds

#define MY_BUFFER_SIZE 2048
#define TSLOG(_X)	"" _X 
#define HEADER_SERVER_STRING ZQ_PRODUCT_NAME_SHORT
#define VERSION_INFO ZQ_PRODUCT_NAME

#define CLIENTREQ_PRIVATEDATA_PREFIX "ClientRequest."

typedef std::map<std::string, std::string> STRINGMAP;
typedef STRINGMAP::iterator STRINGMAP_ITOR;
typedef STRINGMAP::const_iterator STRINGMAP_CITOR;

// -------------------------
// config structure
// -------------------------
struct CONFIG_TianShan_s1
{
	std::string _sessionManager;
	std::string _iceStorm;
	std::string _listenEvent;
	int _sessionTimeout;
	bool _useThreadPool;
	int _threadPoolSize;
	int _reconnectInterval;
	std::string _logFileName;
	int _logFileSize;
	int _logFileNum;
	int _logFileLevel;
	int _maxNoticeLen;
	std::map<std::string, std::string> _loadConfigMap;
	std::map<std::string, std::string> _iceConfigMap;
	int _getParammaxRequests;
	int _getParaminSeconds;
};

// -----------------------------
// class SsmTianShan
// -----------------------------
class SsmTianShan
{
	friend class SessionEventSinkI;
	
public:
	SsmTianShan();
	~SsmTianShan();

	void setConfigPath(std::string path);
	void doInit(IStreamSmithSite* pSite);
	void doUninit();
	
public:
	typedef enum
	{
		RTSP_HEADER_TYPE_TIANSHAN,
		RTSP_HEADER_TYPE_SEACHANGE
	} RTSP_HEADER_TYPE;

	typedef struct _tagWeiwooSession		
	{
		::TianShanIce::SRM::SessionPrx		_sessPrx;
		std::string							_sessID;

		::TianShanIce::Streamer::StreamPrx  _stream;
		std::string							_streamID;

		::TianShanIce::Application::PurchasePrx _purchase;
		std::string								_purchaseID;

		time_t								_lastAccessTime;
		RTSP_HEADER_TYPE					_headerType;
		std::string							_requestURI;
		std::string							_rangePrefix;
	} WeiwooSession;

	typedef std::map<std::string, WeiwooSession> ClientSessToWeiwooSessMap;
	typedef std::map<std::string, std::string>	 WeiwooSessToClientSessMap;
	typedef std::map<std::string, std::string>	 StreamToClientSessMap;

public:

	virtual RequestProcessResult	doFixupRequest(IStreamSmithSite* pSite, IClientRequestWriter* pReq);
	virtual RequestProcessResult	doContentHandle(IStreamSmithSite* pSite, IClientRequestWriter* pReq);
	virtual RequestProcessResult	doFixupResponse(IStreamSmithSite* pSite, IClientRequest* pReq);	

	virtual void					SSMH_EventSink(IStreamSmithSite* pSite, EventType Type, ZQ::common::Variant& params);
	virtual void					OnSessionDropped(const char* sessionId);

	bool SsmTianShan::openSessCtx(const std::string& clientSessId, WeiwooSession& sessCtx);
	bool SsmTianShan::saveSessCtx(const std::string& clientSessId, WeiwooSession& sessCtx);
	bool SsmTianShan::deleteSessCtx(const std::string& clientSessId, std::string reason = "");

public:

	std::string GetStreamStateString(TianShanIce::Streamer::StreamState state);
	bool ConnectSessionManager();
	bool ConnectIceStorm();
	bool getPositionAndScaleForAnnounce(WeiwooSession& ws_struct, std::string& scale, std::string& pos);
	bool getPositionAndScaleForAnnounce2(WeiwooSession& ws_struct, Ice::Int& curPos);
	
protected:
	bool LoadConfig();
	int ParseConfig();
	int ShowConfig();
	void setIceProperties(Ice::PropertiesPtr props);

public:
	CONFIG_TianShan_s1							_config;

	::Ice::CommunicatorPtr						m_communicator;
	TianShanIce::SRM::SessionManagerPrx			m_SessionManagerPrx;
	::Ice::ObjectAdapterPtr						m_OwnAdapter;
	TianShanIce::Events::EventChannelImpl::Ptr	m_evenChannelImplptr;
	IStreamSmithSite*							m_pSite;

	ZQ::common::FileLog							m_Log;
	ZQ::common::SysLog							m_sysLog;

	std::string									m_configFile;

	bool										m_bOwnAdapterCreated;

	ZQ::common::Mutex							_lockSessCtx;
	ClientSessToWeiwooSessMap					m_cwMap;
	/*WeiwooSessToClientSessMap					m_wcMap;*/

	ZQ::common::Mutex							_lockStreamIdx;
	StreamToClientSessMap						m_scMap;

	thrdConnService								m_thrdConnService;
	thrdCleanupSession							m_thrdCleanupSession;

	std::string									m_headerServer;
};

// -----------------------------
// class SsmMethodHandler
// -----------------------------
class SsmMethodHandler
{
public:
	SsmMethodHandler(SsmTianShan& ssm, IStreamSmithSite* pSite, IClientRequestWriter* pReq, const std::string& method="");
	virtual ~SsmMethodHandler();

	virtual RequestProcessResult process();

	const char* getClientSessionId();

	::TianShanIce::SRM::SessionPrx        getServerSession();
	TianShanIce::Streamer::StreamPrx      getStream();
	TianShanIce::Application::PurchasePrx getPurchase();
	void setHeaderType();

	bool getPosScaleFromApplication(std::string& scale, std::string& pos, const std::string& pos_descriptor="npt");
	bool getPosScaleFromStream(std::string& scale, std::string& pos);
	bool calculatePlaylistPos(OUT ::Ice::Int& userCtrlNum, OUT ::Ice::Int& offset, ::Ice::Int& from, const std::string pos, const std::string& pos_descriptor="npt");

	IServerResponse* composeErrorResp(const char* statusCodeLine, const char* szNotice = NULL);

	const char* setError(const char *fmt, ...);
	
	bool retrievePrivateData(const char* pKey ,std::string& strValue,bool bGetFromSess = false);
	bool retrievePrivateData(const char* pKey ,int& iValue,bool bGetFromSess = false);
	bool retrievePrivateData(const char* pKey ,long& lValue,bool bGetFromSess = false);
	bool getPrivateDataFromSess();
	bool addPrivateData(const char* pKey ,  const char* pValue);
	bool addPrivateData(const char* pKey , const std::string& strValue);
	bool addPrivateData(const char* pKey , const int& iValue);
	bool addPrivateData(const char* pKey , const long& lValue);
	bool flushPrivateData(::TianShanIce::SRM::SessionPrx sessPrx);

protected:
	TianShanIce::ValueMap	_pvData;
	SsmTianShan&			_ssm;
	std::string				_clientSessId;
	std::string             _cseq;
	std::string             _userAgent;
	IClientRequestWriter*	_pReq;
	IStreamSmithSite*		_pSite;
	SsmTianShan::WeiwooSession			_serverSessCtx;

	std::string				_lastError;
	std::string				_method;

	bool					_bCRPrivateDataCopied;

	IServerResponse*		_pResponse;
};

#define HANDLERLOGFMT(_C, _X) CLOGFMT(_C, "%s[%s] CSeq(%s): " _X), _method.c_str(), _clientSessId.c_str(), _cseq.c_str()
#ifndef handlerlog
#  define handlerlog _ssm.m_Log
#endif


// -----------------------------
// class SetupHandler
// -----------------------------
class SetupHandler : public SsmMethodHandler
{
public:
	SetupHandler(SsmTianShan& ssm, IStreamSmithSite* pSite, IClientRequestWriter* pReq)
		: SsmMethodHandler(ssm, pSite, pReq, "SETUP")
	{
	}

	~SetupHandler()
	{
		// for SETUP, never _ssm.saveSessCtx(_clientSessId, _serverSessCtx);
		// it is up to process() to call saveSessCtx if setup succeed
	}
	
	virtual RequestProcessResult process(std::string& retSession, ::TianShanIce::SRM::SessionPrx& retSessPrx);

protected:
};

// -----------------------------
// class PlayHandler
// -----------------------------
class PlayHandler : public SsmMethodHandler
{
public:
	PlayHandler(SsmTianShan& ssm, IStreamSmithSite* pSite,IClientRequestWriter* pReq)
		: SsmMethodHandler(ssm, pSite, pReq, "PLAY")
	{
	}

	virtual ~PlayHandler()
	{
		_ssm.saveSessCtx(_clientSessId, _serverSessCtx);
	}

	virtual RequestProcessResult process();

protected:
};

// -----------------------------
// class PauseHandler
// -----------------------------
class PauseHandler : public SsmMethodHandler
{
public:
	PauseHandler(SsmTianShan& ssm, IStreamSmithSite* pSite,IClientRequestWriter* pReq)
		: SsmMethodHandler(ssm, pSite, pReq, "PAUSE")
	{
	}

	virtual ~PauseHandler()
	{
		_ssm.saveSessCtx(_clientSessId, _serverSessCtx);
	}

	virtual RequestProcessResult process();

protected:
};

// -----------------------------
// class TeardownHandler
// -----------------------------
class TeardownHandler : public SsmMethodHandler
{
public:
	TeardownHandler(SsmTianShan& ssm, IStreamSmithSite* pSite,IClientRequestWriter* pReq)
		: SsmMethodHandler(ssm, pSite, pReq, "TEARDOWN")
	{
	}

	~TeardownHandler();

	virtual RequestProcessResult process();

protected:
};

// -----------------------------
// class GetParameterHandler
// -----------------------------
class GetParameterHandler : public SsmMethodHandler
{
public:
	GetParameterHandler(SsmTianShan& ssm, IStreamSmithSite* pSite, IClientRequestWriter* pReq)
		: SsmMethodHandler(ssm, pSite, pReq, "GET_PARAMETER")
	{
	}

	virtual ~GetParameterHandler()
	{
		_ssm.saveSessCtx(_clientSessId, _serverSessCtx);
	}

	virtual RequestProcessResult process();

protected:
};

// -----------------------------
// class PingHandler
// -----------------------------
class PingHandler : public SsmMethodHandler
{
public:
	PingHandler(SsmTianShan& ssm, IStreamSmithSite* pSite, IClientRequestWriter* pReq)
		: SsmMethodHandler(ssm, pSite, pReq, "PING")
	{
	}

	virtual ~PingHandler()
	{
		_ssm.saveSessCtx(_clientSessId, _serverSessCtx);
	}

	virtual RequestProcessResult process();

protected:
};

// -----------------------------
// class OptionHandler
// -----------------------------
class OptionHandler : public SsmMethodHandler
{
public:
	OptionHandler(SsmTianShan& ssm, IStreamSmithSite* pSite, IClientRequestWriter* pReq)
		: SsmMethodHandler(ssm, pSite, pReq, "OPTION")
	{
	}

	virtual ~OptionHandler()
	{
		_ssm.saveSessCtx(_clientSessId, _serverSessCtx);
	}

	virtual RequestProcessResult process();

protected:
};

#endif // __SsmTianShan_H__

