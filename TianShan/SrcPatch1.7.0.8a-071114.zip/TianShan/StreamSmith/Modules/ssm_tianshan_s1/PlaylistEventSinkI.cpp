// PlaylistEventSinkI.cpp: implementation of the PlaylistEventSinkI class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "PlaylistEventSinkI.h"
#include "StreamSmithModule.h"
#include "SsmTianShan.h"
#define			MyGlog						(*m_pLog)
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

PlaylistEventSinkI::~PlaylistEventSinkI()
{
}

PlaylistEventSinkI::PlaylistEventSinkI(SsmTianShan* ssm,ZQ::common::FileLog* pLog) : m_pLog(NULL), _ssm(NULL)
{
	m_pLog = pLog;
	_ssm = ssm;
}

void PlaylistEventSinkI::ping(::Ice::Long lv, const ::Ice::Current& ic)
{
}

void PlaylistEventSinkI::OnItemStepped(const ::std::string& proxy, const ::std::string& playlistId, 
									   ::Ice::Int userCtrlNum,::Ice::Int prevCtrlNum,
									   const ::TianShanIce::Properties& prty,
									   const ::Ice::Current& ic) const
{
	MyGlog(ZQ::common::Log::L_DEBUG, CLOGFMT(PlaylistEventSinkI, "Event(End-of-Item): [%s]"), proxy.c_str());
	IServerRequest *pSrvrRequest = NULL;

	try
	{
		char szBuf[MY_BUFFER_SIZE];
		uint16 szBufLen = MY_BUFFER_SIZE - 1;
		memset(szBuf, 0, MY_BUFFER_SIZE);
		::std::string clientSession;
		::TianShanIce::Properties tempMap;
		tempMap = prty;
		{
			ZQ::common::MutexGuard lk(_ssm->_lockStreamIdx);
			SsmTianShan::StreamToClientSessMap::iterator itSC ;
			itSC = _ssm->m_scMap.find(playlistId);
			if(itSC != _ssm->m_scMap.end())
			{
				clientSession = itSC->second;
				MyGlog(ZQ::common::Log::L_DEBUG, CLOGFMT(PlaylistEventSinkI, "Find stream: [%s] -> session: [%s] in scMap"), playlistId.c_str(), clientSession.c_str());
			}
			else
			{
				MyGlog(ZQ::common::Log::L_DEBUG, CLOGFMT(PlaylistEventSinkI, "Can't find stream: [%s] in scMap"), playlistId.c_str());
				return;
			}
		}
		
		SsmTianShan::WeiwooSession ws_struct;
		{
			ZQ::common::MutexGuard lk(_ssm->_lockSessCtx);
			SsmTianShan::ClientSessToWeiwooSessMap::iterator itCW = _ssm->m_cwMap.find(clientSession);
			if(itCW != _ssm->m_cwMap.end())
			{
				ws_struct = itCW->second;
				MyGlog(ZQ::common::Log::L_DEBUG, CLOGFMT(PlaylistEventSinkI, "Find session: [%s] 's context in cwMap."), clientSession.c_str());
			}
			else
			{
				MyGlog(ZQ::common::Log::L_ERROR, CLOGFMT(PlaylistEventSinkI, "Can't find session: [%s] 's context in cwMap"), clientSession.c_str());
				return;
			}
		}
		
		// DO: Create server request
		pSrvrRequest = _ssm->m_pSite->newServerRequest(clientSession.c_str());
		if(!pSrvrRequest)
		{
			MyGlog(ZQ::common::Log::L_ERROR, CLOGFMT(PlaylistEventSinkI, "fail to create server request by session: [%s]"), clientSession.c_str());
			return;
		}
		MyGlog(ZQ::common::Log::L_DEBUG, CLOGFMT(PlaylistEventSinkI, "Create server request by session: [%s] successfully."), clientSession.c_str());
		
		::std::string responseHead;
		responseHead = "ANNOUNCE " + ws_struct._requestURI + " RTSP/1.0";
		pSrvrRequest->printCmdLine(responseHead.c_str());
		pSrvrRequest->printHeader(HEADER_SESSION,(char*)clientSession.c_str());
		pSrvrRequest->printHeader(HEADER_SERVER, (char*) _ssm->m_headerServer.c_str());
		
		if (ws_struct._headerType == SsmTianShan::RTSP_HEADER_TYPE_SEACHANGE)
		{
			TianShanIce::Properties::const_iterator p_itor;
			p_itor = tempMap.find("prevItemName");
			std::string itemname;
			if (p_itor != tempMap.end())
				itemname = p_itor->second;
			SYSTEMTIME time;
			GetLocalTime(&time);
			snprintf(szBuf, MY_BUFFER_SIZE - 1, SC_ANNOUNCE_ITEMSTEPPED " " \
				SC_ANNOUNCE_ITEMSTEPPED_STRING " " "%04d%02d%02dT%02d%02d%02dZ" " " "\"%s\"" \
				, time.wYear, time.wMonth, time.wDay \
				, time.wHour, time.wMinute, time.wSecond, itemname.c_str());
			pSrvrRequest->printHeader(HEADER_SC_NOTICE,szBuf);
		}
		else if (ws_struct._headerType == SsmTianShan::RTSP_HEADER_TYPE_TIANSHAN)
		{
			pSrvrRequest->printHeader(HEADER_TS_NOTICE, (char*)TS_ANNOUNCE_ITEMSTEPPED);

			if (0 == stricmp(ws_struct._rangePrefix.c_str(), "clock"))
			{
			std::string pos, scale;		
			if (false == _ssm->getPositionAndScaleForAnnounce(ws_struct, scale, pos))
				MyGlog(ZQ::common::Log::L_ERROR,CLOGFMT(StreamEventSinkI, "Session: [%s], Stream: [%s], get position and scale failed."), clientSession.c_str(), ws_struct._streamID.c_str());
			snprintf(szBuf, MY_BUFFER_SIZE - 1, "BcastPos=%s;prev_item=%d;current_item=%d",pos.c_str(), prevCtrlNum ,userCtrlNum);
			}
			else 
			{
			Ice::Int curPos;
			if (true == _ssm->getPositionAndScaleForAnnounce2(ws_struct, curPos))
				snprintf(szBuf, MY_BUFFER_SIZE - 1, "npt=%d.%03d-;prev_item=%d;current_item=%d", curPos / 1000, curPos % 1000, prevCtrlNum ,userCtrlNum);
#pragma message(__MSGLOC__"TODO: return npt position")
			}
			pSrvrRequest->printHeader(HEADER_TS_NOTICEPARAM, szBuf);
		}
		pSrvrRequest->post();	
		if(NULL != pSrvrRequest)
			pSrvrRequest->release();
		MyGlog(ZQ::common::Log::L_INFO, CLOGFMT(PlaylistEventSinkI, "Session: [%s], Item-Stepped announce has been sent out."), clientSession.c_str());
	}
	catch(...)
	{
		if(NULL != pSrvrRequest)
			pSrvrRequest->release();
		MyGlog(ZQ::common::Log::L_ERROR, CLOGFMT(PlaylistEventSinkI, "Catch an exception when process item-stepped event."));
	}
}


