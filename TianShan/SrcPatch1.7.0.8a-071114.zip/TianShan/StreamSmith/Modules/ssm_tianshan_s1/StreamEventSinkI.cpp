// StreamEventSinkI.cpp: implementation of the StreamEventSinkI class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "StreamEventSinkI.h"
#include "StreamSmithModule.h"
#include "TianShanIce.h"
#include <string>
#include "SsmTianShan.h"
#define			MyGlog						(*m_pLog)

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

StreamEventSinkI::~StreamEventSinkI()
{
	/// 
}

StreamEventSinkI::StreamEventSinkI(SsmTianShan* ssm,ZQ::common::FileLog* pLog) : _ssm(NULL), m_pLog(NULL)
{
	_ssm =  ssm;
	m_pLog = pLog;
}

void StreamEventSinkI::ping(::Ice::Long lv, const ::Ice::Current& ic)
{
}

void StreamEventSinkI::OnEndOfStream(const ::std::string& proxy, const ::std::string& uid, const ::Ice::Current& ic)const
{
	MyGlog(ZQ::common::Log::L_INFO, CLOGFMT(StreamEventSinkI, "Event(End-Of-Stream): [%s]"), proxy.c_str());
	IServerRequest *pSrvrRequest = NULL;

	try
	{
		char szBuf[MY_BUFFER_SIZE];
		uint16 szBufLen = MY_BUFFER_SIZE - 1;
		memset(szBuf, 0, MY_BUFFER_SIZE);
		::std::string clientSession;
		
		{
			ZQ::common::MutexGuard lk(_ssm->_lockStreamIdx);
			SsmTianShan::StreamToClientSessMap::iterator itSC ;
			itSC = _ssm->m_scMap.find(uid);
			if(itSC != _ssm->m_scMap.end())
			{
				clientSession = itSC->second;
				MyGlog(ZQ::common::Log::L_DEBUG, CLOGFMT(StreamEventSinkI, "Find stream: [%s] -> session: [%s] in scMap"), uid.c_str(), clientSession.c_str());
			}
			else
			{
				MyGlog(ZQ::common::Log::L_DEBUG, CLOGFMT(StreamEventSinkI, "Can't find stream: [%s] in scMap"), uid.c_str());
				return;
			}
		}
		
		SsmTianShan::WeiwooSession ws_struct;
		{
			ZQ::common::MutexGuard lk(_ssm->_lockSessCtx);
			SsmTianShan::ClientSessToWeiwooSessMap::iterator itCW = _ssm->m_cwMap.find(clientSession);
			if(itCW != _ssm->m_cwMap.end())
			{
				ws_struct = itCW->second;
				MyGlog(ZQ::common::Log::L_DEBUG, CLOGFMT(StreamEventSinkI, "Find session: [%s] 's context in cwMap."), clientSession.c_str());
			}
			else
			{
				MyGlog(ZQ::common::Log::L_ERROR, CLOGFMT(StreamEventSinkI, "Can't find session: [%s] 's context in cwMap"), clientSession.c_str());
				return;
			}
		}
		
		// DO: Create server request
		pSrvrRequest = _ssm->m_pSite->newServerRequest(clientSession.c_str());
		if(!pSrvrRequest)
		{
			MyGlog(ZQ::common::Log::L_ERROR, CLOGFMT(StreamEventSinkI, "fail to create server request by session: [%s]"), clientSession.c_str());
			return;
		}
		MyGlog(ZQ::common::Log::L_DEBUG, CLOGFMT(StreamEventSinkI, "Create server request by session: [%s] successfully."), clientSession.c_str());
		
		::std::string responseHead;
		responseHead = "ANNOUNCE " + ws_struct._requestURI + " RTSP/1.0";
		pSrvrRequest->printCmdLine(responseHead.c_str());
		pSrvrRequest->printHeader(HEADER_SESSION,(char*)clientSession.c_str());
		pSrvrRequest->printHeader(HEADER_SERVER, (char*) _ssm->m_headerServer.c_str());
		
		if (ws_struct._headerType == SsmTianShan::RTSP_HEADER_TYPE_SEACHANGE)
		{
			SYSTEMTIME time;
			GetLocalTime(&time);
			snprintf(szBuf, MY_BUFFER_SIZE - 1, SC_ANNOUNCE_ENDOFSTREAM " " \
				SC_ANNOUNCE_ENDOFSTREAM_STRING " " "%04d%02d%02dT%02d%02d%02dZ \"Normal End\"" \
				, time.wYear, time.wMonth, time.wDay \
				, time.wHour, time.wMinute, time.wSecond);
			pSrvrRequest->printHeader(HEADER_SC_NOTICE,szBuf);
		}
		else 
		{
//			std::string pos, scale;
//		
//			if (false == _ssm->getPositionAndScaleForAnnounce(ws_struct, scale, pos))
//				MyGlog(ZQ::common::Log::L_ERROR,CLOGFMT(StreamEventSinkI, "Session: [%s], Stream: [%s], get position and scale failed."), clientSession.c_str(), ws_struct._streamID.c_str());

			pSrvrRequest->printHeader(HEADER_TS_NOTICE, (char*)TS_ANNOUNCE_ENDOFSTREAM);
			/*snprintf(szBuf, MY_BUFFER_SIZE - 1, "BcastPos=%s", pos.c_str());*/
//			if (0 == stricmp(cltSessCtx.rangePrefix.c_str(), "clock"))
//				pServerRequest->printHeader(HeaderTianShanNoticeParam, "BcastPos=");
//			else 
//				pServerRequest->printHeader(HeaderTianShanNoticeParam, "npt=");
			if (0 == stricmp(ws_struct._rangePrefix.c_str(), "clock"))
				snprintf(szBuf, MY_BUFFER_SIZE - 1, "BcastPos=");
			else 
				snprintf(szBuf, MY_BUFFER_SIZE - 1, "npt=");
			pSrvrRequest->printHeader(HEADER_TS_NOTICEPARAM, szBuf);
		}	
		pSrvrRequest->post();
		if(NULL != pSrvrRequest)
			pSrvrRequest->release();
		MyGlog(ZQ::common::Log::L_INFO, CLOGFMT(StreamEventSinkI, "Session: [%s], End-of-Stream announce has been sent out."), clientSession.c_str());
	}
	catch(...)
	{
		if(NULL != pSrvrRequest)
			pSrvrRequest->release();
		MyGlog(ZQ::common::Log::L_ERROR, CLOGFMT(StreamEventSinkI, "Catch an exception when process item-stepped event."));
	}
}

void StreamEventSinkI::OnBeginningOfStream(const ::std::string& proxy, const ::std::string& uid, const ::Ice::Current& ic)const
{
	MyGlog(ZQ::common::Log::L_INFO, CLOGFMT(StreamEventSinkI, "Event(Beginning-of-Stream): [%s]"), proxy.c_str());
	IServerRequest *pSrvrRequest = NULL;

	try
	{
		char szBuf[MY_BUFFER_SIZE];
		uint16 szBufLen = MY_BUFFER_SIZE - 1;
		memset(szBuf, 0, MY_BUFFER_SIZE);
		::std::string clientSession;
		{
			ZQ::common::MutexGuard lk(_ssm->_lockStreamIdx);
			SsmTianShan::StreamToClientSessMap::iterator itSC ;
			itSC = _ssm->m_scMap.find(uid);
			if(itSC != _ssm->m_scMap.end())
			{
				clientSession = itSC->second;
				MyGlog(ZQ::common::Log::L_DEBUG, CLOGFMT(StreamEventSinkI, "Find stream: [%s] -> session: [%s] in scMap"), uid.c_str(), clientSession.c_str());
			}
			else
			{
				MyGlog(ZQ::common::Log::L_DEBUG, CLOGFMT(StreamEventSinkI, "Can't find stream: [%s] in scMap"), uid.c_str());
				return;
			}
		}
		
		SsmTianShan::WeiwooSession ws_struct;
		{
			ZQ::common::MutexGuard lk(_ssm->_lockSessCtx);
			SsmTianShan::ClientSessToWeiwooSessMap::iterator itCW = _ssm->m_cwMap.find(clientSession);
			if(itCW != _ssm->m_cwMap.end())
			{
				ws_struct = itCW->second;
				MyGlog(ZQ::common::Log::L_DEBUG, CLOGFMT(StreamEventSinkI, "Find session: [%s] 's context in cwMap."), clientSession.c_str());
			}
			else
			{
				MyGlog(ZQ::common::Log::L_ERROR, CLOGFMT(StreamEventSinkI, "Can't find session: [%s] 's context in cwMap"), clientSession.c_str());
				return;
			}
		}
		
		// DO: Create server request
		pSrvrRequest = _ssm->m_pSite->newServerRequest(clientSession.c_str());
		if(!pSrvrRequest)
		{
			MyGlog(ZQ::common::Log::L_ERROR, CLOGFMT(StreamEventSinkI, "fail to create server request by session: [%s]"), clientSession.c_str());
			return;
		}
		MyGlog(ZQ::common::Log::L_DEBUG, CLOGFMT(StreamEventSinkI, "Create server request by session: [%s] successfully."), clientSession.c_str());
		
		::std::string responseHead;
		responseHead = "ANNOUNCE " + ws_struct._requestURI + " RTSP/1.0";
		pSrvrRequest->printCmdLine(responseHead.c_str());
		pSrvrRequest->printHeader(HEADER_SESSION,(char*)clientSession.c_str());
		pSrvrRequest->printHeader(HEADER_SERVER, (char*) _ssm->m_headerServer.c_str());
		
		if (ws_struct._headerType == SsmTianShan::RTSP_HEADER_TYPE_SEACHANGE)
		{
			SYSTEMTIME time;
			GetLocalTime(&time);
			snprintf(szBuf, MY_BUFFER_SIZE - 1, SC_ANNOUNCE_BEGINOFSTREAM " " \
				SC_ANNOUNCE_BEGINOFSTREAM_STRING " " "%04d%02d%02dT%02d%02d%02dZ" \
				, time.wYear, time.wMonth, time.wDay \
				, time.wHour, time.wMinute, time.wSecond);
			pSrvrRequest->printHeader(HEADER_SC_NOTICE,szBuf);
		}
		else 
		{
			pSrvrRequest->printHeader(HEADER_TS_NOTICE, (char*)TS_ANNOUNCE_BEGINOFSTREAM);

			if (0 == stricmp(ws_struct._rangePrefix.c_str(), "clock"))
			{
			std::string pos, scale;		
			if (false == _ssm->getPositionAndScaleForAnnounce(ws_struct, scale, pos))
				MyGlog(ZQ::common::Log::L_ERROR,CLOGFMT(StreamEventSinkI, "Session: [%s], Stream: [%s], get position and scale failed."), clientSession.c_str(), ws_struct._streamID.c_str());
			snprintf(szBuf, MY_BUFFER_SIZE - 1, "BcastPos=%s", pos.c_str());
			}
			else 
			{
			Ice::Int curPos = 0;
			if (true == _ssm->getPositionAndScaleForAnnounce2(ws_struct, curPos))
				snprintf(szBuf, MY_BUFFER_SIZE - 1, "npt=%d.%03d-", curPos / 1000, curPos % 1000);
#pragma message(__MSGLOC__"TODO: return npt position")
			}
			pSrvrRequest->printHeader(HEADER_TS_NOTICEPARAM, szBuf);
		}	
		pSrvrRequest->post();	
		if(NULL != pSrvrRequest)
			pSrvrRequest->release();
		MyGlog(ZQ::common::Log::L_INFO, CLOGFMT(StreamEventSinkI, "Session: [%s], Begin-of-Stream announce has been sent out."), clientSession.c_str());
	}
	catch(...)
	{
		if(NULL != pSrvrRequest)
			pSrvrRequest->release();
		MyGlog(ZQ::common::Log::L_ERROR, CLOGFMT(StreamEventSinkI, "Catch an exception when process item-stepped event."));
	}
}

void StreamEventSinkI::OnSpeedChanged(const ::std::string& proxy, const ::std::string& uid, ::Ice::Float prevSpeed, ::Ice::Float currentSpeed, const ::Ice::Current& ic)const
{
	MyGlog(ZQ::common::Log::L_INFO, CLOGFMT(StreamEventSinkI, "Event(Scale Changed): [%s]"), proxy.c_str());
	IServerRequest *pSrvrRequest = NULL;

	try
	{
		if (prevSpeed == 0)
		{
			MyGlog(ZQ::common::Log::L_INFO, CLOGFMT(StreamEventSinkI, "Previous speed: %f, needn't send announce."), prevSpeed);
			return;
		}
		char szBuf[MY_BUFFER_SIZE];
		uint16 szBufLen = MY_BUFFER_SIZE - 1;
		memset(szBuf, 0, MY_BUFFER_SIZE);
		::std::string clientSession;
		{
			ZQ::common::MutexGuard lk(_ssm->_lockStreamIdx);
			SsmTianShan::StreamToClientSessMap::iterator itSC ;
			itSC = _ssm->m_scMap.find(uid);
			if(itSC != _ssm->m_scMap.end())
			{
				clientSession = itSC->second;
				MyGlog(ZQ::common::Log::L_DEBUG, CLOGFMT(StreamEventSinkI, "Find stream: [%s] -> session: [%s] in scMap"), uid.c_str(), clientSession.c_str());
			}
			else
			{
				MyGlog(ZQ::common::Log::L_DEBUG, CLOGFMT(StreamEventSinkI, "Can't find stream: [%s] in scMap"), uid.c_str());
				return;
			}
		}
		
		SsmTianShan::WeiwooSession ws_struct;
		{
			ZQ::common::MutexGuard lk(_ssm->_lockSessCtx);
			SsmTianShan::ClientSessToWeiwooSessMap::iterator itCW = _ssm->m_cwMap.find(clientSession);
			if(itCW != _ssm->m_cwMap.end())
			{
				ws_struct = itCW->second;
				MyGlog(ZQ::common::Log::L_DEBUG, CLOGFMT(StreamEventSinkI, "Find session: [%s] 's context in cwMap."), clientSession.c_str());
			}
			else
			{
				MyGlog(ZQ::common::Log::L_ERROR, CLOGFMT(StreamEventSinkI, "Can't find session: [%s] 's context in cwMap"), clientSession.c_str());
				return;
			}
		}
		
		// DO: Create server request
		pSrvrRequest = _ssm->m_pSite->newServerRequest(clientSession.c_str());
		if(!pSrvrRequest)
		{
			MyGlog(ZQ::common::Log::L_ERROR, CLOGFMT(StreamEventSinkI, "fail to create server request by session: [%s]"), clientSession.c_str());
			return;
		}
		MyGlog(ZQ::common::Log::L_DEBUG, CLOGFMT(StreamEventSinkI, "Create server request by session: [%s] successfully."), clientSession.c_str());
		
		::std::string responseHead;
		responseHead = "ANNOUNCE " + ws_struct._requestURI + " RTSP/1.0";
		pSrvrRequest->printCmdLine(responseHead.c_str());
		pSrvrRequest->printHeader(HEADER_SESSION,(char*)clientSession.c_str());
		pSrvrRequest->printHeader(HEADER_SERVER, (char*) _ssm->m_headerServer.c_str());
		
		if (ws_struct._headerType == SsmTianShan::RTSP_HEADER_TYPE_SEACHANGE)
		{
			snprintf(szBuf, MY_BUFFER_SIZE - 1, "%f", currentSpeed);
			pSrvrRequest->printHeader(HEADER_SCALE, szBuf);
			SYSTEMTIME time;
			GetLocalTime(&time);
			snprintf(szBuf, MY_BUFFER_SIZE - 1, SC_ANNOUNCE_SCALECHANGED " " \
				SC_ANNOUNCE_SCALECHANGED_STRING " " "%04d%02d%02dT%02d%02d%02dZ" \
				, time.wYear, time.wMonth, time.wDay \
				, time.wHour, time.wMinute, time.wSecond);
			pSrvrRequest->printHeader(HEADER_SC_NOTICE,szBuf);
		}
		else 
		{
			pSrvrRequest->printHeader(HEADER_TS_NOTICE, (char*)TS_ANNOUNCE_SCALECHANGED);

			if (0 == stricmp(ws_struct._rangePrefix.c_str(), "clock"))
			{
			std::string pos, scale;
//			std::string retscale_str;		
			if (false == _ssm->getPositionAndScaleForAnnounce(ws_struct, scale, pos))
				MyGlog(ZQ::common::Log::L_ERROR,CLOGFMT(StreamEventSinkI, "Session: [%s], Stream: [%s], get position and scale failed."), clientSession.c_str(), ws_struct._streamID.c_str());
			snprintf(szBuf, MY_BUFFER_SIZE - 1, "BcastPos=%s;Scale=%f", pos.c_str(), currentSpeed);
			}
			else 
			{
			Ice::Int curPos;
			if (true == _ssm->getPositionAndScaleForAnnounce2(ws_struct, curPos))
				snprintf(szBuf, MY_BUFFER_SIZE - 1, "npt=%d.%03d-;scale=%f", curPos / 1000, curPos % 1000, currentSpeed);
#pragma message(__MSGLOC__"TODO: return npt position")
			}

			pSrvrRequest->printHeader(HEADER_TS_NOTICEPARAM, szBuf);
		}	
		pSrvrRequest->post();	
		if(NULL != pSrvrRequest)
			pSrvrRequest->release();
		MyGlog(ZQ::common::Log::L_INFO, CLOGFMT(StreamEventSinkI, "Session: [%s], Scale-Changed announce has been sent out."), clientSession.c_str());
	}
	catch(...)
	{
		if(NULL != pSrvrRequest)
			pSrvrRequest->release();
		MyGlog(ZQ::common::Log::L_ERROR, CLOGFMT(StreamEventSinkI, "Catch an exception when process item-stepped event."));
	}
}

void StreamEventSinkI::OnStateChanged(const ::std::string& proxy, const ::std::string& uid, ::TianShanIce::Streamer::StreamState prevState, ::TianShanIce::Streamer::StreamState currentState, const ::Ice::Current& /* = ::Ice::Current */)const
{
#pragma message(__MSGLOC__"TODO: npt version")
	MyGlog(ZQ::common::Log::L_INFO, CLOGFMT(StreamEventSinkI, "Event(State Changed): [%s]"), proxy.c_str());
	IServerRequest *pSrvrRequest = NULL;

	try
	{
		char szBuf[MY_BUFFER_SIZE];
		uint16 szBufLen = MY_BUFFER_SIZE - 1;
		memset(szBuf, 0, MY_BUFFER_SIZE);
		::std::string clientSession;
		{
			ZQ::common::MutexGuard lk(_ssm->_lockStreamIdx);
			SsmTianShan::StreamToClientSessMap::iterator itSC ;
			itSC = _ssm->m_scMap.find(uid);
			if(itSC != _ssm->m_scMap.end())
			{
				clientSession = itSC->second;
				MyGlog(ZQ::common::Log::L_DEBUG, CLOGFMT(StreamEventSinkI, "Find stream: [%s] -> session: [%s] in scMap"), uid.c_str(), clientSession.c_str());
			}
			else
			{
				MyGlog(ZQ::common::Log::L_DEBUG, CLOGFMT(StreamEventSinkI, "Can't find stream: [%s] in scMap"), uid.c_str());
				return;
			}
		}
		
		SsmTianShan::WeiwooSession ws_struct;
		{
			ZQ::common::MutexGuard lk(_ssm->_lockSessCtx);
			SsmTianShan::ClientSessToWeiwooSessMap::iterator itCW = _ssm->m_cwMap.find(clientSession);
			if(itCW != _ssm->m_cwMap.end())
			{
				ws_struct = itCW->second;
				MyGlog(ZQ::common::Log::L_DEBUG, CLOGFMT(StreamEventSinkI, "Find session: [%s] 's context in cwMap."), clientSession.c_str());
			}
			else
			{
				MyGlog(ZQ::common::Log::L_ERROR, CLOGFMT(StreamEventSinkI, "Can't find session: [%s] 's context in cwMap"), clientSession.c_str());
				return;
			}
		}

		if (ws_struct._headerType == SsmTianShan::RTSP_HEADER_TYPE_SEACHANGE)
		{
			MyGlog(ZQ::common::Log::L_DEBUG, CLOGFMT(StreamEventSinkI, "SeaChange-Session: [%s] 's State-Changed announce needn't to sent out."), clientSession.c_str());
			return;
		}
		
		// DO: Create server request
		pSrvrRequest = _ssm->m_pSite->newServerRequest(clientSession.c_str());
		if(!pSrvrRequest)
		{
			MyGlog(ZQ::common::Log::L_ERROR, CLOGFMT(StreamEventSinkI, "fail to create server request by session: [%s]"), clientSession.c_str());
			return;
		}
		MyGlog(ZQ::common::Log::L_DEBUG, CLOGFMT(StreamEventSinkI, "Create server request by session: [%s] successfully."), clientSession.c_str());
		
		::std::string responseHead;
		responseHead = "ANNOUNCE " + ws_struct._requestURI + " RTSP/1.0";
		pSrvrRequest->printCmdLine(responseHead.c_str());
		pSrvrRequest->printHeader(HEADER_SESSION,(char*)clientSession.c_str());
		pSrvrRequest->printHeader(HEADER_SERVER, (char*) _ssm->m_headerServer.c_str());
		std::string pos, scale;
		std::string state;
		
		pSrvrRequest->printHeader(HEADER_TS_NOTICE, (char*)TS_ANNOUNCE_STATECHANGED);

		TianShanIce::Streamer::StreamPrx strmPrx = NULL;
		try
		{
			strmPrx = ws_struct._sessPrx->getStream();
		}
		catch(Ice::Exception& ex)
		{
			MyGlog(ZQ::common::Log::L_ERROR, CLOGFMT(StreamEventSinkI, "Catch an %s when get stream proxy."), ex.ice_name().c_str());
		}
		try
		{
			state = _ssm->GetStreamStateString(strmPrx->getCurrentState());
		}
		catch (TianShanIce::BaseException& ex)
		{
			MyGlog(ZQ::common::Log::L_ERROR, CLOGFMT(StreamEventSinkI, "Catch an %s:%s when get stream state."), ex.ice_name().c_str(), ex.message.c_str());
		}
		catch (Ice::Exception& ex)
		{
			MyGlog(ZQ::common::Log::L_ERROR, CLOGFMT(StreamEventSinkI, "Catch an %s when get stream state."), ex.ice_name().c_str());
		}
////////////////////////////////////////////////
		if (0 == stricmp(ws_struct._rangePrefix.c_str(), "clock"))
		{
		if (false == _ssm->getPositionAndScaleForAnnounce(ws_struct, scale, pos))
			MyGlog(ZQ::common::Log::L_ERROR,CLOGFMT(StreamEventSinkI, "Session: [%s], Stream: [%s], get position and scale failed."), clientSession.c_str(), ws_struct._streamID.c_str());		
		snprintf(szBuf, MY_BUFFER_SIZE - 1, "BcastPos=%s;presentation_state=%s", pos.c_str(), state.c_str());
		}
		else 
		{
		Ice::Int curPos;
		if (true == _ssm->getPositionAndScaleForAnnounce2(ws_struct, curPos))
			snprintf(szBuf, MY_BUFFER_SIZE - 1, "npt=%d.%03d-;presentation_state=%s", curPos / 1000, curPos % 1000, state.c_str());
		}
		
		
		pSrvrRequest->printHeader(HEADER_TS_NOTICEPARAM, szBuf);
		pSrvrRequest->post();	
		if(NULL != pSrvrRequest)
			pSrvrRequest->release();
		MyGlog(ZQ::common::Log::L_INFO, CLOGFMT(StreamEventSinkI, "Session: [%s], State-Changed announce has been sent out."), clientSession.c_str());
	}
	catch(...)
	{
		if(NULL != pSrvrRequest)
			pSrvrRequest->release();
		MyGlog(ZQ::common::Log::L_ERROR, CLOGFMT(StreamEventSinkI, "Catch an exception when process State-Changed event."));
	}
}

void StreamEventSinkI::OnExit(const ::std::string& proxy, const ::std::string& uid, ::Ice::Int nExitCode, const ::std::string& sReason, const ::Ice::Current& ic /*= ::Ice::Current()*/) const
{
}
