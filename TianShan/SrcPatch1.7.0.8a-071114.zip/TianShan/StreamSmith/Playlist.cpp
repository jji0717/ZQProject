
#include <ZQ_common_conf.h>
#include "Playlist.h"
#include "StreamSmithSite.h"
#include <stdarg.h>
#include <timeutil.h>

#include "VVXParser\VstrmProc.h"
#include "vvxParser\VvxParser.h"

#ifndef _RTSP_PROXY
	#include <StreamSmithConfig.h>
	extern StreamSmithConfig gStreamSmithConfig;
#endif


#ifdef _DEBUG
	#include "adebugmem.h"
#endif


#define NEW_SETSPEEDEX_LOGIC	1



extern "C"
{
#include <time.h>
}
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <stdarg.h>

//#define		PLSESSID(x,y) 	"[Playlist] SESSID(%s) ["#x"]\t"##y,_strGuid.c_str()
#define		PLSESSID(x,y) 	"[Playlist] SESSID(%s)Thread[%10u][%16s]\t"##y,_strGuid.c_str(),GetCurrentThreadId(),#x

namespace ZQ{
namespace StreamSmith {



// 5 sec for minimal preload, don't change, it was from test result
#define MIN_PRELOAD_TIME             (5000)
#define	CHANGE_DIRECTION_LIMITED		2
#define	REUPDATE_TIMER_TIME				200
#define	FAKE_TIMER_TIMECOUNT		((timeout64_t)-1)
// -----------------------------
// class Playlist
// -----------------------------


#define ABSOLUTEX(x) (x>0?x:-x)

const SPEED_IND	Playlist::SPEED_NORMAL = {  1, 1 };
const SPEED_IND	Playlist::SPEED_FF = {  2, 1 };
const SPEED_IND	Playlist::SPEED_REW = { -2, 1 };


unsigned long	Playlist::_cfgIdleToExpire = 1000000*1000;
void Playlist::ERRLOG(int level,char* fmt,...)
{
	char msg[1024];
	va_list args;	
	ZeroMemory(msg,sizeof(msg));
	va_start(args, fmt);
	vsprintf(msg,fmt, args);
	va_end(args);
	glog(level,msg);
	_lastError=msg;
}

VSTATUS Playlist::cbItemCompleted(HANDLE classHandle, PVOID cbParam, PVOID bufP, ULONG bufLen)
{
	glog(ZQ::common::Log::L_DEBUG, LOGFMT("Playlist::cbItemCompleted"));
	Playlist* pPlaylist = (Playlist*) cbParam;
	if (NULL == pPlaylist)
		return VSTRM_SUCCESS; // unrecognized callback

	PIOCTL_STATUS_BUFFER pStatusBLK = (PIOCTL_STATUS_BUFFER) bufP;	
		
	
	if(pStatusBLK->status==ERROR_SUCCESS /*&& pStatusBLK->status!=536870912 */)
	{
		pStatusBLK->status=VSTRM_SUCCESS;				
	}

	try
	{
		{
			bool bOK=true;
			{
				if(!ZQ::StreamSmith::StreamSmithSite::m_pPlayListManager->plExist(pPlaylist))
					return VSTRM_SUCCESS;
			}
			if(bOK)
				pPlaylist->OnItemCompleted(pStatusBLK, bufLen);	
		}
	}
	catch(...)
	{
		glog(Log::L_ERROR,"unexpect error when vstrm callback");
	}

	return VSTRM_SUCCESS;
}
VSTATUS Playlist::OnItemCompleted(PIOCTL_STATUS_BUFFER pStatusBlk, ULONG BlkLen)
{	
	ZQ::common::MutexGuard gd(_listOpLocker);
	if (_bCleared) 
	{
		return VSTRM_SUCCESS;
	}
	//-1073741800 address conflict
//#pragma message(__MSGLOC__"delete playlist if address conflict")
	if(pStatusBlk->status==-1073741800)
	{
		char szBuf[1024];
		ZeroMemory(szBuf,sizeof(szBuf));
		ERRLOG(Log::L_ERROR,PLSESSID(OnItemCompleted,"destroy playlist because address conflict with error description is %s"),
				_mgr._cls.getErrorText(pStatusBlk->status,szBuf,sizeof(szBuf)-1));
		//destroy();
#ifdef _ICE_INTERFACE_SUPPORT
		_strClearReason=_lastError;
		_iExitCode=-1;//exit abnormal
		DestroyPlaylistRequest* pRequest=new DestroyPlaylistRequest(_gThreadPool,m_plePxStr,_mgr.m_Adapter);
		if(pRequest)
		{
			pRequest->start();
		}
#else//_ICE_INTERFACE_SUPPORT
		destroy();
#endif//_ICE_INTERFACE_SUPPORT
		return VSTRM_SUCCESS;
	}

	//536870912  seekԽ��
//////////////////////////////////////////////////////////////////////////

	if(! ( IS_VSTRM_SUCCESS(pStatusBlk->status) ) )
	{//term abnormal
		char szBuf[1024];
		ZeroMemory(szBuf,sizeof(szBuf));
//#pragma message(__MSGLOC__"Fire Session abnormal expired event")
		ERRLOG(Log::L_ERROR,PLSESSID(OnItemCompleted,"session %u was terminate by system and error description is %s"),
				pStatusBlk->sessionId,_mgr._cls.getErrorText(pStatusBlk->status,szBuf,sizeof(szBuf)-1));	
		try
		{
			OnItemAbnormal(pStatusBlk->sessionId);
		}
		catch (...)
		{
		}
		try
		{
			if(!_bCleared)
			{
				glog(ZQ::common::Log::L_INFO,PLSESSID(OnItemCompleted,"session[%u] done,call VstrmSessExpired"),pStatusBlk->sessionId);
				OnVstrmSessExpired(pStatusBlk->sessionId,glog);
				//stepList(pStatusBlk->sessionId);
			}
		}
		catch (...) 
		{
		}
	}
	else
	{
		char szBuf[1024];
		ZeroMemory(szBuf,sizeof(szBuf));
		glog(Log::L_DEBUG,PLSESSID(OnItemCompleted,"session %u was terminate normarlly! and Status=%s"),
			pStatusBlk->sessionId,_mgr._cls.getErrorText(pStatusBlk->status,szBuf,sizeof(szBuf)-1));	
	}
	

	return VSTRM_SUCCESS;
}
Playlist::Playlist( StreamSmithSite* pSite,PlaylistManager& mgr, const ZQ::common::Guid& guid,
				   bool bFailOver,const std::vector<int>& boardIDs)
: _mgr(mgr), _itCurrent(listStart()), _itNext(listStart()), // _itNextCriticalStart(begin()),
_b1stPlayStarted(false), _bLongFilename(false),
_vstrmPortNum(0), _mastSessId(0), VstrmSessSink(mgr._sessmon),
_stampDone(0), _guid(guid)
{
	_bEnableEOT = true;
	_isGoodItemInfoData = true;
	_iExitCode=0;
	_bDontPrimeNext=false;
	m_iErrInfoCount=0;
	_isReverseStreaming=false;
#ifdef _ICE_INTERFACE_SUPPORT
	m_bCurrentSessionIsONLine=false;
	
#endif
	_bCleared=false;
	m_pStreamSite=pSite;
	endTimer64();

	memset(&_dvbAttrs, 0x00, sizeof(_dvbAttrs));
	memset(&_ioctrlparms, 0x00, sizeof(_ioctrlparms));
	memset(&_iostatus_u, 0x00, sizeof(_iostatus_u));

	_crntSpeed = SPEED_NORMAL;
	
	char	szBuf[128];
	_mgr.reg(*this);
	ZeroMemory(szBuf,sizeof(szBuf));
	_guid.toString(szBuf,sizeof(szBuf)-1);
	_strGuid=szBuf;
	glog(Log::L_DEBUG,"Playlist construct OK");

	_vstrmSessioIDForFailOver=0;
	if(!bFailOver)
	{
		if(boardIDs.size()<=0)
			_vstrmPortNum = _mgr.GetUnUsePort(-1);
		else
		{
			for(int i=0;i<(int)boardIDs.size();i++)
			{
				_vstrmPortNum=_mgr.GetUnUsePort(boardIDs[i]);
				if(_vstrmPortNum!=(ULONG)-1)
					break;
			}
		}
		//_vstrmPortNum = 100;
		if(_vstrmPortNum==(ULONG)-1)			
		{
			ERRLOG(Log::L_ERROR,PLSESSID(Playlist,"Can't get Unuse Port"));
		}
		else
		{
			glog(Log::L_DEBUG,PLSESSID(Playlist,"Get vstram Port port %u"),_vstrmPortNum);
		}
		
	}


	// Set the destination IP address
	setDestination("127.0.0.1", _vstrmPortNum+1000);

	// Set stream's current bit rate and maximum bitrate.
	setMuxRate(1000000, 1000000);

	//TODO: Set the program number
	setProgramNumber((USHORT)_vstrmPortNum+2);

	// add self to the play list manager
	
	_stampCreated = GetTickCount();
	_itNext=_itCurrent=_list.end();
	//////////////////////////////////////////////////////////////////////////	
	//////////////////////////////////////////////////////////////////////////		
	//updateTimer();
	glog(Log::L_DEBUG,PLSESSID(Playlist,"set playlist state to PLAYLIST_SETUP when playlist construct"));
	
	FireStateChanged(PLAYLIST_SETUP,false);
	//_currentStatus=PLAYLIST_SETUP;
#ifdef _ICE_INTERFACE_SUPPORT
	PlaylistAttr	attr;
	attr.playlistState=IPlaylist::PLAYLIST_SETUP;
	ZeroMemory(szBuf,sizeof(szBuf));
	_guid.toString(szBuf,sizeof(szBuf));
	attr.Guid=szBuf;
	attr.vstrmPort=_vstrmPortNum;
	attr.currentCtrlNum=0;
//	DWORD	storeTimeTest=GetTickCount();
//	_mgr.addNewPlaylistIntoFailOver(szBuf,attr);
//	_mgr.UpdatePlaylistFailStore(this,true,false);	
//	glog(Log::L_DEBUG,PLSESSID("addNewPlaylistIntoFailOver run time=%d"),GetTickCount()-storeTimeTest);
#endif

	///��list��������һ��dummy�����Ϳ��԰�_list.begin()����һ����־������_list.end()һ��
	Item	itemDummy;
	itemDummy.userCtrlNum=INVALID_CTRLNUM;
	_list.push_back(itemDummy);
	_itCurrent=_itNext=listBegin();
	
	//mgr._sessmon.subscribe(*this);
	SubScribleSink();
	
	_lastErrCode=ERR_PLAYLIST_SUCCESS;
	 
	if (_vstrmPortNum>=0) 
	{
		glog(ZQ::common::Log::L_DEBUG,PLSESSID(Playlist,"construct playlist ok"));
	}
	else
	{
		glog(ZQ::common::Log::L_DEBUG,PLSESSID(Playlist,"construct playlist complete,but can't get vstrm port"));
	}
	SetTimerEx(gStreamSmithConfig.lPlaylistTimeout);
//	_ProgressGranularity=10*1000;

}
void Playlist::DumpListInfo(bool bOnlyAvailSessId)
{
	iterator it=listBegin();
	glog(Log::L_DEBUG,PLSESSID(DumpListInfo,"dump list information start with bOnlyAvailSessId=%d"),bOnlyAvailSessId);
	for(;it!=listEnd();it++)
	{
		if(bOnlyAvailSessId&&it->sessionId==0)
			continue;
		glog(Log::L_DEBUG,PLSESSID(DumpListInfo,"CtrlNum=%u filename=%s criticalStart=%u stampLoad=%u stampLaunched=%u stampUnload=%u sessionId=%u"),
					it->userCtrlNum,it->objectName.string,it->criticalStart,it->stampLoad,
					it->stampLaunched,it->stampUnload,it->sessionId);
	}
	glog(Log::L_DEBUG,PLSESSID(DumpListInfo,"dump list information end"));
}
void Playlist::ClearAllResource()
{
	{
		ZQ::common::MutexGuard gd(_listOpLocker);	
		endTimer64();
		if(!_bCleared)
		{
			_bCleared=true;
		}
		else
		{
			_mgr.unreg(*this);
			return;
		}
		glog(Log::L_DEBUG,PLSESSID(ClearAllResource,"set playlist state to PLAYLIST_STOP because clear all resource"));
		if(!isCompleted())
		{
			glog(Log::L_DEBUG,PLSESSID(ClearAllResource,"current item CtrlNum=%u and fileName=%s"),
											_itCurrent->userCtrlNum,_itCurrent->objectName.string);
		}
		DumpListInfo();
		FireStateChanged(PLAYLIST_STOP);
		//_currentStatus=PLAYLIST_STOP;

		// TODO: pause current element first		
		clear_pending(true);
		DumpListInfo();
		glog(Log::L_DEBUG,PLSESSID(ClearAllResource,"Unload itnext item"));
		unloadEx(_itNext);		
		

		flush_expired();		
		DumpListInfo();		
		glog(Log::L_DEBUG,PLSESSID(ClearAllResource,"Unload current item"));
		unloadEx(_itCurrent);
		//_list.clear();
		if(isReverseStreaming())
			_itCurrent=listStart();
		else
			_itCurrent=listEnd();		
	}
	glog(Log::L_DEBUG,PLSESSID(ClearAllResource,"unsubscrible this from sessmon"));
	UnSubScribleSink();

	
#ifdef _ICE_INTERFACE_SUPPORT
	_mgr.ClearFailOverInfo(_guid);
#endif	
	if(!_ResourceGuid.isNil())
	{	
		_mgr.FreeResource(_ResourceGuid);
		glog(Log::L_DEBUG,PLSESSID(ClearAllResource,"PlayList resource cleared"));	
	}

	{
		ZQ::common::MutexGuard gd(_listOpLocker);
		_list.erase(listBegin(),listEnd());
	}


	glog(Log::L_DEBUG,PLSESSID(ClearAllResource,"return port %d"),_vstrmPortNum);	
	_mgr.FreePortUsage(_vstrmPortNum);
	_lastErrCode=ERR_PLAYLIST_SUCCESS;

	//destroy ticket
	//set a fake time count to destroy ticket
	SetTimerEx(FAKE_TIMER_TIMECOUNT);

	{//fire event play list destroyed
		if(!m_pStreamSite)
		{
			m_pStreamSite=(StreamSmithSite*)StreamSmithSite::getDefaultSite();
		}		
		if(m_pStreamSite)
		{
			try
			{
#ifdef NEED_EVENTSINK_RAWDATA
				
#else
				ZQ::common::Variant	var;				
				var.set(EventField_PlaylistGuid,_strGuid);
				var.set(EventField_ExiReason,_strClearReason);
				var.set(EventField_ExitCode,_iExitCode);
				var.set(EventField_ClientSessId,m_strClientSessionID);
#endif			
				
				glog(Log::L_DEBUG,PLSESSID(ClearAllResource,"OnPlaylistDestroy()## E_PLAYLIST_DESTROYED is fired and reason is %s"),_strClearReason.c_str());
				m_pStreamSite->PostEventSink(E_PLAYLIST_DESTROYED,var,_strGuid);
			}
			catch (...)
			{
				ERRLOG(Log::L_ERROR,PLSESSID(ClearAllResource,"void Playlist::ClearAllResource()##unexpect exception was threw out when call PostEventSink with EVENTSINK_SESS_SPEEDCHANGED"));
			}
		}		
	}
	_mgr.unreg(*this);
	glog(Log::L_DEBUG,PLSESSID(ClearAllResource,"Clear OK"));

}
Playlist::~Playlist()
{	
	glog(Log::L_DEBUG,PLSESSID(~Playlist,"I am dead now!"));
}
const CtrlNum Playlist::insert(IPlaylist::Item& newitem)
{
	return insertEx(newitem._whereInsert,newitem._fileName,newitem._currentUserCtrlNum,
					newitem._inTimeOffset,newitem._outTimeOffset,newitem._var,
					newitem._criticalStart,newitem._spliceIn,newitem._spliceOut,
					newitem._forceNormal,newitem._flags);
}
const CtrlNum Playlist::insert(IN const CtrlNum inserCtrlnum, IN const char* fileName, IN const CtrlNum userCtrlNum,
								 IN const uint32 inTimeOffset, IN const uint32 outTimeOffset,
							IN const time_t criticalStart, const bool spliceIn, IN const bool spliceOut,
							IN const bool forceNormal, IN const uint32 flags)
{
	ZQ::common::Variant var;
	return insertEx(inserCtrlnum,fileName,userCtrlNum,
					inTimeOffset,outTimeOffset,var,
					criticalStart,spliceIn,spliceOut,
					forceNormal,flags);
}
int	ConvertStringIntoBinary(std::string& str,char buf[])
{
	if( str.size()%2 == 0 ) 
	{		
	}
	else
	{
		str="0"+str;
	}
	 
	std::transform(str.begin(), str.end(), str.begin(), toupper); 
	int iLen = str.length();
	char* pStr = (char*)str.c_str();
	unsigned char cData = 0;
	for(int i=0;i<iLen;i++)
	{
		if (isdigit(pStr[i])) 
		{
			cData=pStr[i] - '0';
		}
		else
		{
			cData=(pStr[i] - 'A')+10;
		}
		if(i%2==0)
		{
			buf[i/2]=cData<<4;
		}
		else
		{
			buf[i/2]|=cData;
		}
	}
	return i/2;
}
// list operations
const CtrlNum Playlist::insertEx(IN const CtrlNum inserCtrlnum, IN const char* fileName, IN const CtrlNum userCtrlNum,
							IN const uint32 inTimeOffset, IN const uint32 outTimeOffset, 
							IN ZQ::common::Variant& varData,
							IN const time_t criticalStart, const bool spliceIn, IN const bool spliceOut,
							IN const bool forceNormal, IN const uint32 flags)
//throw(PlaylistException)
{
	if (fileName==NULL || strlen(fileName) <=0)
	{
		_lastErrCode=ERR_PLAYLIST_INVALID_PARA;
		ERRLOG(Log::L_ERROR,PLSESSID(insert,"insert() invalid filename is passed in,return with error"));
		return INVALID_CTRLNUM;
		//throw PlaylistException("insert an element with illegal filename");
	}
	
	ZQ::common::Guard < ZQ::common::Mutex > guard(_listOpLocker,__MSGLOC__);
	
	glog(ZQ::common::Log::L_DEBUG,
						PLSESSID(insert,"Enter insert with filename[%s] userCtrlNum=[%d] criticalStart=[%d] "),
						fileName,userCtrlNum,criticalStart);


	// step 1. prepare the element node
	Item newElem; 
	std::string	strFullName;
#ifndef _CHECK_ITEM_TYPE_USE_NEWLOGIC

	strFullName = "\\vod\\";
	strFullName += fileName;

#else

	if( !_mgr.m_contentChecker.GetItemType(std::string(fileName),strFullName,_strGuid ) )
	{
		ERRLOG(ZQ::common::Log::L_ERROR,PLSESSID(insert,"Can't get Item type from content checker with item name is %s"),fileName);
		_lastErrCode=ERR_PLAYLIST_INVALID_PARA;
		return INVALID_CTRLNUM;
	}

#endif
	strncpy(newElem.objectName.string, strFullName.c_str(),sizeof(newElem.objectName.string));
	newElem.userCtrlNum = userCtrlNum;
	newElem.reservedFlags = flags;
	newElem.inTimeOffset = inTimeOffset;
	newElem.outTimeOffset = outTimeOffset;
	newElem.spliceIn = (spliceIn?1:0);
	newElem.spliceOut = (spliceOut?1:0);
	newElem.forceNormalSpeed = (forceNormal?1:0);
	newElem.criticalStart = (criticalStart>0 ? criticalStart:0);	
	strncpy(newElem._rawItemName,fileName,sizeof(newElem._rawItemName)-1);
	
	//analyze encryption data and set it into item data
	{
		//just for PID test
		if (varData.has(VSTRM_ITEM_PID)) 
		{
			newElem._bhasItemPID =  true;
			newElem._itemPID = (USHORT)varData[VSTRM_ITEM_PID];
		}
		else
		{
			newElem._bhasItemPID =  false;
		}

		//get ecm vendor
		int iEnableEcm = (int ) varData[ENCRYPTION_ENABLE];
		if(iEnableEcm > 0)
		{
			glog(ZQ::common::Log::L_INFO,PLSESSID(insert,"ECM is enabled,analyze ecm data"));			
			newElem._bEnableEcm = true;
			int iecmVendor = (int)varData[ENCRYPTION_VENDOR];
			newElem._encryptionData.vendor = (VSTRM_ENCRYPTION_VENDOR)iecmVendor ; 
			glog(ZQ::common::Log::L_INFO,PLSESSID(insert,"ECM DATA : Vendor [%d] < MOTOROLA [%d] >"),iecmVendor,VSTRM_ENCRYPTION_VENDOR_MOTOROLA);

			int iecmPID = (int)varData[ENCRYPTION_ECM_PID];
			newElem._encryptionData.ecmPid = iecmPID;
			glog(ZQ::common::Log::L_INFO,PLSESSID(insert,"ECM DATA : PID [%d]"),iecmPID);

			int iecmCycle1 = (int)varData[ENCRYPTION_CYCLE1];
			newElem._encryptionData.Cycle1 = iecmCycle1;
			glog(ZQ::common::Log::L_INFO,PLSESSID(insert,"ECM DATA : ecm cycle 1 [%d]"),iecmCycle1);

			int iecmCycle2 = (int) varData[ENCRYPTION_CYCLE2];
			newElem._encryptionData.Cycle2 = iecmCycle2;
			glog(ZQ::common::Log::L_INFO,PLSESSID(insert,"ECM DATA : ecm cycle 2 [%d]"),iecmCycle2);

			int iecmFreq1 = (int) varData[ENCRYPTION_FREQ1];
			newElem._encryptionData.Freq1 = iecmFreq1;
			glog(ZQ::common::Log::L_INFO,PLSESSID(insert,"ECM DATA : ecm freq 1 [%d]"),iecmFreq1);

			int iecmFreq2 = (int) varData[ENCRYPTION_FREQ2];
			newElem._encryptionData.Freq2 = iecmFreq2;
			glog(ZQ::common::Log::L_INFO,PLSESSID(insert,"ECM DATA : ecm freq 2 [%d]"),iecmFreq2);

			int iecmDataCount = (int) varData[ENCRYPTION_DATACOUNT];
			glog(ZQ::common::Log::L_INFO,PLSESSID(insert,"ECM DATA : ecm data count [%d]"),iecmDataCount);

			newElem._iEcmDataCount = iecmDataCount;
			{
				ZQ::common::Variant& varEcmData = (ZQ::common::Variant&)varData[ENCRYPTION_DATAPREFIX];
				char	szEcmDataName[256];
				for(int iCount =0 ; iCount <iecmDataCount ; iCount ++)
				{
					sprintf(szEcmDataName,"%s%d",ENCRYPTION_DATAPREFIX,iCount);
					std::string	strData = (std::string)varEcmData[szEcmDataName];
					glog(ZQ::common::Log::L_INFO,PLSESSID(insert,"ECM DATA : ecm data [%s] and size [%d]"),
						strData.c_str(),strData.length());
					newElem._encryptionData.motoData[iCount].byteCount = 4+ConvertStringIntoBinary(strData,newElem._encryptionData.motoData[iCount].Message);
				}
			}
			
			{
				ZQ::common::Variant varPnOffsetData = (ZQ::common::Variant&)varData[ENCRYPTION_PNOFFSETPREFIX];
				char szPnOffsetName[256];
				for(int iCount=0; iCount<iecmDataCount ;iCount++)
				{
					sprintf(szPnOffsetName,"%s%d",ENCRYPTION_PNOFFSETPREFIX,iCount);
					newElem._encryptionData.motoData[iCount].ProgramNumberOffset = (int)varPnOffsetData[szPnOffsetName];
				}
			}			
		}
		else
		{
			newElem._bEnableEcm = false;
		}

	}

#ifndef _CHECK_ITEM_TYPE_USE_NEWLOGIC
	
	newElem._itemPlaytime = -1;
	newElem._itemBitrate  = -1;

#else//_CHECK_ITEM_TYPE_USE_NEWLOGIC
	
	_mgr.m_contentChecker.GetItemAttribute(std::string(fileName),newElem._itemPlaytime,newElem._itemBitrate,_strGuid);

#endif//_CHECK_ITEM_TYPE_USE_NEWLOGIC
	glog(ZQ::common::Log::L_INFO,PLSESSID(insert,"get item attribute with ItemName %s and PlayTime is %d bitRate is %d"),
											fileName,newElem._itemPlaytime,newElem._itemBitrate);
	//TODO: associate the element's length, bitrate with the given filename
	
	iterator where=findUserCtrlNum(inserCtrlnum);
	// step 1. test if the location about to insert is at a allowed place
	if (where <listBegin() || where > listEnd())
	{
		_lastErrCode=ERR_PLAYLIST_INVALID_PARA;
		ERRLOG(Log::L_ERROR,PLSESSID(insert,"insert an element out of the range of list"));
		return INVALID_CTRLNUM;
		//throw PlaylistException("insert an element out of the range of list");
	}

	if(! ( _currentStatus ==PLAYLIST_SETUP || _currentStatus==PLAYLIST_STOP ) )
	{
		//�����������ڲ��ŵ�item��Ԥ��load��item֮������µ�item
//		if ( (!isReverseStreaming()&&where==_itNext) || (isReverseStreaming() && where ==_itCurrent ) )
//			//if (where < _itNext)
//		{
//			ERRLOG(Log::L_ERROR,PLSESSID("could not insert element before playing or preloaded element"));
//			return INVALID_CTRLNUM;
//			//throw PlaylistException("could not insert element before playing or preloaded element");
//		}
//		ERRLOG(Log::L_ERROR,PLSESSID("could not insert element before playing or preloaded element"));
//			return INVALID_CTRLNUM;
		if(!isReverseStreaming())
		{//����Streaming
			if(_itNext!=listEnd() && where==_itNext)
			{
				_lastErrCode=ERR_PLAYLIST_INVALIDSTATE;
				ERRLOG(Log::L_ERROR,PLSESSID(insert,"could not insert element before playing or preloaded element"));
				return INVALID_CTRLNUM;
			}
		}
		else
		{//����Streaming
			if(_itNext!=listStart() && where ==_itCurrent)
			{
				_lastErrCode=ERR_PLAYLIST_INVALIDSTATE;
				ERRLOG(Log::L_ERROR,PLSESSID(insert,"could not insert element before playing or preloaded element"));
				return INVALID_CTRLNUM;
			}
		}
	}

	// step 3, do the inserting
	

	static ULONG sCtrlId_ =0;  // global internal control id seed
	newElem.intlCtrlNum = sCtrlId_++;

	// step 3.1 back up the old location of _itCurrent, _itNext, _itNextCriticalStart
	//������Ҫ����Դ�streaming�ķ���
	ULONG crntSeqNum = INVALID_CTRLNUM, nextSeqNum =INVALID_CTRLNUM, nextStartSeqNum=INVALID_CTRLNUM;
	if (_itCurrent>=listBegin() && _itCurrent <listEnd())
		crntSeqNum = _itCurrent->intlCtrlNum;

	if (_itNext>listStart() && _itNext <listEnd())
		nextSeqNum = _itNext->intlCtrlNum;
	
	
	bool isLastItem= (bool)(_itNext==listEnd()||_itNext==listStart());

	// step 3.2 do the insert
	const_iterator ret = _list.insert(where, newElem);
	
	///Check if current item is the last item 

	// step 3.3 restore where the iterators were
	if (INVALID_CTRLNUM != crntSeqNum)
	{
		_itCurrent = findInternalCtrlNum(crntSeqNum);
	}
	else
	{
		_itCurrent = listBegin();
	}

	if (INVALID_CTRLNUM != nextSeqNum)
	{
		_itNext = findInternalCtrlNum(nextSeqNum);
	}
	else
	{
		if(isReverseStreaming())
		{
			_itNext= _itCurrent>listStart() ?_itCurrent-1:listStart();
		}
		else
		{
			_itNext=_itCurrent<listEnd() ?_itCurrent+1:listEnd();
		}
		//_itNext = listBegin();
	}

	//glog(Log::L_DEBUG,"Now PlayListSize=%d",size());;
	glog(Log::L_DEBUG,PLSESSID(insert,"Insert a item with CtrlNum=%u wheretoInsert=%u filename=%s and now pl size=%d"),
								userCtrlNum,inserCtrlnum,strFullName.c_str(), size());
	printList("Playlist::insert");
	

	endTimer64();
	_isGoodItemInfoData=true;
	SetTimerEx(gStreamSmithConfig.lPlaylistTimeout);
	if(_mgr._timeout ==TIMEOUT_INF)
		_mgr.wakeup();	
	if(isLastItem && PLAYLIST_PLAY==_currentStatus)
	{
		//glog(ZQ::common::Log::L_INFO,PLSESSID(insert,"last item ,call primeNext"));
		//primeNext();
#pragma message(__MSGLOC__"Call updateTimer instead of primeNext")
		//����ڱ���������insert�ᵼ�²��ܼ�ʱ�����µ�Item
		updateTimer();
	}
	else if(_currentStatus==PLAYLIST_PLAY)
	{
		//glog(ZQ::common::Log::L_INFO,PLSESSID(insert,"Update Timer"));
		updateTimer();
	}
#ifdef _ICE_INTERFACE_SUPPORT
	_mgr.UpdatePlaylistFailStore(this,true,true);
#endif	
	_lastErrCode=ERR_PLAYLIST_SUCCESS;

	glog(ZQ::common::Log::L_INFO,PLSESSID(insert,"succesfully insert file[%s] userCtrlNum[%d]"),fileName,userCtrlNum);

	return ret->userCtrlNum;
}

const CtrlNum	Playlist::push_back(IPlaylist::Item& item)
{
//	return push_back(item._fileName,item._currentUserCtrlNum,item._inTimeOffset,
//					item._outTimeOffset,item._var item._criticalStart,
//					item._spliceIn,item._spliceOut,
//					item._forceNormal,item._flags);
	CtrlNum	 ctrl=INVALID_CTRLNUM;
	return insertEx(ctrl, item._fileName, item._currentUserCtrlNum, 
					item._inTimeOffset, item._outTimeOffset,
					item._var,
					item._criticalStart, item._spliceIn, item._spliceOut,
					item._forceNormal, item._flags);
}
const CtrlNum Playlist::push_back(const char* fileName, 
									const uint32 userCtrlNum, const uint32 inTimeOffset, 
									const uint32 outTimeOffset, const time_t criticalStart, 
									const bool spliceIn, const bool spliceOut, 
									const bool forceNormal, const uint32 flags)
{
	CtrlNum	 ctrl=INVALID_CTRLNUM;
	return insert(ctrl, fileName, userCtrlNum, inTimeOffset, outTimeOffset, criticalStart, spliceIn, spliceOut, forceNormal, flags);
}
const char* printfUTCTime(time_t t)
{
	static char UTCTimeBuffer[256];
	ZeroMemory(UTCTimeBuffer,sizeof(UTCTimeBuffer));
	tm* tLocal = localtime (&t) ;
	strftime(UTCTimeBuffer,sizeof(UTCTimeBuffer)-1,"%Y:%m:%d-%H:%M:%S",tLocal);
	return UTCTimeBuffer;
}

void  Playlist::printList(const char* hints)
{
#if 1
	glog(ZQ::common::Log::L_DEBUG, PLSESSID(printList,"%s Playlist:"), (hints?hints:""));
	for (iterator it = listBegin(); it <listEnd(); it++)
		glog(ZQ::common::Log::L_DEBUG, PLSESSID(printList,"%c%c%c{intlCtrlNum:%u; file:%s; userCtrlNum:%u; sessId:%u criticalStart:%s}"), 
//		       ((!isCompleted() && it >=_itCurrent && it == _itNextCriticalStart) ? '-' : ' '), 
			   ((isCompleted() || it !=_itCurrent) ? ' ' : '>'), (0 !=it->sessionId ? '*' : ' '),
			   (0 !=it->criticalStart ? 'i' : ' '),
			   it->intlCtrlNum, 
			   it->objectName.string,
			   it->userCtrlNum,
			   it->sessionId,
			   (0 !=it->criticalStart ? printfUTCTime(it->criticalStart) : "<No Critical Start Time>") );
#endif // _DEBUG
}

//Playlist::const_iterator Playlist::flush_expired()
const CtrlNum		Playlist::flush_expired()
{
	ZQ::common::Guard < ZQ::common::Mutex > guard(_listOpLocker,__MSGLOC__);
	if (empty())
	{
		//return end();
		glog(Log::L_DEBUG,PLSESSID(flush_expired,"playlist  empty"));
		return INVALID_CTRLNUM;
	}

	glog(ZQ::common::Log::L_DEBUG,PLSESSID(flush_expired,"enter flush_expired"));
	ULONG crntSeqNum = _itCurrent->intlCtrlNum;
	if(!isReverseStreaming())
	{
		_list.erase(listBegin(), _itCurrent);
	}
	else
	{
		//_list.erase(listEnd(),)
		iterator	itTemp=_itCurrent;
		if(itTemp<listEnd())
		{
			_list.erase(itTemp+1,listEnd());
		}
	}
	// flush the elements before current	
	_itCurrent = findInternalCtrlNum(crntSeqNum);
	if(!isReverseStreaming())
	{
		_itNext=_itCurrent <listEnd() ?_itCurrent+1:listEnd();
	}
	else
	{
		_itNext=_itCurrent>listStart() ?_itCurrent-1:listStart();
	}
	if(_itNext!=listEnd() && _itNext!=listStart())
	{
		_lastErrCode=ERR_PLAYLIST_SUCCESS;
		glog(ZQ::common::Log::L_DEBUG,PLSESSID(flush_expired,"Leave flush_expired"));
		return _itNext->userCtrlNum;
	}
	else
	{
		glog(ZQ::common::Log::L_DEBUG,PLSESSID(flush_expired,"Leave flush_expired"));
		return INVALID_CTRLNUM;
	}
}

const bool Playlist::clear_pending(const bool includeInitedNext)
{
	if (isCompleted())
	{
		_lastErrCode=ERR_PLAYLIST_SUCCESS;
		return true;
	}

	ZQ::common::Guard < ZQ::common::Mutex > guard(_listOpLocker,__MSGLOC__);
	glog(ZQ::common::Log::L_DEBUG,PLSESSID(clear_pending,"Enter Clear_pending"));
	iterator it = listCurrent();
	CtrlNum curCtrlNum=it->intlCtrlNum;
	
	printList("Playlist::clear_pending");

	// move to the skip element
	if(!isReverseStreaming())
	{
		if (++it == listEnd())
			return true;
		iterator itTemp=it+1;
		for(;itTemp<listEnd();itTemp++)
		{
			if(itTemp->sessionId!=0)
			{				
				unloadEx(itTemp);
			}
		}		
		_list.erase(it+1, listEnd());
	}
	else
	{
		if(--it==listStart())
			return true;
		iterator itTemp=listBegin();
		for(;itTemp<it;itTemp++)
		{
			if(itTemp->sessionId!=0)
				unloadEx(itTemp);
		}
		_list.erase(listBegin(),it);
	}

	// clear up those after the skip element
	 
	printList("Playlist::clear_pending");

	// now clear the skip element upon its state
//	if (it->sessionId ==0)
//	{
//		_list.erase(it); // simply erase the skip element if it hasn't been loaded
//	}
//	else if (!includeInitedNext)
//	{
//		unloadEx(_itNext);
//		_list.erase(it);
//	}

	_itCurrent=findInternalCtrlNum(curCtrlNum);
	if(isReverseStreaming())
	{//rewind
		_itNext = _itCurrent>listStart() ?_itCurrent-1 :listStart();
	}
	else
	{//normal
		_itNext = (_itCurrent < listEnd()) ? (_itCurrent+1) : listEnd();
	}

	_lastErrCode=ERR_PLAYLIST_SUCCESS;
	glog(ZQ::common::Log::L_DEBUG,PLSESSID(clear_pending,"Leave Clear_pending"));
	return true;
}


//Playlist::const_iterator Playlist::erase(const_iterator where)
const CtrlNum	Playlist::erase(const CtrlNum ctrlNum)
{
	ZQ::common::Guard < ZQ::common::Mutex > guard(_listOpLocker,__MSGLOC__);
	
	glog(Log::L_DEBUG,PLSESSID(erase,"enter erase with CtrlNum=%u"),ctrlNum);
	iterator where=findUserCtrlNum(ctrlNum);

	if (where <= listStart() || where >=listEnd())
	{
		_lastErrCode=ERR_PLAYLIST_INVALID_PARA;
		ERRLOG(Log::L_ERROR,PLSESSID(erase,"Can't find item with user ctrl num=%u"),ctrlNum);
		return INVALID_CTRLNUM;
	}
	
	if (0 != where->sessionId)
	{
		_lastErrCode=ERR_PLAYLIST_INVALIDSTATE;
		ERRLOG(Log::L_ERROR,PLSESSID(erase,"Could not erase an ongiong element and CtrlNum=%u"),ctrlNum);
		return INVALID_CTRLNUM;
	}
//	if(isCompleted())
//	{
//		_lastErrCode=ERR_PLAYLIST_INVALID_PARA;
//#pragma message(__MSGLOC__"������Կ��ƶ˿ڣ���ô�����ǲ������ҲӦ�ÿ���ִ��erase����")
//		ERRLOG(Log::L_ERROR,PLSESSID("playlist complete"));
//		return INVALID_CTRLNUM;
//	}
	
	// flush the elements before current	
	ULONG crntSeqNum;
	bool bComplete = false;
	if (isCompleted())
	{
		bComplete =true;
	}
	else
	{
		crntSeqNum = _itCurrent->intlCtrlNum;
	}
	const_iterator ret = _list.erase(where);
	glog(Log::L_DEBUG,PLSESSID(erase,"erase item with CtrlNum=%d ok"),ctrlNum);
	if( bComplete )
	{
		if (isReverseStreaming()) 
		{
			_itCurrent = listStart();
		}
		else
		{
			_itCurrent = listEnd();
		}
	}
	else
	{
		_itCurrent = findInternalCtrlNum(crntSeqNum);
	}

	if(isReverseStreaming())
	{
		_itNext=_itCurrent>listStart() ?_itCurrent-1:listStart();
	}
	else
	{
		_itNext=_itCurrent<listEnd() ?_itCurrent+1:listEnd();
	}
	
//
//	if(_itNext!=listStart() && _itNext!=listEnd())
//	{
//		_lastErrCode=ERR_PLAYLIST_SUCCESS;
//		/*return _itNext->userCtrlNum;//.ret->userCtrlNum;*/
//	}
//	else
//	{
//		/*return INVALID_CTRLNUM;*/
//	}
	
	glog(Log::L_DEBUG,PLSESSID(erase,"Leave erase"));
	return 1;
}

bool Playlist::loadEx(iterator it,bool bNormalSpeed , long timeOffset)
{	
	if (it < listBegin() || it >= listEnd())
	{
		FireStateChanged(PLAYLIST_STOP);
		//_currentStatus=PLAYLIST_STOP;
		_lastErrCode=ERR_PLAYLIST_INVALIDSTATE;
		ERRLOG(Log::L_ERROR,PLSESSID(loadEx,"loadEx() iterator is out of range"));
		return false;
	}
	glog(Log::L_DEBUG,PLSESSID(loadEx,"enter LoadEx with item(%d) =%s bNormalSpeed=%d and Timeoffset=%d"),
								it->userCtrlNum , it->objectName.string,bNormalSpeed,timeOffset);	
	if (it->sessionId != 0)
	{
		_lastErrCode=ERR_PLAYLIST_INVALIDSTATE;
		//ERRLOG(Log::L_ERROR,PLSESSID(loadEx,"Current Session Is Playing"));
		glog(ZQ::common::Log::L_WARNING,PLSESSID(loadEx,"Current Session is playing"));
		return true;
	}

	IOCTL_LOAD_PARAMS			loadParams;
	DVB_SESSION_ATTR			dvbAttrs;

	memset(&loadParams, 0x00, sizeof(loadParams));
	memset(&dvbAttrs,0x00, sizeof(dvbAttrs));

	loadParams.FileLocal 			= TRUE;
	loadParams.Debug 				= TRUE;
	
	loadParams.Mask =
		LOAD_IOCTL_FILE_LOCAL
		| LOAD_IOCTL_PAUSE_ON_PLAY
		| LOAD_IOCTL_FRAME_COUNT
		| LOAD_IOCTL_MASTER_SESSION_ID
		| LOAD_IOCTL_PRE_BLACK_FRAMES
		| LOAD_IOCTL_POST_BLACK_FRAMES
		| LOAD_IOCTL_TIME_SKIP
		| LOAD_IOCTL_BYTE_SKIP
		| LOAD_IOCTL_SKIP_HEADER
		| LOAD_IOCTL_DEST_PORT_HANDLE
		| LOAD_IOCTL_TERMINATE_ON_EXIT
		| LOAD_IOCTL_PLAYLIST_FLAG
		| LOAD_IOCTL_OBJECT_NAME
		| LOAD_IOCTL_DEBUG
		| LOAD_IOCTL_SPECIFIED_DIRECTORY;

	loadParams.Debug = TRUE;
	loadParams.TimeSkip=timeOffset;

	// make a copy of common DVB attributes of the playlist
	memcpy(&dvbAttrs, &_dvbAttrs, sizeof(dvbAttrs));

	//////////////////////////////////////////////////////////////////////////

	// Init the parameter table
	LOAD_PARAM paramTableV2[] =
	{
		LOAD_CODE_OBJECT_NAME,		 		&loadParams.ObjectName,			0,
		LOAD_CODE_TERMINATE_ON_EXIT,		&loadParams.TerminateOnExit,	sizeof(loadParams.TerminateOnExit),						
		LOAD_CODE_TIME_SKIP,				&loadParams.TimeSkip,			sizeof(loadParams.TimeSkip),					
		LOAD_CODE_DEST_HANDLE,				&loadParams.DestPortHandle,		sizeof(loadParams.DestPortHandle),				
		LOAD_CODE_DEBUG,					&loadParams.Debug,				sizeof(loadParams.Debug),						
		LOAD_CODE_DVB_SESSION_ATTRIBUTES, 	&dvbAttrs,						sizeof(_dvbAttrs)	
	};
	
	

	// Set vod file spec
	strcpy ((PCHAR)&loadParams.ObjectName, it->objectName.string);
	paramTableV2[0].loadValueLength = strlen(it->objectName.string);
	
	// Set the output destination
	loadParams.DestPortHandle = _vstrmPortNum; //TODO: _vstrmPortNum.getNum();
	
	// Abort video on exit
	loadParams.TerminateOnExit = FALSE;
	
	// splice-in or cue-in
	dvbAttrs.spliceIn			= it->spliceIn;
	dvbAttrs.inTimeOffset		= it->inTimeOffset;

	// splice-out or cue-out
	dvbAttrs.spliceOut			= it->spliceOut;
	dvbAttrs.outTimeOffset		= it->outTimeOffset;
	
	// force normal speed
	dvbAttrs.forceNormalSpeed	= it->forceNormalSpeed;
	
	
	if (it->_bhasItemPID) 
	{
		dvbAttrs.VideoPid.New = dvbAttrs.VideoPid.Old = it->_itemPID;
	}
	if (it->_bEnableEcm) 
	{
		dvbAttrs.EcmPid.New = dvbAttrs.EcmPid.Old = it->_encryptionData.ecmPid;
	}	

	// Copy the parameters from the temporary location into the IOCTL structure for the call
	IOCTL_CONTROL_PARMS_LONG	parmsV2;
	memset(&parmsV2 , 0 ,sizeof(parmsV2));
	parmsV2.u.load.loadParamCount = sizeof (paramTableV2) / sizeof (LOAD_PARAM);
	for (int iParameterCount = 0; iParameterCount < parmsV2.u.load.loadParamCount; iParameterCount++)
	{
		parmsV2.u.load.loadParamArray[iParameterCount].loadCode 		= paramTableV2[iParameterCount].loadCode;	
		parmsV2.u.load.loadParamArray[iParameterCount].loadValueLength 	= paramTableV2[iParameterCount].loadValueLength;
		parmsV2.u.load.loadParamArray[iParameterCount].loadValueP		= paramTableV2[iParameterCount].loadValueP; 	
	}
	
	//add pre-encryption-data if needed
	if(it->_bEnableEcm)
	{
		parmsV2.u.load.loadParamArray[iParameterCount].loadCode		=	(USHORT)LOAD_CODE_ENCRYPTION_VENDOR;
		parmsV2.u.load.loadParamArray[iParameterCount].loadValueP	=	&(it->_encryptionData.vendor);
		parmsV2.u.load.loadParamArray[iParameterCount].loadValueLength=	sizeof(it->_encryptionData.vendor);
		iParameterCount++;

		parmsV2.u.load.loadParamArray[iParameterCount].loadCode		=	(USHORT)LOAD_CODE_ENCRYPTION_PID;
		parmsV2.u.load.loadParamArray[iParameterCount].loadValueP	=	&(it->_encryptionData.ecmPid);
		parmsV2.u.load.loadParamArray[iParameterCount].loadValueLength=	sizeof(it->_encryptionData.ecmPid);
		iParameterCount++;

		parmsV2.u.load.loadParamArray[iParameterCount].loadCode		=	(USHORT)LOAD_CODE_ENCRYPTION_CYCLE_1;
		parmsV2.u.load.loadParamArray[iParameterCount].loadValueP	=	&(it->_encryptionData.Cycle1);
		parmsV2.u.load.loadParamArray[iParameterCount].loadValueLength=	sizeof(it->_encryptionData.Cycle1);
		iParameterCount++;

		parmsV2.u.load.loadParamArray[iParameterCount].loadCode		=	(USHORT)LOAD_CODE_ENCRYPTION_CYCLE_2;
		parmsV2.u.load.loadParamArray[iParameterCount].loadValueP	=	&(it->_encryptionData.Cycle2);
		parmsV2.u.load.loadParamArray[iParameterCount].loadValueLength=	sizeof(it->_encryptionData.Cycle2);
		iParameterCount++;

		parmsV2.u.load.loadParamArray[iParameterCount].loadCode		=	(USHORT)LOAD_CODE_ENCRYPTION_FREQUENCY_1;
		parmsV2.u.load.loadParamArray[iParameterCount].loadValueP	=	&(it->_encryptionData.Freq1);
		parmsV2.u.load.loadParamArray[iParameterCount].loadValueLength=	sizeof(it->_encryptionData.Freq1);
		iParameterCount++;
		
		parmsV2.u.load.loadParamArray[iParameterCount].loadCode		=	(USHORT)LOAD_CODE_ENCRYPTION_FREQUENCY_2;
		parmsV2.u.load.loadParamArray[iParameterCount].loadValueP	=	&(it->_encryptionData.Freq2);
		parmsV2.u.load.loadParamArray[iParameterCount].loadValueLength=	sizeof(it->_encryptionData.Freq2);
		iParameterCount++;

		parmsV2.u.load.loadParamArray[iParameterCount].loadCode		=	(USHORT)LOAD_CODE_ENCRYPTION_DATA;
		parmsV2.u.load.loadParamArray[iParameterCount].loadValueP	=	&(it->_encryptionData.motoData);
		parmsV2.u.load.loadParamArray[iParameterCount].loadValueLength=	(it->_iEcmDataCount+1)*sizeof(it->_encryptionData.motoData[0]);
		iParameterCount++;
	}

	if ((it->_bhasItemPID)) 
	{
		parmsV2.u.load.loadParamArray[iParameterCount].loadCode		=	(USHORT)LOAD_CODE_VIDEO_PID;
		parmsV2.u.load.loadParamArray[iParameterCount].loadValueP	=	&(it->_itemPID);
		parmsV2.u.load.loadParamArray[iParameterCount].loadValueLength=	sizeof(it->_itemPID);
		iParameterCount++;
	}

	//Add this for new parameter entry
	parmsV2.u.load.loadParamCount =iParameterCount;

	
	
	// Tell the Vstrm Class Driver to load the session
	//TEST
	_status = VstrmClassControlSessionEx1(_mgr.classHandle(), 
											0,
											VSTRM_GEN_CONTROL_LOAD,
											&parmsV2, 
											sizeof(parmsV2), 
											cbItemCompleted, 
											(ULONG)this);
	

	// Save the session handle
	if (_status != VSTRM_SUCCESS)
	{
		it->sessionId 	= 0;					// just to be sure
		_ntstatus 	= GetLastError ();		// capture secondary error code (if any)
		char	szErrbuf[1024];
		ZeroMemory(szErrbuf,1024);	
		_lastErrCode=ERR_PLAYLIST_SERVER_ERROR;
		FireStateChanged(PLAYLIST_STOP);
		//_currentStatus=PLAYLIST_STOP;
		ERRLOG(Log::L_EMERG,PLSESSID(loadEx,"Can't load item with CtrlNum=%u and fileName= %s with error description is %s"),
									it->userCtrlNum,it->objectName.string,_mgr.getErrorText(_ntstatus,szErrbuf,1023));
		DumpItemInfo(it);
		//֪ͨ˵��ǰ��Item�������
		try
		{
			//OnItemDone(it,listEnd());
		}
		catch (...) 
		{
		}
	}
	else
	{
		glog(Log::L_DEBUG,PLSESSID(loadEx,"LoadEx item Successfully with CtrlNum=%u and fileName=%s and vstrm session ID=%d"),
					it->userCtrlNum,it->objectName.string, parmsV2.u.load.sessionId);
#if _USE_NEW_SESSION_MON
		RegisterSessID(parmsV2.u.load.sessionId);
#endif	
		DumpItemInfo(it);
		it->sessionId = parmsV2.u.load.sessionId;

		// stamp the execution
		it->stampLoad = GetTickCount();
		it->stampLaunched = it->stampUnload = it->stampLastUpdate =0;		

		_status = VstrmClassPrimeEx(_mgr.classHandle(), it->sessionId);
		if(_status!=VSTRM_SUCCESS)
		{
			char szErrbuf[1024];
			ERRLOG(Log::L_ERROR,PLSESSID(loadEx,"call VstrmClassPrimeEx fail and error string is %s"),
					_mgr.getErrorText(_status,szErrbuf,1023));
		}

		//////////////////////////////////////////////////////////////////////////
		_lastSessionID=it->sessionId;		
		glog(Log::L_DEBUG,PLSESSID(loadEx,"Load Item with CtrlNum=%u  and fileName=%s and vstrm sessionId=%u OK"),
				it->userCtrlNum,it->objectName.string,it->sessionId);
#ifdef _ICE_INTERFACE_SUPPORT
		//Ϊʲô��ʹ��it-listbegin()����Ϊ�п���������Load itemnext
		_currentItemDist=(int)(_itCurrent-listBegin());		
		_mgr.UpdatePlaylistFailStore(this,true,true);
#endif//_ICE_INTERFACE_SUPPORT
		if(bNormalSpeed)
			setSpeedEx(SPEED_NORMAL);
		printList("LoadEX::");
	}
	_lastErrCode=ERR_PLAYLIST_SUCCESS;
	glog(Log::L_DEBUG,PLSESSID(loadEx,"Leave LoadEx with  CtrlNum=%u fileName=%s"),
							it->userCtrlNum,it->objectName.string);
	return (_status == VSTRM_SUCCESS);
}
bool Playlist::LoadAndLaunch(iterator& it)
{
	bool bOK=true;
	bool bComplete=it<listEnd() && it>listStart();
	while ( bComplete && !loadEx(it) )
	{
		if(isReverseStreaming())
		{
			it--;
		}
		else
		{
			it++;
		}
		bComplete=it<listEnd() && it>listStart();
		bOK=false;
	}	
	return bOK;
}
__int64 Playlist::SeekStream(__int64 offset,IPlaylist::SeekStartPos pos)
{//return -1 if failed
	ZQ::common::Guard < ZQ::common::Mutex > guard(_listOpLocker,__MSGLOC__);
	glog(ZQ::common::Log::L_DEBUG,PLSESSID(SeekStream,"enter seekStream with offset=%I64d and startPos=%d"),offset,pos);
	//���ڵ�һ����������Ƿ���Ҫ��seekStream��ʱ�����»�ȡһ�����е�item��playTime
	CtrlNum seekToCtrlNum=INVALID_CTRLNUM;
	__int64 backupOffset = offset;
	if(pos == IPlaylist::SeekStartPos::SEEK_POS_BEGIN)
	{
		for(List::iterator it =listBegin() ; it!= listEnd(); it++)
		{
#ifndef	_CHECK_ITEM_TYPE_USE_NEWLOGIC
			if ( ( it->_itemPlaytime < 0 || it->_itemBitrate < 0 ) || ( size() > 1 && it == listEnd()-1 ) ) 
			{
				if(!_mgr.m_contentChecker.GetItemAttribute(it->_rawItemName,it->_itemPlaytime,it->_itemBitrate,_strGuid))
				{
					ERRLOG(ZQ::common::Log::L_ERROR,PLSESSID(SeekStream,"query item %s playtime and bitrate failed"),
						it->_rawItemName);
					return -1;
				}			
			}
			glog(ZQ::common::Log::L_INFO,PLSESSID(SeekStream,"query item [%s] ctrlNum [%u],get playtime is [%d] bitrate is [%d]"),
						it->_rawItemName,it->userCtrlNum,it->_itemPlaytime,it->_itemBitrate);
#else//_CHECK_ITEM_TYPE_USE_NEWLOGIC
			if(!_mgr.m_contentChecker.GetItemAttribute(it->_rawItemName,it->_itemPlaytime,it->_itemBitrate,_strGuid))
			{
				ERRLOG(ZQ::common::Log::L_ERROR,PLSESSID(SeekStream,"query item %s userCtrlNum[%u] ,get playtime and bitrate failed"),
											it->_rawItemName,it->userCtrlNum);
				return -1;
			}
			else
			{
				glog(ZQ::common::Log::L_DEBUG,PLSESSID(SeekStream,"query item %s userCtrlNum[%u] ,get playtime is %d bitrate is %d"),
											it->_rawItemName,it->userCtrlNum,it->_itemPlaytime,it->_itemBitrate);
			}
#endif//_CHECK_ITEM_TYPE_USE_NEWLOGIC

			if( offset < it->_itemPlaytime )
			{
				//ok find the Item,calculate the offset inside the item
				long itemOffset = (long)offset;
				glog(ZQ::common::Log::L_DEBUG,PLSESSID(SeekStream,"find the item with CtrlNum=%d filename=%s and InsideOffset=%d startpos=SEEK_POS_BEGIN"),
						it->userCtrlNum ,it->objectName.string,itemOffset);
				if(! SeekTo(it->userCtrlNum , itemOffset ,IPlaylist::SeekStartPos::SEEK_POS_BEGIN ))
					return -1;
				//���ص�ǰ��ʵ��offset
				__int64 retOffset = backupOffset - itemOffset;
				//Ȼ�����item�ڵ�ʵ��offset
				ESESSION_CHARACTERISTICS esessInfo;
				TIME_OFFSET	tOffset=0;
				if(!getVstrmSessInfo(_itCurrent->sessionId,esessInfo))
				{//call getVstrmSessInfo fail
					tOffset=_itCurrent->timeOffset;					
				}		
				else
				{//call getVstrmSessInfo Success
					SESSION_CHARACTERISTICS* pInfo=&(esessInfo.SessionCharacteristics);				
					tOffset=pInfo->PlayoutTimeOffset;					
				}
				retOffset+=tOffset;
				glog(ZQ::common::Log::L_ERROR,
					PLSESSID(SeekStream,"seekto %d ok , get totalOffset is  %I64d and itemoffset is %d"),
					retOffset,tOffset);
				
				return retOffset;				
			}
			offset -= it->_itemPlaytime;
		}
		ERRLOG(ZQ::common::Log::L_ERROR,PLSESSID(SeekStream,"Invalid parameter,Invalid offset =%I64d "),backupOffset);
		_lastErrCode = ERR_PLAYLIST_INVALID_PARA;
		return -1;
	}
	else if(pos == IPlaylist::SeekStartPos::SEEK_POS_END)
	{
		if(offset > 0)
		{
			ERRLOG(ZQ::common::Log::L_ERROR,PLSESSID(SeekStream,"Invalid offset,shoud be a positive value when start pos is SEEK_POS_END"));
			_lastErrCode= ERR_PLAYLIST_INVALID_PARA;
		}
		List::iterator it =listEnd();
		it--;
		offset = - offset;
		for( ; it!=listStart() ; it-- )
		{
#ifndef	_CHECK_ITEM_TYPE_USE_NEWLOGIC
			if ( ( it->_itemPlaytime < 0 || it->_itemBitrate < 0 ) || ( size() > 1 && it == listEnd()-1 ) ) 
			{
				if(!_mgr.m_contentChecker.GetItemAttribute(it->_rawItemName,it->_itemPlaytime,it->_itemBitrate,_strGuid))
				{
					ERRLOG(ZQ::common::Log::L_ERROR,PLSESSID(SeekStream,"query item %s userCtrlNum[%u] playtime and bitrate failed"),
													it->_rawItemName,it->userCtrlNum);
					return -1;
				}			
			}
			glog(ZQ::common::Log::L_INFO,PLSESSID(SeekStream,"query item [%s] userCtrlNum[%u],get playtime is [%d] bitrate is [%d]"),
									it->_rawItemName,it->userCtrlNum,it->_itemPlaytime,it->_itemBitrate);
#else//_CHECK_ITEM_TYPE_USE_NEWLOGIC
			if(!_mgr.m_contentChecker.GetItemAttribute(it->_rawItemName,it->_itemPlaytime,it->_itemBitrate,_strGuid))
			{
				ERRLOG(ZQ::common::Log::L_ERROR,PLSESSID(SeekStream,"query item %s userCtrlNum[%u] ,get playtime and bitrate failed"),
												it->_rawItemName,it->userCtrlNum);
				return -1;
			}
			else
			{
				glog(ZQ::common::Log::L_DEBUG,PLSESSID(SeekStream,"query item %s userCtrlNum[%u] ,get playtime is %d bitrate is %d"),
										it->_rawItemName,it->userCtrlNum,it->_itemPlaytime,it->_itemBitrate);
			}
#endif//_CHECK_ITEM_TYPE_USE_NEWLOGIC
			
			if( offset < it->_itemPlaytime )
			{
				long itemOffset = (long)offset;
				glog(ZQ::common::Log::L_DEBUG,
					PLSESSID(SeekStream,"find the item with CtrlNum=%d filename=%s and InsideOffset=%d startpos=SEEK_POS_END"),
						it->userCtrlNum ,it->objectName.string,itemOffset);
				if(! SeekTo(it->userCtrlNum , -itemOffset ,IPlaylist::SeekStartPos::SEEK_POS_END ))
					return -1;
				//��õ�ǰ����ʵoffset
				__int64 retOffset = 0;
				for(List::const_iterator itTemp = listBegin() ;itTemp !=it ;it++)
				{
					retOffset +=itTemp->_itemPlaytime;
				}
				//Ȼ�����item�ڵ�ʵ��offset
				ESESSION_CHARACTERISTICS esessInfo;
				TIME_OFFSET	tOffset=0;
				if(!getVstrmSessInfo(_itCurrent->sessionId,esessInfo))
				{//call getVstrmSessInfo fail
					tOffset=_itCurrent->timeOffset;					
				}		
				else
				{//call getVstrmSessInfo Success
					SESSION_CHARACTERISTICS* pInfo=&(esessInfo.SessionCharacteristics);				
					tOffset=pInfo->PlayoutTimeOffset;					
				}
				retOffset+=tOffset;
				glog(ZQ::common::Log::L_ERROR,
					PLSESSID(SeekTo,"seekto %d ok , get totalOffset is  %I64d and itemoffset is %d"),
					retOffset,tOffset);
				return retOffset;
			}
			offset -= it->_itemPlaytime;
		}
		ERRLOG(ZQ::common::Log::L_ERROR,PLSESSID(SeekStream,"Invalid parameter,Invalid offset =%I64d "),backupOffset);
		_lastErrCode = ERR_PLAYLIST_INVALID_PARA;
		return -1;
	}
	ERRLOG(ZQ::common::Log::L_ERROR,PLSESSID(SeekStream,"Invalid parameter,Not supported startPos =%d"),pos);
	_lastErrCode = ERR_PLAYLIST_INVALID_PARA;
	return -1;
}
bool Playlist::SeekTo(CtrlNum to,long timeOffset,IPlaylist::SeekStartPos pos)
{
	ZQ::common::MutexGuard  guard(_listOpLocker,__MSGLOC__);
	iterator it=findItem(to,listBegin());
	
	if(it==listEnd() || it==listStart())
	{
		_lastErrCode=ERR_PLAYLIST_INVALIDSTATE;
		ERRLOG(Log::L_ERROR,PLSESSID(SeekTo,"Invalid userCtrlNum %u when entering seekto"),to);
		DumpListInfo();
		return false;
	}
	glog(Log::L_DEBUG,PLSESSID(SeekTo,"Enter Seekto with CtrlNum=%u startpos=%d timeoffset=%d"),
												to,pos,timeOffset);
	endTimer64();
	
	long dwBitRate =0;
	long RealTotalTimeCount = 0;

	if(!_mgr.m_contentChecker.GetItemAttribute(std::string(it->_rawItemName),RealTotalTimeCount,dwBitRate,_strGuid) )
	{
		_lastErrCode=ERR_PLAYLIST_SERVER_ERROR;
		ERRLOG(ZQ::common::Log::L_ERROR,PLSESSID(SeekTo,"Can't get item attribute with item name is %s"),it->_rawItemName);
		return false;
	}

	glog(Log::L_DEBUG,PLSESSID(SeekTo,"get file playtime=%d and bitrate=%d with itemName=%s userCtrlNum[%u] from contentChecker"),
								RealTotalTimeCount,dwBitRate,it->_rawItemName,it->userCtrlNum);
	if(it!=_itCurrent || !_b1stPlayStarted || it->sessionId==0)
	{
		//1-->��Ŀ��item���ǵ�ǰ��item
		//2-->��playlist��û�в����κ�һ�β��ţ�����rewind��ͷ
		//3-->Ŀ��itemû�в���
		if(it!=_itCurrent)
			glog(Log::L_DEBUG,PLSESSID(SeekTo,"find item =%u  which is not current item when invoke seekto"),
										it->userCtrlNum);


		iterator prevIterator = listEnd();
//		CtrlNum lastCtrlNum = INVALID_CTRLNUM;
//		std::string	lastFileName = "";
		
		//���ʱ������primenext
		LockPrimeNext lock(_bDontPrimeNext);

		
		iterator itNext=_itNext;
		
		if((itNext!=listEnd()) && (itNext!=listStart()))
		{
			if (itNext->sessionId!=0) 
			{							
				glog(Log::L_DEBUG,PLSESSID(SeekTo,"Unload item with CtrlNum=%u and filename=%s"),
						itNext->userCtrlNum,itNext->objectName.string);
				if(!unloadEx(itNext))
				{
					_lastErrCode=ERR_PLAYLIST_SERVER_ERROR;
					ERRLOG(Log::L_ERROR,PLSESSID(SeekTo,"Unload item with CtrlNum=%u and fileName=%s fail"),
						itNext->userCtrlNum,itNext->objectName.string);
				}
			}
		}
		
		if(_itCurrent->sessionId!=0 )
		{
//			if(_itCurrent->stampLaunched!=0)
//			{
//				pause();
//			}
			glog(Log::L_DEBUG,PLSESSID(SeekTo,"UnLoad Item with CtrlNum %u and fileName=%s"),
					_itCurrent->userCtrlNum,_itCurrent->objectName.string);
			if(!unloadEx(_itCurrent))
			{
				_lastErrCode=ERR_PLAYLIST_SERVER_ERROR;
				ERRLOG(Log::L_ERROR,PLSESSID(SeekTo,"Can't unload current item with CtrlNum=%u and fileName=%s"),
					_itCurrent->userCtrlNum,_itCurrent->objectName.string);
			}
			//record last ctrlNum for firing a item stepped event
			prevIterator = _itCurrent;
//			lastCtrlNum = _itCurrent->userCtrlNum;
//			lastFileName = _itCurrent->objectName.string;
			
			//return false;//�����Ƿ���Ҫ����ִ���Ժ�Ķ�����
		}
		bool bComplete=!(it<listEnd()&&it>listStart());
		bool bLoadOK=true;
		
		long RealTimeOffset=0;
		

		switch(pos)
		{
		case IPlaylist::SEEK_POS_BEGIN:
			{					
				RealTimeOffset=timeOffset;
			}
			break;
		case IPlaylist::SEEK_POS_CUR:
			{
				RealTimeOffset=timeOffset;
			}
			break;
		case IPlaylist::SEEK_POS_END:
			{
				RealTimeOffset=RealTotalTimeCount+timeOffset;
			}
			break;
		}
		
		if(gStreamSmithConfig.lForceNormalTimeBeforeEnd>0&&
						_itCurrent+1==listEnd()&&
			memcmp(&_crntSpeed,&SPEED_NORMAL,sizeof(SPEED_NORMAL))!=0)
		{
			if(RealTimeOffset>RealTotalTimeCount-gStreamSmithConfig.lForceNormalTimeBeforeEnd)
			{//				
				RealTimeOffset=RealTotalTimeCount-gStreamSmithConfig.lForceNormalTimeBeforeEnd;
				glog(Log::L_DEBUG,PLSESSID(SeekTo,"this is the last item and in pauseTV mode,adjust realTimeOffset to %d"),
							RealTimeOffset);
			}
		}
		else if(RealTimeOffset>RealTotalTimeCount-MIN_PRELOAD_TIME)
		{
			//play next item
			RealTimeOffset=RealTotalTimeCount-MIN_PRELOAD_TIME;
		}
		glog(Log::L_DEBUG,PLSESSID(SeekTo,"Adjust timeOffset to %d with startPos=%d and offset=%d"),
					RealTimeOffset,pos,timeOffset);
		if(RealTimeOffset<0)
		{
			glog(Log::L_DEBUG,PLSESSID(SeekTo,"timeOffset<0 adjust it to 0"));
			RealTimeOffset=0;
		}
		timeOffset=RealTimeOffset;
		
		glog(Log::L_DEBUG,PLSESSID(SeekTo,"load item with CtrlNum=%u fileName=%s with timeoffset =%d "),
										it->userCtrlNum,it->objectName.string,timeOffset);
		
		while ( !bComplete  && !loadEx(it,false,timeOffset) )
		{		
			if(isReverseStreaming())
			{
				it--;
			}
			else
			{
				it++;
			}
			//can't load the specified item,set it to 0
			timeOffset = 0;

			_itCurrent=it;
			bComplete=!(   it <= listEnd() && it >= listStart()  );
			bLoadOK=false;
		}		
		_itCurrent=it;
			//����_itNext
		if(isReverseStreaming())
		{
			_itNext=_itCurrent>listStart() ?_itCurrent-1:listStart();
		}
		else
		{
			_itNext=_itCurrent<listEnd() ?_itCurrent+1:listEnd();
		}		
		if(!isCompleted())
		{			
			//if (!_b1stPlayStarted)
			{	
				//fire a state changed
				FireStateChanged(PLAYLIST_PLAY);
				//_currentStatus=PLAYLIST_PLAY;
				
				//seekto�Ժ�ǿ��
				setSpeedEx(Playlist::SPEED_NORMAL,true);
				//_b1stPlayStarted=true;
			}
			if(!launchEx(_itCurrent))
			{
				_lastErrCode=ERR_PLAYLIST_SERVER_ERROR;
				ERRLOG(Log::L_ERROR,PLSESSID(SeekTo,"Can't Launch item with CtrlNum=%u and fileName=%s"),
						_itCurrent->userCtrlNum,_itCurrent->objectName.string);
				return false;
			}
			if(!_b1stPlayStarted)
			{				
				_b1stPlayStarted=true;
				//OnItemDoneDummy(INVALID_CTRLNUM,_itCurrent);
			}
			//fire a Item stepped event
			//OnItemDoneDummy(lastCtrlNum,lastFileName,_itCurrent);
			OnItemStepped(prevIterator,_itCurrent,timeOffset);
			
		}
		else
		{
			try
			{
				OnPlaylistDone();
			}
			catch (...){}
			ERRLOG(Log::L_ERROR,PLSESSID(SeekTo,"Seek to fail,no loadable item"));
			_lastErrCode=ERR_PLAYLIST_SERVER_ERROR;
			return false;
		}

		primeNext();
		/*updateTimer();*/
	}
	else
	{
		glog(Log::L_DEBUG,PLSESSID(SeekTo,"seekto in current item with CtrlNum=%u fileName=%s vstrmsessionId=%u"),
							_itCurrent->userCtrlNum,_itCurrent->objectName.string,_itCurrent->sessionId);
		ESESSION_CHARACTERISTICS esessInfo;
		if(!getVstrmSessInfo(_itCurrent->sessionId,esessInfo))
		{
			ERRLOG(Log::L_ERROR,PLSESSID(SeekTo,"SeekTo()##call getVstrmSessInfo fail with session id =%u "),
													_itCurrent->sessionId);
			_lastErrCode=ERR_PLAYLIST_SERVER_ERROR;
			return false;
		}			
		//����offset
		SESSION_CHARACTERISTICS* pInfo=&(esessInfo.SessionCharacteristics);
		if(pInfo->MuxRate==0)
		{
			ERRLOG(Log::L_ERROR,PLSESSID(SeekTo,"SeekTo()##getVstrmSessInfo fail with session id =%d because MuxRate==0"),
										_itCurrent->sessionId);
			_lastErrCode=ERR_PLAYLIST_SERVER_ERROR;
			return false;
		}
		
		//check the parameter first
		long RealTimeOffset=0;
		//�����ܳ���

		
		if(RealTotalTimeCount<=0)
		{
			ERRLOG(Log::L_ERROR,PLSESSID(SeekTo,"SeekTo() Can't get total time count"));
			_lastErrCode=ERR_PLAYLIST_SERVER_ERROR;
			return false;
		}		
		glog(Log::L_DEBUG,PLSESSID(SeekTo,"SeekTo()  current  totalPlayTime=%d and MuxBitRate=%u"),
									RealTotalTimeCount,dwBitRate);
		switch(pos)
		{
		case IPlaylist::SEEK_POS_BEGIN:
			{					
				RealTimeOffset=timeOffset;
			}
			break;
		case IPlaylist::SEEK_POS_CUR:
			{
				RealTimeOffset=pInfo->PlayoutTimeOffset+timeOffset;
			}
			break;
		case IPlaylist::SEEK_POS_END:
			{
				RealTimeOffset=RealTotalTimeCount+timeOffset;
			}
			break;
		}
		if(RealTimeOffset>RealTotalTimeCount-MIN_PRELOAD_TIME)
		{
			//play next item
			RealTimeOffset=RealTotalTimeCount-MIN_PRELOAD_TIME;
		}
		glog(Log::L_DEBUG,PLSESSID(SeekTo,"Adjust timeOffset to %d with startPos=%d and offset=%d"),
								RealTimeOffset,pos,timeOffset);
		if(RealTimeOffset<0)
		{
			glog(Log::L_DEBUG,PLSESSID(SeekTo,"timeOffset<0 adjust it to 0"));
			RealTimeOffset=0;
		}
		timeOffset=RealTimeOffset;
		
				iterator itNext=_itNext;
		
		if((itNext!=listEnd()) && (itNext!=listStart()))
		{
			if (itNext->sessionId!=0) 
			{							
				glog(Log::L_DEBUG,PLSESSID(SeekTo,"Unload item with CtrlNum=%u and filename=%s"),
						itNext->userCtrlNum,itNext->objectName.string);
				if(!unloadEx(itNext))
				{
					_lastErrCode=ERR_PLAYLIST_SERVER_ERROR;
					ERRLOG(Log::L_ERROR,PLSESSID(SeekTo,"Unload item with CtrlNum=%u and fileName=%s fail"),
						itNext->userCtrlNum,itNext->objectName.string);
				}
			}
		}
		
		glog(Log::L_DEBUG,PLSESSID(SeekTo,"reposition with sessionId= %d and timeOffset=%d and total PlayTime=%d"),
									_itCurrent->sessionId,timeOffset,RealTotalTimeCount);

		IOCTL_CONTROL_PARMS controlParam;
		memset(&controlParam, 0 ,sizeof(controlParam));
		controlParam.controlCode=VSTRM_GEN_CONTROL_REPOSITION;		
		controlParam.u.reposition.timeOffset=timeOffset;
		controlParam.u.reposition.timeOffsetType=ABSOLUTE_TIME_OFFSET;
		controlParam.u.reposition.setSpeed=FALSE;
		
		VSTATUS _status=VstrmClassControlSessionEx(_mgr.classHandle(),_itCurrent->sessionId,VSTRM_GEN_CONTROL_REPOSITION,
			&controlParam,sizeof(IOCTL_REPOSITION_PARAMS),
			NULL,NULL);
		if(_status!=VSTRM_SUCCESS)
		{		
			char szErrbuf[1024];
			ZeroMemory(szErrbuf,1024);
			_lastErrCode=ERR_PLAYLIST_SERVER_ERROR;
			ERRLOG(Log::L_ERROR,PLSESSID(SeekTo,"reposition stream fail and error string is %s"),
											_mgr.getErrorText(_status,szErrbuf,1023));
			return false;
		}
		else
		{
			//����_itNext
			if(isReverseStreaming())
			{
				_itNext=_itCurrent>listStart() ?_itCurrent-1:listStart();
			}
			else
			{
				_itNext=_itCurrent<listEnd() ?_itCurrent+1:listEnd();
			}
			
#pragma message(__MSGLOC__"���������������ٶ�(��FF��ΪNP)������seekto��û��Ч����ԭ����")
			if( (!isCompleted())&&
				(_itCurrent+1==listEnd())&& 
				(!isReverseStreaming())
				)
			{
				if(gStreamSmithConfig.lForceNormalTimeBeforeEnd>0 && memcmp(&_crntSpeed,&SPEED_NORMAL,sizeof(SPEED_NORMAL))!=0)
				{
					glog(Log::L_DEBUG,PLSESSID(SeekTo,"this is the last item and in pauseTV mode,setspeed to normal"));
					glog(Log::L_DEBUG,PLSESSID(SeekTo,"before setspeed in seekto current item "));
					DisplaySessionAttr(_itCurrent);	

					setSpeedEx(SPEED_NORMAL,true);

					glog(Log::L_DEBUG,PLSESSID(SeekTo,"after setspeed in seekto current item"));
					DisplaySessionAttr(_itCurrent);	
				}
			}
			primeNext();
			/*updateTimer();*/
		}
	}
	glog(Log::L_DEBUG,PLSESSID(SeekTo,"####After reposition#####"));
	DisplaySessionAttr(_itCurrent);

	_lastErrCode=ERR_PLAYLIST_SUCCESS;
	DumpListInfo(true);
	glog(Log::L_DEBUG,PLSESSID(SeekTo,"Leave seekto"));
	return true;
}
bool Playlist::unloadEx(iterator it)
{
	
	ZQ::common::Guard < ZQ::common::Mutex > guard(_listOpLocker,__MSGLOC__);

	if (it <= listStart() || it >= listEnd())
	{
		glog(Log::L_DEBUG,PLSESSID(unloadEx,"unloadEx() iterator is out of range, do not need to unloadex"));
		return false;
	}
	glog(Log::L_DEBUG,PLSESSID(unloadEx,"enter UnLoad item with CtrlNum=%d and fileName=%s and vstrm sessionId=%u"),
				it->userCtrlNum,it->objectName.string ,it->sessionId);
	if (it->sessionId ==0)
	{
		glog(Log::L_DEBUG,PLSESSID(unloadEx,"item with CtrlNum=%u and fileName=%s is not loaded yet,do not need to unloadex"),
					it->userCtrlNum,it->objectName.string);
		return false; // haven't been loaded yet
	}

	
	if (it == listCurrent() && it->stampLaunched >0 /*&& it->stampUnload ==0*/)
	{
		// pause the executing session
		glog(Log::L_DEBUG,PLSESSID(unloadEx,"pause when unloadex sessionId=%u CtrlNum=%u and fileName=%s"),
									it->sessionId,it->userCtrlNum,it->objectName.string);
		pause();
	}

	try
	{
		glog(Log::L_DEBUG,PLSESSID(unloadEx,"Unload item with CtrlNum=%u and fileName=%s and Vstrm SessionId=%u"),
									it->userCtrlNum,it->objectName.string,it->sessionId);
		if(VstrmClassUnloadEx (_mgr.classHandle(), it->sessionId)!=VSTRM_SUCCESS)
		{	
			_ntstatus 	= GetLastError ();		// capture secondary error code (if any)
			char	szErrbuf[1024];
			ZeroMemory(szErrbuf,1024);
			_lastErrCode=ERR_PLAYLIST_SERVER_ERROR;
			ERRLOG(Log::L_ERROR,PLSESSID(unloadEx,"Unload with CtrlNum=%u fileName=%s and vstrm SessionId=%u fail and error desc is %s"),
						it->userCtrlNum,it->objectName.string,it->sessionId,_mgr.getErrorText(_ntstatus,szErrbuf,1023));
		}
		else
		{
			glog(Log::L_DEBUG,PLSESSID(unloadEx,"Unload with CtrlNum=%u fileName=%s and vtrsm sessionId=%u succesufully"),
								it->userCtrlNum,it->objectName.string,it->sessionId);
			try
			{
				//send the item done message
//				OnItemDone(it);
			}
			catch (...)
			{
			}			
		}
	}
	catch(...) 
	{
		glog(Log::L_ERROR,PLSESSID(unloadEx,"unexpect exception was throw out in unloadEx()"));
	}

	it->sessionId = 0;

	// stamp the execution
	it->stampUnload = GetTickCount();

	//set it to 0 for future 
	it->stampLaunched =0;
	// make the un-played element loadable in the future
	if (it->stampLaunched ==0)
	{
		it->sessionId = 0;
		it->stampLoad = 0; 
	}
	_lastErrCode=ERR_PLAYLIST_SUCCESS;
	glog(Log::L_DEBUG,PLSESSID(unloadEx,"Leave unload with CtrlNum=%u and fileName=%s"),
								it->userCtrlNum,it->objectName.string);
	return true;
}

bool Playlist::launchEx(iterator it)
{
	ZQ::common::Guard < ZQ::common::Mutex > guard(_listOpLocker,__MSGLOC__);

	if (it < listBegin() || it >= listEnd())
	{
		glog(Log::L_ERROR,PLSESSID(launchEx,"launchEx() iterator is out of range"));
		return false;
	}
	glog(Log::L_DEBUG,PLSESSID(launchEx,"Enter LaunchEx with ctrlnum=%u and fileName=%s vtrsmSessId=%u"),
										it->userCtrlNum,it->objectName.string,it->sessionId);
	if (it->sessionId ==0)
	{
		glog(Log::L_DEBUG,PLSESSID(launchEx,"launchEx()  Item with CtrlNum=%u and fileName=%s is not loaded yet"),
									it->userCtrlNum,it->objectName.string);
		return false; // haven't been loaded yet
	}
	if ( isLaunched(it) ) 
	{
		glog(Log::L_INFO,PLSESSID(launchEx,"launchEx() Item with CtrlNum=%u and fileName=%s has been lauched"),
									it->userCtrlNum,it->objectName.string);
		return true; // haven't been loaded yet
	}

	VSTATUS status = VstrmClassPlayEx (_mgr.classHandle(), it->sessionId);

	if (VSTRM_SUCCESS == status)
	{
		// stamp the execution
		it->stampLaunched = GetTickCount();
	}
	else
	{		
		_ntstatus 	= GetLastError ();		// capture secondary error code (if any)
		char	szErrbuf[1024];
		ZeroMemory(szErrbuf,1024);
		ERRLOG(Log::L_ERROR,PLSESSID(launchEx,"Can't Lauch the item with CtrlNum=%u and fileName %s and Error description is %s"),
									it->userCtrlNum,it->objectName.string,_mgr.getErrorText(_ntstatus,szErrbuf,1023));		
		return false;
	}
	glog(Log::L_DEBUG,PLSESSID(launchEx,"set playlist state to PLAYLIST_PLAY in LauchEx"));
	
	FireStateChanged(PLAYLIST_PLAY);
	//_currentStatus=PLAYLIST_PLAY;

	glog(Log::L_DEBUG,PLSESSID(launchEx,"Leave LaunchEx with CtrlNum=%u and fileName=%s vstrmSessionId=%u"),
							it->userCtrlNum,it->objectName.string,it->sessionId);
	_lastErrCode=ERR_PLAYLIST_SUCCESS;
	return true;
}

bool Playlist::isLaunched(iterator it)
{
	if (it->sessionId ==0)
	{
		it->stampLaunched =0;
		return false;
	}
	
	return (it->stampLaunched >0);
}

Playlist::iterator Playlist::findItem(const ULONG userCtrlNum, const_iterator from)
{
	ZQ::common::Guard < ZQ::common::Mutex > guard(_listOpLocker,__MSGLOC__);
	
	for (iterator it = (from < listBegin() ? listBegin() : from); it < listEnd(); it++)
	{
		if (it->userCtrlNum == userCtrlNum)
			break;
	}
	
	return it;
}

const bool Playlist::getItemInfo(const_iterator it, Item& elem)
{
	if (it < listBegin() || it >= listEnd())
		return false;

	ZQ::common::Guard < ZQ::common::Mutex > guard(_listOpLocker,__MSGLOC__);
	memcpy(&elem, &(*it), sizeof(Item));
	return true;
}

Playlist::iterator Playlist::findInternalCtrlNum(const ULONG intlCtrlNum)
{
	ZQ::common::Guard < ZQ::common::Mutex > guard(_listOpLocker,__MSGLOC__);

	for (iterator it = listBegin(); it != listEnd(); it++)
	{
		if (it->intlCtrlNum == intlCtrlNum)
			break;
	}
	
	return it;
}

Playlist::iterator Playlist::findUserCtrlNum(const CtrlNum userCtrlNum)
{
	ZQ::common::Guard < ZQ::common::Mutex > guard(_listOpLocker,__MSGLOC__);
	for (iterator it = listBegin(); it < listEnd(); it++)
	{
		if (it->userCtrlNum == userCtrlNum)
			break;
	}
	
	return it;
}

bool Playlist::setSpeedEx(const SPEED_IND newspeed,bool bForceSet)
{
	if (_b1stPlayStarted && 
		newspeed.denominator==_crntSpeed.denominator*1000 
		&&newspeed.numerator==_crntSpeed.numerator*1000)
	{
		glog(Log::L_DEBUG,PLSESSID(setSpeedEx,"new speed is same as current speed,return success!"));
		/*&& memcmp(&newspeed, &_crntSpeed, sizeof(_crntSpeed)) ==0*/
		return true;
	}	
	
	if(isCompleted())
	{
		_lastErrCode=ERR_PLAYLIST_INVALIDSTATE;
		ERRLOG(Log::L_ERROR,PLSESSID(setSpeedEx,"playlist is complete when call SetSpeedEx"));
		return false;
	}
	
	ZQ::common::Guard < ZQ::common::Mutex > guard(_listOpLocker,__MSGLOC__);
	if ( !(_currentStatus == IPlaylist::PLAYLIST_PLAY || _currentStatus == IPlaylist::PLAYLIST_PAUSE)) 
	{
		_lastErrCode=ERR_PLAYLIST_INVALIDSTATE;
		ERRLOG(ZQ::common::Log::L_ERROR,PLSESSID(setSpeedEx,"current playlist is not in PLAY or PAUSE state,[%d] return failed"),_currentStatus);
		return false;
	}
	
	glog(Log::L_DEBUG,PLSESSID(setSpeedEx,"Enter SetSpeedEx with newSpeed (%d/%d) and bForceSet=%d"),
				newspeed.numerator,newspeed.denominator,bForceSet);
	bool	bEndTimer=false;
	if(!bForceSet)
	{
		if(_currentStatus==PLAYLIST_STOP || _currentStatus==PLAYLIST_SETUP)
		{
			_lastErrCode=ERR_PLAYLIST_INVALIDSTATE;
			ERRLOG(Log::L_ERROR,PLSESSID(setSpeedEx,"Can't set speed because vstrm port is closed"));
			return false;
		}
		if(_currentStatus!=PLAYLIST_PAUSE)
		{
			ULONG		tmpBitRate=0;
			LONGLONG	tmpObjectSize=0;
			LONGLONG	tmpPlayOffset=0;

			ESESSION_CHARACTERISTICS esessInfo;
			if(!getVstrmSessInfo(_itCurrent->sessionId, esessInfo))
			{					
				tmpPlayOffset=_itCurrent->byteOffset;
				tmpObjectSize=_itCurrent->byteOffsetEOS;
				tmpBitRate=_itCurrent->bitrate;
			}			
			else
			{
				SESSION_CHARACTERISTICS* pInfo=&(esessInfo.SessionCharacteristics);				
				tmpPlayOffset=pInfo->ByteOffset.QuadPart;
				tmpObjectSize=pInfo->ObjectSize.QuadPart;
				tmpBitRate=pInfo->MuxRate;
			}			

			glog(Log::L_DEBUG,PLSESSID(setSpeedEx,"current streaming status OffSetEOS=%I64d ByteOffset=%I64d bitrate=%u"),
																				tmpObjectSize,tmpPlayOffset,tmpBitRate);
			///�����ж����趨���ٶȺ;ɵ��ٶȵķ���		
			int		GuardTimeMulti=2;
			int timeOff=0;
			int timeOff1=0,timeOff2=0;
			
		
			if(tmpBitRate!=0 &&tmpObjectSize!=0 )
			{				
				if( ( newspeed.numerator * _crntSpeed.numerator ) < 0 )
				{//�������һ�£�������������þͿ�һЩ
					//GuardTimeMulti=CHANGE_DIRECTION_LIMITED;
					glog(Log::L_DEBUG,PLSESSID(setSpeedEx,"different direction"));
					GuardTimeMulti=1;//�����ı䷽��				
									
					//timeOff1=(int) ( ((tmpObjectSize - tmpPlayOffset) *8*1000) / (tmpBitRate));
					timeOff2=(int) ( ((tmpPlayOffset) *8*1000) / (tmpBitRate));
					//timeOff=MIN_PRELOAD_TIME*GuardTimeMulti+1;
					timeOff=timeOff2;//timeOff1>timeOff2 ?timeOff2:timeOff1;
				}
				else
				{
					glog(Log::L_DEBUG,PLSESSID(setSpeedEx,"same direction"));
					timeOff1=(int) ( ((tmpObjectSize - tmpPlayOffset) *8*1000) / (tmpBitRate));
					//timeOff2=(int) ( ((tmpPlayOffset) *8*1000) / (tmpBitRate));
					//timeOff2=(int) ( ((_itCurrent->byteOffset) *8*1000) / (_itCurrent->bitrate));
					timeOff=timeOff1;//timeOff1>timeOff2 ?timeOff2:timeOff1;					
				}
			}
			else
			{			
				timeOff=MIN_PRELOAD_TIME*GuardTimeMulti-1;
			}
			
//			if(!isCompleted()&&//û�н���
//				_itCurrent+1==listEnd()&&
//				!isReverseStreaming())//���ô������һ��Itemn��������PauseTV״̬,���������򲥷�
//			{//�ú���ʱ����������?
//				int forceNormalTime=gStreamSmithConfig.lForceNormalTimeBeforeEnd;
//				if(forceNormalTime>= timeOff && (float)newspeed.numerator/(float)newspeed.denominator > 1.0)
//				{
//					_lastErrCode=ERR_PLAYLIST_INVALIDSTATE;
//					ERRLOG(Log::L_ERROR,PLSESSID("last item and ForceNormalTimeOnPause=%d timeOff=%d,so can setspeed to %d/%d"),
//								forceNormalTime,timeOff,newspeed.numerator,newspeed.denominator);
//					return false;
//				}
//			}

			glog(Log::L_DEBUG,PLSESSID(setSpeedEx,"now timeoff=%d"),timeOff);
			if( timeOff < (MIN_PRELOAD_TIME*GuardTimeMulti) || _itCurrent->sessionId==0 ||tmpBitRate ==0 )
			{
				_lastErrCode=ERR_PLAYLIST_INVALIDSTATE;
				ERRLOG(Log::L_ERROR,PLSESSID(setSpeedEx,"at the boundry of a item,set speed fail"));
				return false;
			}
			else
			{
				glog(Log::L_DEBUG,PLSESSID(setSpeedEx,"SetSpeedEx to %d/%d and timeoff=%d"),
						newspeed.numerator,newspeed.denominator,timeOff);
			}
		}		
		endTimer64();
		bEndTimer=true;		
	}
	//���е����λ�ô�������setspeed
	//�����itnext
#if NEW_SETSPEEDEX_LOGIC
	iterator itNeedUnload = listEnd();
#endif
	if(isReverseStreaming())
	{
		if(_itNext!=listStart() && _itNext->sessionId!=0)
		{
#if NEW_SETSPEEDEX_LOGIC
			itNeedUnload = _itNext;
#else
			unloadEx(_itNext);		
#endif 
		}
	}
	else
	{
		if(_itNext!=listEnd() && _itNext->sessionId!=0)
		{
#if NEW_SETSPEEDEX_LOGIC
			itNeedUnload = _itNext;
#else
			unloadEx(_itNext);		
#endif 	
		}
	}
	VSTATUS					status = VSTRM_SUCCESS;
	
	IOCTL_CONTROL_PARMS_LONG controlParam;
	memset(&controlParam , 0 , sizeof(controlParam));
	
	controlParam.u.portSpeed.speedIndicator = newspeed;
	_isReverseStreaming=newspeed.numerator < 0;

		status = VstrmClassControlPortEx1(_mgr.classHandle(),
			_vstrmPortNum,
			VSTRM_GEN_CONTROL_PORT_SPEED,
			&controlParam,
			sizeof(IOCTL_CONTROL_PARMS_LONG),
			NULL,
			0);
		
		if (status == VSTRM_SUCCESS)
		{		
			// Retrieve the returned actual speed from the driver
			status				= controlParam.NtStatus;
			//		_timeOffset			= controlParam.u.portSpeed.timeOffset;
			_crntSpeed			= controlParam.u.portSpeed.speedIndicator;
			_itCurrent->speed.numerator	= controlParam.u.portSpeed.speedIndicator.numerator;
			_itCurrent->speed.denominator	= controlParam.u.portSpeed.speedIndicator.denominator;

			//update current timeoffset
			_itCurrent->timeOffset = controlParam.u.portSpeed.timeOffset;

			glog(Log::L_DEBUG,PLSESSID(setSpeedEx,"bool Playlist::setSpeedEx() Set speed OK to Port[%d]"
					" speed[%d/%d] timeoffset[%u]"),
							_vstrmPortNum,_crntSpeed.numerator,_crntSpeed.denominator,_itCurrent->timeOffset);
			//DisplaySessionAttr(_itCurrent);
#if NEW_SETSPEEDEX_LOGIC
			//setspeed successfully , unload the itNeedUnload item
			unloadEx(itNeedUnload);
#else//NEW_SETSPEEDEX_LOGIC
				
#endif //NEW_SETSPEEDEX_LOGIC
			if(bEndTimer)
			{
				//			glog(Log::L_DEBUG,PLSESSID("Force to prime next"));			
				//			primeNext();
				//��SpeedChanged���¼��������Ժ󣬻�����call PrimeNext��Load��һ��Item				
				primeNext();
				updateTimer();
			}
			printList("SetspeedEx");
		}
		else
		{		
			_ntstatus 	= GetLastError ();		// capture secondary error code (if any)
			_lastErrCode=ERR_PLAYLIST_SERVER_ERROR;
			char	szErrbuf[1024];
			ZeroMemory(szErrbuf,1024);
			ERRLOG(Log::L_ERROR,PLSESSID(setSpeedEx,"Can't set speed for current session %u and port=%d error description is %s" ),
					_itCurrent->sessionId,_vstrmPortNum,_mgr.getErrorText(_ntstatus,szErrbuf,1023));
		}
	_lastErrCode=ERR_PLAYLIST_SUCCESS;
	glog(Log::L_DEBUG,PLSESSID(setSpeedEx,"Leave SetSpeedEx"));
	return (status == VSTRM_SUCCESS);
}


bool Playlist::play()
{
	glog(Log::L_DEBUG,PLSESSID(play,"Enter play"));
	if(_currentStatus==PLAYLIST_PAUSE)
	{//Current playlist is in pause state
		glog(Log::L_DEBUG,PLSESSID(play,"in PAUSE state,redirect to resume() "));
		return resume();
	}
//#pragma message(__MSGLOC__"���Item�Ѿ��ڲ��ţ��Ƿ���ֱ�ӷ���True???")
	if(_currentStatus==PLAYLIST_PLAY)
	{
		glog(Log::L_DEBUG,PLSESSID(play,"current item is in playing,return with successful"));
		return true;
	}
	
	glog(Log::L_DEBUG,PLSESSID(play,"Play Start"));
	if (isCompleted())
	{
		_lastErrCode=ERR_PLAYLIST_INVALIDSTATE;
		ERRLOG(Log::L_ERROR,PLSESSID(play,"no more items in the playlist"));
		return false;
	}
	glog(Log::L_DEBUG,PLSESSID(play,"set playlist state to PLAYLIST_PLAY in play"));

	{	
		long lMaxWait = gStreamSmithConfig.lmaxWaitTimeToStartFirstItem;
		//lMaxWait = min(lMaxWait,3000);//Adjust maxwait under 3000
		if (lMaxWait>3000) 
		{
			glog(ZQ::common::Log::L_INFO,PLSESSID(play,"maxWaitTimeToStartFirstItem [%d] is bigger than 3000(ms) adjust it to 3000(ms)"),lMaxWait);
			lMaxWait = 3000;
		}
		//ֻ��enable����������������
		if ( lMaxWait > 0 &&  _itCurrent->criticalStart > 0 ) 
		{
			ZQ::common::MutexGuard gd(_listOpLocker);
			
			//convert UTC time to system time
			SYSTEMTIME	sysCR;
			SYSTEMTIME	sysNow;
			ZQ::common::TimeUtil::Time2SystemTime(_itCurrent->criticalStart,sysCR);
			GetSystemTime(&sysNow);

			FILETIME	ftCR ;
			FILETIME	ftNow;
			SystemTimeToFileTime(&sysCR,&ftCR);
			SystemTimeToFileTime(&sysNow,&ftNow);
			time_t UTCnow = time(NULL);


			ULARGE_INTEGER criticalStart ;
			ULARGE_INTEGER currentTime;
			memcpy(&criticalStart,&ftNow,sizeof(ftNow));
			memcpy(&currentTime,&ftCR,sizeof(ftCR));
			long wait = (long)((currentTime.QuadPart-criticalStart.QuadPart)/10000);

			//���ʱ���С��10�����ֱ��ִ���������
			if (wait>10) 
			{			
				if ( wait>gStreamSmithConfig.lmaxWaitTimeToStartFirstItem/*config*/ ) 
				{
					_lastErrCode = ERR_PLAYLIST_INVALIDSTATE;
					ERRLOG(Log::L_ERROR,
						PLSESSID(play,"Current Item has a criticalStart time [%u] and the"
						" difference now is [%u] diff=[%d] configTime[%d]"),
						_itCurrent->criticalStart,UTCnow,wait,lMaxWait);
					return false;
				}
				glog(ZQ::common::Log::L_INFO,
					PLSESSID(play,"pause [%d] milliseconds before [%s] to load the item [%s][%d]"),
					wait,printfUTCTime(_itCurrent->criticalStart),_itCurrent->objectName.string,_itCurrent->userCtrlNum);
				Sleep(wait);
			}
		}
	}

	//_currentStatus=PLAYLIST_PLAY;
	
	glog(Log::L_DEBUG,PLSESSID(play,"Loadex Item (%d)%s in Play"),_itCurrent->userCtrlNum , _itCurrent->objectName.string);	
	{
		ZQ::common::MutexGuard gd(_listOpLocker);
		LockPrimeNext lock(_bDontPrimeNext);
		
		for(;_itCurrent<listEnd()&&_itCurrent>listStart();_itCurrent+= isReverseStreaming()?-1:1)
		{
			if (loadEx(_itCurrent))
			{
				//		ERRLOG(Log::L_ERROR,PLSESSID("set playlist state to PLAYLIST_SETUP because loadex fail"));
				//		_currentStatus=PLAYLIST_SETUP;
				//		ERRLOG(Log::L_ERROR,PLSESSID("can't load current item"));
				//return false;		
				_itNext=isReverseStreaming()?_itCurrent-1:_itCurrent+1;
				break;
			}
		}		
		if(_itCurrent>=listEnd() || _itCurrent <=listStart())
		{	
			try
			{
				_stampDone = GetTickCount();
				OnPlaylistDone();
				return false;		
			}
			catch(...)
			{
				glog(Log::L_ERROR,PLSESSID(play,"Unexpect exception was threw out when call OnPlaylistDone in play function"));
			}
			return false;
		}
		
		FireStateChanged(PLAYLIST_PLAY);

		

		//	while (!isCompleted() && 0 == _itCurrent->sessionId)
		//		skipToItem(_itNext);
		
		
		//	if (isCompleted())
		//		return false;
		
		if (!_b1stPlayStarted)
		{
			//setSpeedEx(Playlist::SPEED_FF,true);			
			setSpeedEx(_crntSpeed,true);
			//OnItemDoneDummy(INVALID_CTRLNUM,"",_itCurrent);
			OnItemStepped(listEnd(),_itCurrent);
		}
		
		launchEx(_itCurrent);
		_b1stPlayStarted =true;		
		
	}

	Sleep(1); // yield for current playing	
	primeNext();
	
	glog(Log::L_DEBUG,PLSESSID(play,"Play ok"));
	_lastErrCode=ERR_PLAYLIST_SUCCESS;	
	glog(Log::L_DEBUG,PLSESSID(play,"Leave play"));
	return true;
}


bool Playlist::pause()
{
	if (isCompleted())
	{
		ERRLOG(Log::L_ERROR,PLSESSID(pause,"playlist complete"));
		return false;
	}
	ZQ::common::Guard < ZQ::common::Mutex > guard(_listOpLocker,__MSGLOC__);
	if (_currentStatus == IPlaylist::PLAYLIST_PAUSE) 
	{
		glog(ZQ::common::Log::L_INFO,PLSESSID(pause,"current playlist is in PAUSE state,return ok"));
		return true;
	}
	if (_currentStatus != IPlaylist::PLAYLIST_PLAY) 
	{
		_lastErrCode=ERR_PLAYLIST_INVALIDSTATE;
		ERRLOG(Log::L_ERROR,PLSESSID(pause,"playlist is not at PLAY state,can't perform PAUSE command"));
		return false;
	}
	glog(Log::L_DEBUG,PLSESSID(pause,"Enter pause"));
	
	glog(Log::L_DEBUG,PLSESSID(pause,"Pause current item with CtrlNum=[%u] and fileName=[%s] and VstrmPort=[%d]"),
									_itCurrent->userCtrlNum,_itCurrent->objectName.string,_vstrmPortNum);
	IOCTL_CONTROL_PARMS_LONG controlParam;
	memset(&controlParam, 0 ,sizeof(controlParam));

	
	ULONG portNum				= _vstrmPortNum;  // _vstrmPortNum.getPortNum();	
	controlParam.u.pause.timeCode = TIME_CODE_NOW ;
	
	VSTATUS status = VstrmClassControlPortEx1(_mgr.classHandle(),
												portNum,
												VSTRM_GEN_CONTROL_PAUSE,
												&controlParam,
												sizeof(IOCTL_CONTROL_PARMS_LONG),
												NULL,
												0);
	
	if (status == VSTRM_SUCCESS && &(*_itCurrent) != NULL && !isCompleted())
	{
		// Retrieve the returned actual speed from the driver
		status					= controlParam.NtStatus;
		_itCurrent->timeOffset	= controlParam.u.pause.timeOffset;
		_crntSpeed	= controlParam.u.pause.speedIndicator;
		glog(Log::L_DEBUG,PLSESSID(pause,"set playlist state to PLAYLIST_PAUSE because invoke pause successfully"));
		FireStateChanged(PLAYLIST_PAUSE);
		//_currentStatus=PLAYLIST_PAUSE;
		glog(Log::L_DEBUG,
			PLSESSID(pause,"bool Playlist::pause() vstrmSess[%u] vstrmPort[%d] ctrlNum[%u] fileName[%s] "
							"was paused and timeOffset[%u] speed[%d/%d]"),
							_itCurrent->sessionId,_vstrmPortNum, _itCurrent->userCtrlNum, 
							_itCurrent->objectName.string,_itCurrent->timeOffset,
							_crntSpeed.numerator,_crntSpeed.denominator );
		
		//DisplaySessionAttr(_itCurrent);
		
		endTimer64();
		_isGoodItemInfoData=true;
		SetTimerEx(gStreamSmithConfig.lPlaylistTimeout);
		if(_mgr._timeout ==(timeout_t)TIMEOUT_INF || (timeout_t)gStreamSmithConfig.lPlaylistTimeout<_mgr._timeout)
			_mgr.wakeup();	
#ifdef _ICE_INTERFACE_SUPPORT
		_currentItemDist=(int)(_itCurrent-listBegin());
		_mgr.UpdatePlaylistFailStore(this,true,true);
#endif//_ICE_INTERFACE_SUPPORT
	}
	else
	{		
		_ntstatus 	= GetLastError ();		// capture secondary error code (if any)
		char	szErrbuf[1024];
		ZeroMemory(szErrbuf,1024);
		_lastErrCode=ERR_PLAYLIST_SERVER_ERROR;
		ERRLOG(Log::L_ERROR,PLSESSID(pause,"Can't Pause the item with CtrlNum=[%u] and fileName=[%s] on vstrmPort=[%d] and Error description is %s"),
						_itCurrent->userCtrlNum,_itCurrent->objectName.string,_vstrmPortNum,_mgr.getErrorText(_ntstatus,szErrbuf,1023));		
	}
	_lastErrCode=ERR_PLAYLIST_SUCCESS;
	glog(Log::L_DEBUG,PLSESSID(pause,"Leave pause"));
	return (status == VSTRM_SUCCESS);
}

bool Playlist::fastward()
{
#pragma message(__MSGLOC__"obsolete")
	return false;
	if (isCompleted())
		return false;

	// unplayed item reached by calling skip(), load it
	glog(Log::L_DEBUG,PLSESSID(fastward,"LoadEx item (%d)%s in fastforward"),_itCurrent->userCtrlNum,_itCurrent->objectName.string);
	loadEx(_itCurrent);
	
	// TODO: call VstrmAPI::play

	return true;
}

bool Playlist::resume()
{
	glog(Log::L_DEBUG,PLSESSID(resume,"Enter resume with vtrsm port =%u"),_vstrmPortNum);
	if (isCompleted())
	{
		ERRLOG(Log::L_ERROR,PLSESSID(resume,"playlist is complete"));
		return false;
	}

	if (0 == _itCurrent->sessionId)
	{
		// unplayed item reached by calling skip(), do the whole procedure then play
		return play();
	}
	else
	{
		ZQ::common::Guard < ZQ::common::Mutex > guard(_listOpLocker,__MSGLOC__);		

		IOCTL_CONTROL_PARMS_LONG controlParam;
		memset(&controlParam , 0 , sizeof(controlParam));
		
		ULONG portNum				= _vstrmPortNum;  // _vstrmPortNum.getPortNum();		
		controlParam.u.pause.timeCode = TIME_CODE_NOW ;
		
		VSTATUS status = VstrmClassControlPortEx1(_mgr.classHandle(),
													portNum,
													VSTRM_GEN_CONTROL_RESUME,
													&controlParam,
													sizeof(IOCTL_CONTROL_PARMS_LONG),
													NULL,
													0);
		if(status!=VSTRM_SUCCESS)
		{
			_ntstatus 	= GetLastError ();		// capture secondary error code (if any)
			char	szErrbuf[1024];
			ZeroMemory(szErrbuf,1024);
			_lastErrCode=ERR_PLAYLIST_SERVER_ERROR;
			ERRLOG(Log::L_ERROR,PLSESSID(resume,"Can't resume the item with CtrlNum=%u and fileName=%s on vtrsmPort=%d and error description is %s"),
									_itCurrent->userCtrlNum,_itCurrent->objectName.string,_vstrmPortNum,
									_mgr.getErrorText(_ntstatus,szErrbuf,1023));			
		}
		else
		{
			updateTimer();
			DisplaySessionAttr(_itCurrent);
			glog(Log::L_DEBUG,PLSESSID(resume,"set playlist state to PLAYLIST_PLAY because resume ok"));
			FireStateChanged(PLAYLIST_PLAY);
			//_currentStatus=PLAYLIST_PLAY;
			glog(Log::L_DEBUG,PLSESSID(resume,"resume current item with CtrlNum=%u and fileName=%s and current sessionId=%u on VstrmPort=%d ok"),
					_itCurrent->userCtrlNum,_itCurrent->objectName.string,_itCurrent->sessionId,_vstrmPortNum);
		}
		_lastErrCode=ERR_PLAYLIST_SUCCESS;
		return status==VSTRM_SUCCESS;
	}	
	glog(Log::L_DEBUG,PLSESSID(resume,"Leave resume"));
}

void Playlist::OnVstrmSessDetected(const PVOD_SESSION_INFORMATION sessinfo
#if _USE_NEW_SESSION_MON
								   ,ZQ::common::Log& log
#endif
								   )
{
	{
		ZQ::common::MutexGuard gd(_listOpLocker);
		
		if(size()<=0 || _bCleared)
			return;
		
		const_iterator it=updateItem(sessinfo);
		if (it>=listEnd() ||it<=listStart())
		{		
			return;
		}	
	}

	if(!m_pStreamSite)
	{
		m_pStreamSite=(StreamSmithSite*)StreamSmithSite::getDefaultSite();
	}

	
	if(m_pStreamSite)
	{
#ifdef NEED_EVENTSINK_RAWDATA
		SESSDETECTED	sd;
		sd.pSessInfo=sessinfo;
		ZQ::common::Variant var(&sd,sizeof(SESSDETECTED));		
#else
		ZQ::common::Variant var;		
		const ZQ::common::Variant varValue=(int)sessinfo->sessionId;
		var.set(EventField_SessionId,varValue);
		var.set(EventField_PlaylistGuid,_strGuid);
		var.set(EventField_ClientSessId,m_strClientSessionID);
#endif
		glog(Log::L_DEBUG,PLSESSID(NewSessDetect,"OnSessStart()##E_PLAYLIST_STARTED is fired with vstrm sessionId=%d"),
								(int)sessinfo->sessionId);
		m_pStreamSite->PostEventSink(E_PLAYLIST_STARTED,var,_strGuid);
	}

	else
	{
		//ERRLOG(Log::L_ERROR,PLSESSID("void Playlist::OnVstrmSessDetected()##m_pStreamSite==NULL,So can't send sink event"));
	}
	//VstrmSessSink::OnVstrmSessDetected(sessinfo);
}

void Playlist::OnVstrmSessStateChanged(const PVOD_SESSION_INFORMATION sessinfo, const ULONG PreviousState
#if _USE_NEW_SESSION_MON
									   ,ZQ::common::Log& log
#endif
									   )
{	
#pragma message(__MSGLOC__"VstrmSessStateChanged is not needed")
	return;

	ZQ::common::MutexGuard gd(_listOpLocker);

	if(size()<=0)
		return;
	
	const_iterator it= updateItem(sessinfo);
	
	if (listEnd() <= it ||it<=listStart())
		return;
	if(!m_pStreamSite)
	{
		m_pStreamSite=(StreamSmithSite*)StreamSmithSite::getDefaultSite();
	}

	//VstrmSessSink::OnVstrmSessStateChanged(sessinfo, PreviousState);
	if(m_pStreamSite)
	{
#ifdef NEED_EVENTSINK_RAWDATA
		SESSSTATECHANGED	ss;
		ss.pSessInfo=sessinfo;
		ss.PrevState=PreviousState;
		ZQ::common::Variant var(&ss,sizeof(SESSSTATECHANGED));		
#else
		ZQ::common::Variant	var;
		var.set(EventField_SessionId,ZQ::common::Variant((int)sessinfo->sessionId));
		var.set(EventField_PrevState,ZQ::common::Variant((int)PreviousState));
		var.set(EventField_CurrentState,ZQ::common::Variant((int)sessinfo->currentState));
		var.set(EventField_PlaylistGuid,_strGuid);
		var.set(EventField_ClientSessId,m_strClientSessionID);
#endif 
		glog(Log::L_DEBUG,
			PLSESSID(SessStateChanged,"StateChanged()##E_PLAYLIST_STATECHANGED is fired with previousState=%s currentState=%s"),
			VodProviderStateCodeText[(int)PreviousState],VodProviderStateCodeText[(int)sessinfo->currentState]);
		m_pStreamSite->PostEventSink(E_PLAYLIST_STATECHANGED,var,_strGuid);
	}
	else
	{
		//ERRLOG(Log::L_ERROR,PLSESSID("void Playlist::OnVstrmSessStateChanged()## m_pStreamSite==NULL,So can't send event sink"));
	}

//	if (_itCurrent == it && VOD_STATE(DONE) == sessinfo->currentState)
//	{
//		//glog(Log::L_DEBUG,PLSESSID("session state==DONE(%u)"),sessinfo->sessionId);
//		//stepList(it->sessionId);
//	}
}
void Playlist::OnVstrmSessExpired(const ULONG sessionID,ZQ::common::Log& log)
{
	CtrlNum num=INVALID_CTRLNUM;
	ZQ::common::MutexGuard guard(_listOpLocker,__MSGLOC__);
	
	if( size()<=0 || _bCleared )
		return;

	for(iterator it=listBegin();it!=listEnd();it++)
	{
		if(it->sessionId==sessionID)
		{
			num=it->userCtrlNum;
			break;
		}
	}
#if _USE_NEW_SESSION_MON
	UnRegisterSessID(sessionID);
#endif
	{
		if( it != listEnd() &&  it!=_itCurrent &&(_itCurrent!=listEnd() ||_itCurrent!=listStart()))
		{
			//��������vstrm session ����
			glog(Log::L_WARNING,PLSESSID(SessExpired,"OnVstrmSessExpired() ablnormal session expired "
				"with userctrlNum=%d (%u)"),num,sessionID);
			it->sessionId = 0;
		}
	}
	glog(Log::L_DEBUG,PLSESSID(SessExpired,"OnVstrmSessExpired() session expired with userctrlNum=%d (%u)"),num,sessionID);
	stepList(sessionID);
}

void Playlist::stepList(ULONG doneSessionId,bool unloadCurrent)
{
	ZQ::common::MutexGuard guard(_listOpLocker,__MSGLOC__);
	
	if (isCompleted())
		return;
	if(_bCleared)
	{
		glog(Log::L_DEBUG,PLSESSID(stepList,"current playlist resource is cleared,DO not steplist"));
		return;
	}
	
	if( _itCurrent->sessionId != doneSessionId || ( _itCurrent->_sessionDone == true ) )
	{
		glog(Log::L_DEBUG,PLSESSID(stepList,"not current session or current session is already done,current vtrsm Sess[%u] ,notify sess[%u],current session done[%d]"),
							_itCurrent->sessionId,doneSessionId,_itCurrent->_sessionDone	);
		//should I call updateTimer() here ???
		return;
	}

	
	_itCurrent->_sessionDone=true;	
	iterator	itBackup=_itCurrent;
	
	glog(ZQ::common::Log::L_DEBUG, PLSESSID(stepList,"stepList()##current item with  CtrlNum=%u fileName=%s"),
									_itCurrent->userCtrlNum,_itCurrent->objectName.string);

	// current item has been done, move the cursor to next
	iterator itTemp = _itCurrent;
	
	//set session id to 0
	itTemp->sessionId = 0;
	itTemp->stampLaunched = 0;
	itTemp->stampUnload = 0;
	
	if(isReverseStreaming())
	{
		_itCurrent =( _itNext <_itCurrent  && _itNext >listStart() )?_itNext :(_itCurrent-1);
		_itNext = _itCurrent>listStart() ?_itCurrent-1 :listStart();
	}
	else
	{		
		_itCurrent = (_itNext > _itCurrent && _itNext < listEnd()) ? _itNext : (_itCurrent+1);
		_itNext = (_itCurrent < listEnd()) ? (_itCurrent+1) : listEnd();
	}
	if(_itCurrent>listStart()&&_itCurrent<listEnd())
		glog(Log::L_DEBUG,PLSESSID(stepList,"Change iterator current to CtrlNum[%u] filename [%s] session [%u] "),
			_itCurrent->userCtrlNum,_itCurrent->objectName.string,_itCurrent->sessionId);
#ifdef _ICE_INTERFACE_SUPPORT
	_currentItemDist=(int)(_itCurrent-listBegin());
	_mgr.UpdatePlaylistFailStore(this,true,false);
#endif//_ICE_INTERFACE_SUPPORT	
	
	/////
	itBackup->_sessionDone=false;

	try
	{
		OnItemStepped(itTemp,_itCurrent);
//		if(_itCurrent>=listEnd() || _itCurrent<=listStart() )
//		{
//			OnItemDone(itTemp,INVALID_CTRLNUM);
//		}
//		else
//		{
//			OnItemDone(itTemp,_itCurrent->userCtrlNum);
//		}
	}
	catch(...) 
	{
		glog(Log::L_ERROR,PLSESSID(stepList,"unexpect error when call OnItemStepped"));
	}
	

//#pragma message(__MSGLOC__"TODO:���steplist��ʱ��_itNextû�б�load������ô�죿")
	if(!isCompleted() )
	{
#pragma message(__MSGLOC__"���ڲ������������play,������������")

		if (unloadCurrent)
				unloadEx(itTemp);

		if( _itCurrent->sessionId==0)
		{
			glog(ZQ::common::Log::L_INFO,PLSESSID(stepList,"current item %d(%s) is not loaded yet"),
							_itCurrent->userCtrlNum,_itCurrent->objectName.string);
			if(!_bCleared)
			{
				LockPrimeNext lock(_bDontPrimeNext);
				//			play();//play current item
				bool bOK=false;
				while(( _itCurrent->sessionId ==0 ) && (bOK=loadEx(_itCurrent))!=true)
				{			
					if(isReverseStreaming())
					{
						_itCurrent =( _itNext <_itCurrent  && _itNext >listStart() )?_itNext :(_itCurrent-1);
						_itNext = _itCurrent>listStart() ?_itCurrent-1 :listStart();
					}
					else
					{		
						_itCurrent = (_itNext > _itCurrent && _itNext < listEnd()) ? _itNext : (_itCurrent+1);
						_itNext = (_itCurrent < listEnd()) ? (_itCurrent+1) : listEnd();
					}
					if (isCompleted())
					{
						break;
					}
				}
				if (bOK&&!isCompleted())
				{
					launchEx(_itCurrent);
				}
				if(isCompleted())
				{
					try
					{
						_stampDone = GetTickCount();
						OnPlaylistDone();
					}
					catch (...)
					{
					}
					return;
				}
				{
					glog(ZQ::common::Log::L_INFO , 
						PLSESSID(stepList,"step list to item ctrlNum [%u] filename [%s] sessionId [%u] "),
						_itCurrent->userCtrlNum,_itCurrent->objectName.string,_itCurrent->sessionId);
				}
			}
			//updateTimer();//??
			primeNext();
		}
		updateTimer();
	}
	else
	{		
		unloadEx(itTemp);
		try
		{
			_stampDone = GetTickCount();
			OnPlaylistDone();
		}
		catch(...) 
		{
			glog(Log::L_ERROR,PLSESSID(stepList,"unexpect error when call onplaylistdone in function steplist"));
		}
		//		endTimer();
		//		return;		
	}
	printList("Steplist");
	DumpListInfo(true);
}

Playlist::iterator Playlist::findNextCriticalStartItem(timeout_t& timeout)
{
	timeout = TIMEOUT_INF;
	Playlist::iterator it = listEnd();

	// return the regular timer if _itNextCriticalStart is invalid
	{
		ZQ::common::Guard < ZQ::common::Mutex > guard(_listOpLocker,__MSGLOC__);
		if ( isCompleted() || isReverseStreaming() )
		{
			return it;
		}
		
		for (it = _itCurrent+1; it < listEnd() && 0 ==it->criticalStart; it++);
		
		if (it != listEnd())
		{
			time_t now;
			time(&now);
			timeout = (it->criticalStart - now) *1000;
			glog(ZQ::common::Log::L_DEBUG,
				PLSESSID(findNextCriticalStartItem,"find criticalStart Item[%s] [%u] at [%s] ,[%d] from now"),
				it->objectName.string,it->userCtrlNum,printfUTCTime(it->criticalStart),timeout);
		}
	}

	if ( timeout <0 || timeout>=0x8fffffff )//unsigned data
		timeout = 0;

	return it;
}

void Playlist::OnVstrmSessSpeedChanged(const PVOD_SESSION_INFORMATION sessinfo, const VVX_FILE_SPEED PreviousSpeed
#if _USE_NEW_SESSION_MON
									   ,ZQ::common::Log& log
#endif
									   )
{
	int iCurCtrlNum = INVALID_CTRLNUM;
	std::string curRawName= "";
	{
		ZQ::common::MutexGuard gd(_listOpLocker);
		
		if( size()<=0 || _bCleared )
			return;
		
		iterator it=updateItem(sessinfo, true);
		if ( it<=listStart() ||it>listEnd())
			return;
		//��ΪSpeedChaged�¼�����⵽��ʱ�����ܻ��ͺ�������Ҫprimenext��
		glog(Log::L_DEBUG,PLSESSID(SessSpeedChanged,"speedChangeded detected stream session (%d/%d===>>%d/%d) and timeoffset=%u"),
			PreviousSpeed.numerator,PreviousSpeed.denominator,
			sessinfo->currentSpeed.numerator,sessinfo->currentSpeed.denominator,
			sessinfo->currentTimeOffset );
		
		primeNext();
		iCurCtrlNum = _itCurrent->userCtrlNum;
		curRawName = _itCurrent->_rawItemName;		
	}
	
//	// re-calculate the remaining duration
//	updateTimer();
	if(!m_pStreamSite)
	{
		m_pStreamSite=(StreamSmithSite*)StreamSmithSite::getDefaultSite();
	}


	if(m_pStreamSite)
	{
		try
		{
#ifdef NEED_EVENTSINK_RAWDATA
			SINKSPEEDCHANGED	ss;
			ss.pSessionInfo=sessinfo;
			ss.prevFileSpeed=PreviousSpeed;
			ZQ::common::Variant	var(&ss,sizeof(SINKSPEEDCHANGED));
#else
			ZQ::common::Variant	var;
			ZQ::common::Variant	 varSpeed;
			var.set(EventField_SessionId,ZQ::common::Variant((int)sessinfo->sessionId));
				
				varSpeed.clear();
				varSpeed.set(EventField_SpeedNumer,ZQ::common::Variant((int)PreviousSpeed.numerator));
				varSpeed.set(EventField_SpeedDenom,ZQ::common::Variant((int)PreviousSpeed.denominator));
			var.set(EventField_PrevSpeed,varSpeed);
			
				varSpeed.clear();
				varSpeed.set(EventField_SpeedDenom,ZQ::common::Variant((int)sessinfo->currentSpeed.denominator));
				varSpeed.set(EventField_SpeedNumer,ZQ::common::Variant((int)sessinfo->currentSpeed.numerator));
			var.set(EventField_CurrentSpeed,varSpeed);
			var.set(EventField_PlaylistGuid,_strGuid);
			var.set(EventField_ClientSessId,m_strClientSessionID);

			if (!isCompleted()) 
			{				
				var.set(EventField_UserCtrlNum,(int)iCurCtrlNum);
				var.set(EventField_ItemFileName,curRawName);
			}
			else
			{
				var.set(EventField_UserCtrlNum,(int)INVALID_CTRLNUM);
				var.set(EventField_ItemFileName,"");
			}
#endif
			glog(Log::L_DEBUG,PLSESSID(SessSpeedChanged,"SpeedChanged()## E_PLAYLIST_SPEEDCHANGED is fired with changing speed from %d/%d to %d/%d"),
														(int)PreviousSpeed.numerator,(int)PreviousSpeed.denominator,														
														(int)sessinfo->currentSpeed.numerator,
														(int)sessinfo->currentSpeed.denominator);
			m_pStreamSite->PostEventSink(E_PLAYLIST_SPEEDCHANGED,var,_strGuid);
		}
		catch (...)
		{
			ERRLOG(Log::L_ERROR,PLSESSID(SessSpeedChanged,"void Playlist::OnVstrmSessSpeedChanged()##unexpect exception was threw out when call PostEventSink with EVENTSINK_SESS_SPEEDCHANGED"));
		}
	}
	else
	{
		//ERRLOG(Log::L_ERROR,PLSESSID("void Playlist::OnVstrmSessSpeedChanged()## m_pStreamSite==NULL,can't send sink event"));
	}
	//VstrmSessSink::OnVstrmSessSpeedChanged(sessinfo, PreviousSpeed);
}

void Playlist::OnVstrmSessProgress(const PVOD_SESSION_INFORMATION sessinfo, const TIME_OFFSET PreviousTimeOffset
#if _USE_NEW_SESSION_MON
								   ,ZQ::common::Log& log
#endif
								   )
{
	int totalSize = 0;
	int step =0;
	int iCurCtrlNum = 0;
	std::string strRawName ="";
	{
		ZQ::common::MutexGuard gd(_listOpLocker);
		
		if( size()<=0 || _bCleared )
			return;
		
		//glog(Log::L_DEBUG,PLSESSID("Current TimeOffset=(%ld/%ld) byeoffset(%I64d/%I64d)"),PreviousTimeOffset,sessinfo->currentTimeOffset,sessinfo->runningByteOffset,sessinfo->endOfStreamByteOffset);
		if(sessinfo->mpegBitRate==0 || sessinfo->endOfStreamByteOffset==0 )
		{
			glog(Log::L_DEBUG,PLSESSID(SessProgress,"Invalid session information in progress"));
		}
		if(isCompleted())
		{
			return;
		}
		
		bool bSendMessage=false;
		if( _itCurrent->sessionId == sessinfo->sessionId )
		{
#pragma message(__MSGLOC__"TODO:control the frequency of sending message")
			if((_itCurrent->lastProgressEventTimeoffset - sessinfo->currentTimeOffset!=0) &&
				abs( _itCurrent->lastProgressEventTimeoffset - sessinfo->currentTimeOffset ) <= 
				gStreamSmithConfig.lProgressEventSendoutInterval )
			{
				bSendMessage=false;
			}
			else
			{
				_itCurrent->lastProgressEventTimeoffset  = sessinfo->currentTimeOffset;
				bSendMessage=true;
			}
		}
		else
		{
			bSendMessage=false;
		}
		const_iterator it= updateItem(sessinfo);
		
		if(!bSendMessage)
			return;
		
		if (listEnd() <= it || it <= listStart())
			return;
		
		totalSize = size();
		step = (int(listCurrent()-listBegin())) +1;
		iCurCtrlNum = it->userCtrlNum;
		strRawName = it->_rawItemName;
			
	}
	if(!m_pStreamSite)
	{
		m_pStreamSite=(StreamSmithSite*)StreamSmithSite::getDefaultSite();
	}
	if(m_pStreamSite)
	{
		try
		{
#ifdef NEED_EVENTSINK_RAWDATA
			SINKPROGRESS	sp;
			sp.pSessionInfo=sessinfo;
			sp.timeOffset=PreviousTimeOffset;
			ZQ::common::Variant var(&sp,sizeof(SINKPROGRESS));		
#else
			ZQ::common::Variant var;
			var.set(EventField_SessionId,ZQ::common::Variant((int)sessinfo->sessionId));
			var.set(EventField_PrevTimeOffset,ZQ::common::Variant((int)PreviousTimeOffset));
			var.set(EventField_CurrentTimeOffset,ZQ::common::Variant((int)sessinfo->currentTimeOffset));
			char szBuf[128];
			ZeroMemory(szBuf,sizeof(szBuf));
			_guid.toString(szBuf,127);

			var.set(EventField_PlaylistGuid,ZQ::common::Variant(szBuf));
			var.set(EventField_totalStep,ZQ::common::Variant(totalSize));
			var.set(EventField_currentStep,ZQ::common::Variant( step ));
			var.set(EventField_UserCtrlNum,ZQ::common::Variant(iCurCtrlNum));
			var.set(EventField_ItemFileName,ZQ::common::Variant(strRawName ));
			var.set(EventField_ClientSessId,m_strClientSessionID);
			///how to set a longlong var data????
			var.setQuadword(var,EventField_runningByteOffset,sessinfo->runningByteOffset);
			var.setQuadword(var,EventField_TotalbyteOffset,sessinfo->endOfStreamByteOffset);
#endif
			m_pStreamSite->PostEventSink(E_PLAYLIST_INPROGRESS,var,_strGuid);
		}
		catch (...)
		{
			ERRLOG(Log::L_ERROR,PLSESSID(SessProgress,"void Playlist::OnVstrmSessProgress()## Unexpect exception was threw out when call PostEventSink with EVENTSINK_SESS_PROGRESS"));
		}
	}
	else
	{
		//ERRLOG(Log::L_ERROR,PLSESSID("void Playlist::OnVstrmSessProgress()## m_pStreamSite==NULL,can't send sink event"));
	}
//	VstrmSessSink::OnVstrmSessProgress(sessinfo, PreviousTimeOffset);
}

Playlist::const_iterator Playlist::updateItem(const PVOD_SESSION_INFORMATION sessinfo, bool forceUpdateTimer)
{
	if (NULL == sessinfo || size()<=0 || isCompleted() )
	{
		glog(Log::L_DEBUG,PLSESSID(updateItem,"null session info or playlist complete"));
		return listEnd(); // invalid iterator or input
	}
	if ( sessinfo->mpegBitRate==0 || sessinfo->endOfStreamByteOffset==0 ) 
	{
		return listEnd();
	}

	Playlist::iterator it = listEnd();

	if(_itCurrent<listEnd() &&_itCurrent >listStart())
		forceUpdateTimer |= (_itCurrent->bitrate ==0);
	else
		forceUpdateTimer=true;

	if (_itCurrent->sessionId == sessinfo->sessionId)
	{
		it = _itCurrent;
		// about the current item
		it->bitrate = sessinfo->mpegBitRate;
		it->state = sessinfo->currentState;
		it->speed = sessinfo->currentSpeed;
		it->timeOffset = sessinfo->currentTimeOffset;				//  current time offset	(miliseconds)
		it->byteOffset = sessinfo->runningByteOffset;
		it->byteOffsetEOS = sessinfo->endOfStreamByteOffset;			// end of stream offset
		it->stampLoad = it->stampLastUpdate = GetTickCount();
	}
	else if (/*_itNext >_itCurrent && _itNext < listEnd() && */_itNext->sessionId == sessinfo->sessionId)
	{
		// about the next item
		it = _itNext;
		it->bitrate = sessinfo->mpegBitRate;
		it->state = sessinfo->currentState;
		it->speed = sessinfo->currentSpeed;
		it->timeOffset = sessinfo->currentTimeOffset;				//  current time offset	(miliseconds)
		it->byteOffset = sessinfo->runningByteOffset;
		it->byteOffsetEOS = sessinfo->endOfStreamByteOffset;			// end of stream offset
		it->stampLoad = it->stampLastUpdate = GetTickCount();
	}

	if (forceUpdateTimer)
	{
//		glog(Log::L_DEBUG,PLSESSID("force update timer when update item"));
//		updateTimer();
	}

	return it;
}

void Playlist::updateTimer()
{
	glog(Log::L_DEBUG,PLSESSID(updateTimer,"Enter update timer"));
	long to = getSessDurLeft();
	if (TIMEOUT_INF == to)
	{		
		glog(ZQ::common::Log::L_DEBUG, PLSESSID(updateTimer,"time==TIMEOUT_INF return updateTimer(%ums)"), gStreamSmithConfig.lPlaylistTimeout);		
		_isGoodItemInfoData=true;
		SetTimerEx(gStreamSmithConfig.lPlaylistTimeout);
		if(_mgr._timeout==_UI64_MAX)
			_mgr.wakeup();
		return;		
	}
#pragma message(__MSGLOC__"TODO:�ж������ǰ�����һ��Item�����Ҵ���real time��ģʽ����ʱ��1 Min")

	if(_isGoodItemInfoData)
	{
		if(!isCompleted()&&//û�н���
			_bEnableEOT &&
			_itCurrent+1==listEnd()&&_isGoodItemInfoData&&
			!isReverseStreaming())//���ô������һ��Itemn��������PauseTV״̬,���������򲥷�,����EnableEOTΪTRUE
		{
			int forceNormalTime=gStreamSmithConfig.lForceNormalTimeBeforeEnd;
			glog(Log::L_DEBUG,PLSESSID(updateTimer,"This is the last item and in pauseTV mode with configuration time=%dms"),
																	forceNormalTime);
			if(forceNormalTime<MIN_PRELOAD_TIME)
			{
				glog(Log::L_DEBUG,PLSESSID(updateTimer,"configuration time=%dms is too small,set it to %dms"),
															forceNormalTime,MIN_PRELOAD_TIME);
				forceNormalTime=MIN_PRELOAD_TIME;
			}
			to-=forceNormalTime;
			glog(Log::L_DEBUG,PLSESSID(updateTimer,"so set update timer to %dms"),to);
		}
		else if(to>MIN_PRELOAD_TIME)
		{//Ϊʲô��MIN_PRELOAD_TIME*2������Ϊϣ���ڽӽ�preload������ǰ����У׼ʱ��
			to -= MIN_PRELOAD_TIME;
		}
//		else if(to>MIN_PRELOAD_TIME)
//		{
//			to-=MIN_PRELOAD_TIME;
//		}
	}
	if(to<0)
		to=0;

	
	// adjust regular timer if _itNextCriticalStart is valid
	timeout_t t2;
	iterator it = findNextCriticalStartItem(t2);
	if (it < listEnd() && it> listStart() && TIMEOUT_INF != t2 && to > t2)
	{
		glog(ZQ::common::Log::L_DEBUG,PLSESSID(updateTimer,"adjust timer to [%u] because criticalStart"),t2);
		to = t2;
	}
//#pragma message(__MSGLOC__"TODO:������ >=0 ���� >0")
	if (to >= 0)
	{
		glog(ZQ::common::Log::L_DEBUG, PLSESSID(updateTimer,"update current Timer to (%dms)"), to+10);
		SetTimerEx(to+10,_isGoodItemInfoData);
	}

	if (0 ==to || to <= _mgr._timeout ||  (to >0 && _mgr._timeout ==_UI64_MAX))
	{
		glog(Log::L_DEBUG,PLSESSID(updateTimer,"wakeup timer execution and to =%dms mgr._timeout=%I64dms"),to,_mgr._timeout);
		_mgr.wakeup();
	}
	glog(Log::L_DEBUG,PLSESSID(updateTimer,"Leave UpdateTimer with to = [%d]ms"),to+10);
}

void Playlist::OnTimer()
{
	try
	{
		//�ж�һ��Timer�����
		timeout64_t tNow=_GetTickCount64();
		glog(ZQ::common::Log::L_DEBUG,
			PLSESSID(OnTimer,"OnTimer():Enter with time different :%I64d (%I64d/%I64d)"),tNow-_lastUpdateTimer64,tNow,_lastUpdateTimer64);
		endTimer64(); // stop the time first	
	
		if( (isCompleted()  || _currentStatus!=PLAYLIST_PLAY)&& _isGoodItemInfoData )
		{
			if(_currentStatus==PLAYLIST_PAUSE)
			{
				if(_mgr.GetTimeoutOnPause())
				{
					glog(Log::L_DEBUG,PLSESSID(OnTimer,"onTimer() current status=PLAYLIST_PAUSE and TimeoutOnPause is true,kill the playlist"));
					try
					{
						ClearAllResource();
						return;
					}
					catch(...)
					{
					}
				}
				else
				{
					glog(Log::L_DEBUG,PLSESSID(OnTimer,"onTimer() current status==PLAYLIST_PAUSE,and TimeoutOnPause=false,renew the timer"));
					SetTimerEx(gStreamSmithConfig.lPlaylistTimeout);
					return;
				}
			}
			glog(Log::L_DEBUG,PLSESSID(OnTimer,"void Playlist::OnTimer()  kill the playlist and state=%d [SETUP->0 PLAY->100 PAUSE->200 STOP->300] isComplete=%d"),
					_currentStatus,isCompleted());
			try
			{
				glog(Log::L_INFO,PLSESSID(OnTimer,"Clear playlist resource"));
				//delete this;
#ifdef _ICE_INTERFACE_SUPPORT
				ClearAllResource();
#else//_ICE_INTERFACE_SUPPORT
				ClearAllResource();
#endif//_ICE_INTERFACE_SUPPORT
			}
			catch (...)
			{
				glog(Log::L_ERROR,PLSESSID(OnTimer,"Unexpect error when clearAllresource"));
			}
		}
		else 
		{
			if(_bCleared)
			{
				glog(Log::L_DEBUG,PLSESSID(OnTimer,"current playlist resource is cleared,DO not execute on in OnTimer"));
				return;
			}
			if(m_iErrInfoCount>=100)
			{
				ERRLOG(Log::L_CRIT,PLSESSID(OnTimer,"error info count reached 100,playlist destroy automatically!"));
				_strClearReason=_lastError;
				try
				{
					ClearAllResource();
				}
				catch (...){}
				return;
			}
			if(_currentStatus!=PLAYLIST_PLAY)
				return;
			glog(Log::L_DEBUG,PLSESSID(OnTimer,"void Playlist::OnTimer(),May be should load next item"));
			try
			{
				if(_itCurrent+1==listEnd()&&_isGoodItemInfoData)
				{		
#pragma  message(__MSGLOC__"TODO:Ӧ������EOT�Ľ���ʱ��!!")
					if( _bEnableEOT && ( gStreamSmithConfig.lForceNormalTimeBeforeEnd>0 ) )//��Ҫ�����һ��Itemǰ��ĳ��ʱ�̱��normalPlay
					{
						if(!isReverseStreaming())
						{
							glog(Log::L_DEBUG,PLSESSID(OnTimer,"current item with CtrlNum=%u and fileName=%s is the last item and in PauseTV mode, pauseTVTime=%d"),
									_itCurrent->userCtrlNum,_itCurrent->objectName.string,
									gStreamSmithConfig.lForceNormalTimeBeforeEnd);
							if( memcmp ( &_crntSpeed,&SPEED_NORMAL,sizeof(SPEED_NORMAL) )!=0 )
							{								
								glog(Log::L_DEBUG,PLSESSID(OnTimer,"current speed is not normal speed,change stream to normal speed "));
								setSpeedEx(SPEED_NORMAL,true);
								//������ʱ����һ��speedΪnormal��ANNOUNCE���?
							}
							return;
						}						
					}
				}
				timeout_t t;
				iterator it = findNextCriticalStartItem(t);	
				//����Ϊcritical start�ļ�ʱ
				if (it != listEnd() && t ==0)
				{
					glog(Log::L_DEBUG,PLSESSID(OnTimer,"Skip to Item with CtrlNum=%u and fileName=%s"),
							it->userCtrlNum ,it->objectName.string);
					skipToItem(it, true);
				}
				glog(Log::L_DEBUG,PLSESSID(OnTimer,"Prime Next in OnTimer"));
				primeNext();
				
			}
			catch(...)
			{
				ERRLOG(Log::L_ERROR,PLSESSID(OnTimer,"void Playlist::OnTimer()##unexpect exception was threw out when primenext item,maybe playlist is dead^_^"));
			}
		}
	}
	catch (...) 
	{
	}
}

bool Playlist::skipToItem(const_iterator it, bool bPlay)
{	
	{
		ZQ::common::Guard < ZQ::common::Mutex > guard(_listOpLocker,__MSGLOC__);
		glog(Log::L_DEBUG,PLSESSID(skipToItem,"Enter skipToItem"));
		if (isCompleted() || /*it <= _itCurrent ||*/ it >=listEnd() ||it<=listStart())
		{
			_lastErrCode = ERR_PLAYLIST_INVALID_PARA;
			ERRLOG(Log::L_ERROR,PLSESSID(skipToItem,"set playlist state to PLAYLIST_STOP because invalid iterator or playlist complete"));
			FireStateChanged(PLAYLIST_STOP);
			//_currentStatus=PLAYLIST_STOP;
			ERRLOG(Log::L_ERROR,PLSESSID(skipToItem,"skipToItem()##PlayList is complete or invalid iterator "));
			DumpListInfo();
			return false;
		}
	
		// time to start, if there is any still playing, stop it
		if ( _itNext <listEnd() && _itNext>listStart() && 0 != _itNext->sessionId)
			unloadEx(_itNext); // kill the preloaded of _itCurrent
		
//		CtrlNum lastCtrlNum = INVALID_CTRLNUM;
//		std::string	lastFileName = "";
		iterator prevIterator = listEnd();

		if ( _itCurrent->sessionId != 0 )
		{
			prevIterator = _itCurrent;
//			lastCtrlNum = _itCurrent->userCtrlNum;
//			lastFileName = _itCurrent->objectName.string;
			unloadEx(_itCurrent); // kill the session of _itCurrent
		}
		
		if(bPlay)
			glog(Log::L_DEBUG,PLSESSID(skipToItem,"LoadEx item with CtrlNum=%u and fileName=%s in SkiptoItem"),
								it->userCtrlNum,it->objectName.string);

#pragma message(__MSGLOC__"TODO:Load next if failed?")
		{
			iterator itCur = it;
			bool bLoadOK = true;
			bool bComplete = false;
			while ( !bComplete  && !loadEx(itCur,false,0) )
			{		
				if(isReverseStreaming())
				{
					itCur--;
				}
				else
				{
					itCur++;
				}
				_itCurrent=itCur;
				bComplete= !(   itCur <= listEnd() && itCur >= listStart()  );
				bLoadOK=false;
			}
			_itCurrent = itCur;
			//����_itNext
			if(isReverseStreaming())
			{
				_itNext=_itCurrent>listStart() ?_itCurrent-1:listStart();
			}
			else
			{
				_itNext=_itCurrent<listEnd() ?_itCurrent+1:listEnd();
			}	
			if(!bLoadOK)
			{
				_lastErrCode = ERR_PLAYLIST_SERVER_ERROR;
				ERRLOG(Log::L_ERROR,PLSESSID(skipToItem,"set playlist state to PLAYLIST_STOP because No loadable item"));
				FireStateChanged(PLAYLIST_STOP);
				//OnItemDoneDummy(lastCtrlNum,lastFileName, listEnd());
				OnItemStepped(prevIterator,listEnd());
				OnPlaylistDone();
				updateTimer();
				return false;					 
			}
			if(!isCompleted() )
			{
				launchEx(_itCurrent);			
			}
			if(!_b1stPlayStarted)
			{				
				_b1stPlayStarted=true;				
			}
			//fire a Item stepped event
			//OnItemDoneDummy(lastCtrlNum,lastFileName,_itCurrent);
			OnItemStepped(prevIterator,_itCurrent);
			
			//fire a state changed
			FireStateChanged(PLAYLIST_PLAY);
			//_currentStatus=PLAYLIST_PLAY;
		}
	}
	primeNext();
	glog(Log::L_DEBUG,PLSESSID(skipToItem,"Leave SkipToItem"));
	return true;
}

void Playlist::primeNext()
{
	glog(Log::L_DEBUG,PLSESSID(primeNext,"Enter Prime Next"));
	if (isCompleted())
	{
		glog(Log::L_DEBUG,PLSESSID(primeNext,"PlayList is done"));

		if(isReverseStreaming())
		{
			_itNext = listStart();
		}
		else
		{
			_itNext = listEnd();
		}		
		return;
	}
	if(_bDontPrimeNext)
	{
		glog(Log::L_DEBUG,PLSESSID(primeNext,"Dont' primenext because _bDontPrimeNext=true"));
		return;			 
	}
	//////////////////////////////////////////////////////////////////////////	
	{	
		ZQ::common::Guard< ZQ::common::Mutex > guard(_listOpLocker,__MSGLOC__);	

		if(isReverseStreaming())
		{
			if(_itNext >=_itCurrent || _itNext <=listStart())
				_itNext=_itCurrent-1;
		}
		else
		{
			if (_itNext <=_itCurrent || _itNext >=listEnd())
				_itNext = _itCurrent +1;
		}
		
		//////////////////////////////////////////////////////////////////////////		
	
		if(_itNext==listEnd() || _itNext==listStart())
		{
			glog(Log::L_DEBUG,PLSESSID(primeNext,"No more Item for prime next"));
			return;
		}

		if( _itNext->sessionId!=0)
		{
			//Ҳ����˵�����һ��item�Ѿ���Load�������Ժ󣬾Ͳ���Ҫ��updateTimer�ˣ�
			//��steplist��ʱ������һ��UpdateTimer			
			glog(Log::L_DEBUG,PLSESSID(primeNext,"next item with CtrlNum=%u and fileName=%s vstrm sessionId=%u is loaded already,don't primenext"),
					_itNext->userCtrlNum, _itNext->objectName.string,_itNext->sessionId);
			return;
		}
		
		ULONG to = getSessDurLeft();
		if(_isGoodItemInfoData)
		{
			m_iErrInfoCount=0;
			glog(Log::L_DEBUG,PLSESSID(primeNext,"Get target time=%d and current ctrlnum=%d, itnext stream sessionID=%d and threadID=%d in PrimeNext"),
				to,_itCurrent->userCtrlNum, _itNext->sessionId,::GetCurrentThreadId());
			if (to <= MIN_PRELOAD_TIME + 999 && 0 ==_itNext->sessionId) // round up to 1 sec
			{
				glog(ZQ::common::Log::L_DEBUG,
					PLSESSID(primeNext,"pre-loading next item at %dms before sess(%d) ends... And Current userCtrlNum=%d and fileName=%s"), 
					to, _itCurrent->sessionId,_itCurrent->userCtrlNum ,_itCurrent->objectName.string);
				// scan the following items in the list and load the first loadable
				bool bLoadOk = false ;
				if(isReverseStreaming())
				{//reverse direction
					for( ;  _itNext >listStart() && _itNext->sessionId == 0 ; _itNext--)
					{					
						if(loadEx(_itNext))
						{
							glog(Log::L_DEBUG,
								PLSESSID(primeNext,"primeNext() Load Item successfully with userCtrlNum=%u and fileName=%s"),
									_itNext->userCtrlNum,_itNext->objectName.string);
							bLoadOk = true;
							break;
						}
					}
					if(_itNext!=listStart())
					{
						launchEx(_itNext);
					}					
				}
				else
				{//normal direction	
					for (; _itNext < listEnd() && 0 == _itNext->sessionId; _itNext++)
					{
						if (loadEx(_itNext))
						{
							glog(Log::L_DEBUG,
								PLSESSID(primeNext,"primeNext() Load Item successfully with userCtrlNum=%u and fileName=%s"),
								_itNext->userCtrlNum,_itNext->objectName.string);
							bLoadOk =true;
							break;
						}
					}
					
					if (_itNext != listEnd())
					{
						launchEx(_itNext);
					}	
				}
				//���û��һ��Load�ɹ���
				if(!bLoadOk)
				{
					glog(Log::L_ERROR,PLSESSID(primeNext,"Can't load rest item of current playlist"));
				}				
				updateTimer();				
			}	
			else if(_itNext->sessionId==0)
			{
				glog(Log::L_DEBUG,PLSESSID(primeNext,"do not need to load next item,but need to update timer"));
				updateTimer();
				printList("PrimeNext");
			}
			else
			{
				glog(Log::L_DEBUG,PLSESSID(primeNext,"do not need to load next item,and do not need to update timer"));
			}
			//�����һ��item�Ѿ���Load�����Ͳ�ҪupdateTimer��
		}
		else
		{
			m_iErrInfoCount++;
			updateTimer();
		}
	}	
}

long Playlist::getSessDurLeft()
{
	if (isCompleted())// || _itCurrent->sessionId ==0 || _itCurrent->bitrate ==0 )//|| _itCurrent->byteOffsetEOS==0 ||_itCurrent->byteOffset==0)
	{
		_isGoodItemInfoData=true;
		return TIMEOUT_INF; 
	}

	{		
		ESESSION_CHARACTERISTICS esessInfo;
		if(!getVstrmSessInfo(_itCurrent->sessionId,esessInfo))
		{
			glog(Log::L_DEBUG,PLSESSID(getSessDurLeft,"getSessDurLeft()##getVstrmSessInfo fail with session id =%u and current Item CtrlNum=%u and fileName=%s"),
									_itCurrent->sessionId ,_itCurrent->userCtrlNum,_itCurrent->objectName.string);
			_isGoodItemInfoData=false;
			return REUPDATE_TIMER_TIME;
		}			
		//����offset
		SESSION_CHARACTERISTICS* pInfo=&(esessInfo.SessionCharacteristics);
#pragma message(__MSGLOC__"tsoverip ȡ������MuxRate��Ϊ 0 ")		
		if(pInfo->MuxRate<=0)
		{
			glog(Log::L_DEBUG,PLSESSID(getSessDurLeft,"invalid muxRate info which come from vtrsm Sess information"));
			_isGoodItemInfoData=false;
			return REUPDATE_TIMER_TIME;
		}

//		if(pInfo->ByteOffset.QuadPart==0)
//		{
//			glog(Log::L_DEBUG,PLSESSID("invalid byteoffset"));
//			_isGoodItemInfoData=false;
//			return REUPDATE_TIMER_TIME*5;
//		}
		glog(Log::L_DEBUG,PLSESSID(getSessDurLeft,"objectSize=%I64d ByteOffset=%I64d bitrate=%u"),
							pInfo->ObjectSize,pInfo->ByteOffset,pInfo->MuxRate);
		
		int intv=0;

		intv =(int)( ((pInfo->ObjectSize.QuadPart-pInfo->ByteOffset.QuadPart)*8000 )/pInfo->MuxRate);
		
		//intv= (int)  ((LONGLONG)(( pInfo->ObjectSize.QuadPart - pInfo->ByteOffset.QuadPart) *8*1000)) / ((LONGLONG) pInfo->MuxRate );

		_isGoodItemInfoData=true;

		glog(Log::L_DEBUG,PLSESSID(getSessDurLeft,"item with CtrlNum=%u and fileName=%s return with targetTime to=%d"),
							_itCurrent->userCtrlNum,_itCurrent->objectName.string,(intv >0) ? intv : 1);
		
		return (intv >0) ? intv : 1;
	}

	if( (_itCurrent->sessionId==0 || _itCurrent->bitrate ==0 ) && _currentStatus==PLAYLIST_PLAY)
	{
		glog(Log::L_DEBUG,PLSESSID(getSessDurLeft,"(%d)session id=%d bitrate=%d in PLAYLIST_PLAY"),
			_itCurrent->userCtrlNum,_itCurrent->sessionId,_itCurrent->bitrate);
		_isGoodItemInfoData=false;
		return REUPDATE_TIMER_TIME;
	}

	glog(Log::L_DEBUG,PLSESSID(getSessDurLeft,"ULONG Playlist::getSessDurLeft()##(%d) bitrate=%d byteOffsetEOS=%I64d byteOffset=%I64d,timeOffset=%u"),
							_itCurrent->userCtrlNum, _itCurrent->bitrate,
							_itCurrent->byteOffsetEOS,_itCurrent->byteOffset,_itCurrent->timeOffset);
	
	if(isReverseStreaming())
	{
		if(_itCurrent->timeOffset != 0 && _itCurrent->byteOffsetEOS==_itCurrent->byteOffset && _itCurrent->byteOffset!=0)
		{
			glog(Log::L_DEBUG,PLSESSID(getSessDurLeft,"(%d)timeoffset=%u byteEOS=%I64d byteoffset=%I64d in reverse streaming return REUPDATE_TIMER_TIME=%d"),
										_itCurrent->userCtrlNum,_itCurrent->timeOffset ,
										_itCurrent->byteOffsetEOS,_itCurrent->byteOffset,
										REUPDATE_TIMER_TIME);
			_isGoodItemInfoData=false;
			return 	REUPDATE_TIMER_TIME;//TEST
		}
	}
	else
	{		
		if ( (_itCurrent->byteOffsetEOS< _itCurrent->byteOffset))
		{
//			glog(Log::L_DEBUG,PLSESSID("return with MIN_PRELOAD_TIME to=%d"),MIN_PRELOAD_TIME+1);
//			return MIN_PRELOAD_TIME+1;
			glog(Log::L_DEBUG,PLSESSID(getSessDurLeft,"(%d) EOS=%I64d byteOffset=%I64d  in normal streaming"),
				_itCurrent->userCtrlNum, _itCurrent->byteOffsetEOS,_itCurrent->byteOffset);
			_isGoodItemInfoData=false;
			return REUPDATE_TIMER_TIME;
		}
		if(_itCurrent->byteOffsetEOS==_itCurrent->byteOffset && _itCurrent->timeOffset==0 )
		{
			glog(Log::L_DEBUG,PLSESSID(getSessDurLeft,"(%d) EOS=%I64d offset=%I64d timeoffset=%u"),
										_itCurrent->userCtrlNum, _itCurrent->byteOffsetEOS,
										_itCurrent->byteOffset,_itCurrent->timeOffset);
			_isGoodItemInfoData=false;
			return REUPDATE_TIMER_TIME;
		}
	}
	if(/*_itCurrent->byteOffset==0 ||*/ _itCurrent->byteOffsetEOS==0)
	{
		_isGoodItemInfoData=false;
		glog(Log::L_DEBUG,PLSESSID(getSessDurLeft,"no byteoffset or bytreoffsetEOS value return to=%d"),MIN_PRELOAD_TIME+1000);
		return REUPDATE_TIMER_TIME;
	}

	int intv = (int) ( (( _itCurrent->byteOffsetEOS - _itCurrent->byteOffset) *8*1000) / ( _itCurrent->bitrate ));	
//	glog(ZQ::common::Log::L_DEBUG, PLSESSID("session(%d) will be termed in %dms\n", _itCurrent->sessionId, intv);
	glog(Log::L_DEBUG,PLSESSID(getSessDurLeft,"(%d)return with to=%d"),_itCurrent->userCtrlNum,(intv >0) ? intv : 1);
	_isGoodItemInfoData=true;
	return (intv >0) ? intv : 1;
}

bool Playlist::setDestMac(IN char* macAddr)
{
	if(!macAddr||strlen(macAddr)<0)
	{
		ERRLOG(Log::L_ERROR,PLSESSID(setDestMac,"no mac information when entering setDestMac,return with false"));
		return false;
	}
	glog(Log::L_DEBUG,PLSESSID(setDestMac,"enter setDestMac with mac=%s"),macAddr);
	m_strDestinationMac=macAddr;
	if(m_strDestinationMac.size()>0)
	{	
		glog(Log::L_DEBUG,PLSESSID(setDestMac,"Set Mac =%s"),m_strDestinationMac.c_str());
		int		iTemp[6];
		UCHAR	uMac[6];
		if(sscanf(m_strDestinationMac.c_str(),"%d-%d-%d-%d-%d-%d",&iTemp[0],&iTemp[1],&iTemp[2],&iTemp[3],
			&iTemp[4],&iTemp[5])==6)
		{
			for(int i=0;i<6;i++)
			{
				uMac[i]=(UCHAR)iTemp[i]+'0';
			}
			memcpy(_dvbAttrs.macAddr,uMac,sizeof(_dvbAttrs.macAddr));
			//memcpy(_dvbAttrs.macAddr,m_strDestinationMac.c_str(),sizeof(_dvbAttrs.macAddr));
		}
		else if(sscanf(m_strDestinationMac.c_str(),"%x:%x:%x:%x:%x:%x",&iTemp[0],&iTemp[1],&iTemp[2],&iTemp[3],
			&iTemp[4],&iTemp[5])==6)
		{
			for(int i=0;i<6;i++)
			{
				uMac[i]=(UCHAR)iTemp[i];
			}
			memcpy(_dvbAttrs.macAddr,uMac,sizeof(_dvbAttrs.macAddr));
			//memcpy(_dvbAttrs.macAddr,m_strDestinationMac.c_str(),sizeof(_dvbAttrs.macAddr));
		}
		else if(sscanf(m_strDestinationMac.c_str(),"%2X%2X%2X%2X%2X%2X",&iTemp[0],&iTemp[1],&iTemp[2],&iTemp[3],
			&iTemp[4],&iTemp[5])==6)
		{
			for(int i=0;i<6;i++)
			{
				uMac[i]=(UCHAR)iTemp[i];
			}
			memcpy(_dvbAttrs.macAddr,uMac,sizeof(_dvbAttrs.macAddr));
		}
		else
		{
			ERRLOG(ZQ::common::Log::L_ERROR,PLSESSID(setDestMac,"Invalid mac format [%s],should be [d-d-d-d-d-d] or [x:x:x:x:x:x] or [2X2X2X2X2X2X]"),macAddr);
			return false;
		}
	}
	glog(Log::L_DEBUG,PLSESSID(setDestMac,"Leave setDestMac"));
	return true;
	
}
// Playlist attributes
bool Playlist::setDestination(IN char* ipAddr, IN int udpPort)
{
	glog(Log::L_DEBUG,PLSESSID(setDestination,"enter setDestination"));
	char	*pIPAddr;
	if (NULL == ipAddr)
	{
		return false;
	}
	else
	{
		pIPAddr=ipAddr;
	}
	_destIP=ipAddr;
	glog(Log::L_DEBUG,PLSESSID(setDestination,"PlayList::SetDestination=%s port=%d"),pIPAddr,udpPort);
	_dvbAttrs.ipVersion		= IP_VERSION4; //TODO: support IPv6 later
	_dvbAttrs.ipAddr		= inet_addr(pIPAddr);
	_dvbAttrs.udpPort		= udpPort;
	glog(Log::L_DEBUG,PLSESSID(setDestination,"Leave setDestination"));
	return (0 !=_dvbAttrs.ipAddr);
}

bool Playlist::setMuxRate(IN ULONG NowRate, IN ULONG MaxRate, IN ULONG MinRate)
{
	glog(Log::L_DEBUG,PLSESSID(setMuxRate,"Enter setMuxRate with maxRate=%u(kbps)"),MaxRate/1000);
	// Set stream's current bit rate and maximum bitrate.
	_dvbAttrs.MaxMuxRate = MaxRate; //TODO: bitrate
	_dvbAttrs.NowMuxRate = NowRate; //TODO: bitrate
	_dvbAttrs.MinMuxRate = MinRate;
	glog(Log::L_DEBUG,PLSESSID(setMuxRate,"Leave setMuxRate"));
	return true;
}

bool Playlist::setProgramNumber(IN USHORT ProgramNumber)
{
	// Set stream's current bit rate and maximum bitrate.
	glog(Log::L_DEBUG,PLSESSID(setProgramNumber,"enter setProgramNumber with programNumber=%u"),ProgramNumber);
	_dvbAttrs.ProgramNumber = ProgramNumber;
	glog(Log::L_DEBUG,PLSESSID(setProgramNumber,"leave setProgramNumber"));
	return true;
}

bool Playlist::setAuth(IN const char* endpoint)
{
	if (NULL == endpoint)
		return false;

	_authEndpoint = endpoint;
 	return !_authEndpoint.empty();
}
void Playlist::destroy()
{
	glog(Log::L_DEBUG,PLSESSID(destroy,"Enter destroy"));
	try
	{
		//delete this;
		ClearAllResource();
	}
	catch (...)
	{
	}
	glog(Log::L_DEBUG,PLSESSID(destroy,"Leave destroy"));
}
bool Playlist::setSpeed(const float newSpeed)
{
	SPEED_IND	si;
	si.numerator=(int)(newSpeed*1000.0);
	si.denominator=1000;
	glog(Log::L_DEBUG,PLSESSID(setSpeed,"enter setSpeed with new Speed = %d/%d"),si.numerator,si.denominator);
	return setSpeedEx(si);
}
void Playlist::OnItemStepped(const iterator prevItem ,const iterator nextItem,int curTimeOffset)
{
	if(!m_pStreamSite)
	{
		m_pStreamSite=(StreamSmithSite*)StreamSmithSite::getDefaultSite();
	}
	if(m_pStreamSite)
	{
		try
		{
			std::string	strPrevItem,strNextItem;
			int ctrlPrev=INVALID_CTRLNUM,ctrlNext=INVALID_CTRLNUM;
#ifdef NEED_EVENTSINK_RAWDATA
			
#else
			//get current time
			//snprintf
			SYSTEMTIME st_utc;
			GetSystemTime(&st_utc);

			char	szNowUTC[256];
			ZeroMemory(szNowUTC,sizeof(szNowUTC));
			snprintf(szNowUTC, 255,  "%04d%02d%02dT%02d%02d%02d.%03dZ", 
						st_utc.wYear, st_utc.wMonth, st_utc.wDay,
						st_utc.wHour, st_utc.wMinute, st_utc.wSecond, 
						st_utc.wMilliseconds);

			ZQ::common::Variant var;
			var.set(EventField_StampUTC,std::string(szNowUTC));
			var.set(EventField_PlaylistGuid,_strGuid);
			var.set(EventField_ClientSessId,m_strClientSessionID);
			var.set(EventField_CurrentItemTimeOffset,curTimeOffset);
			if (prevItem>=listEnd()||prevItem<=listStart()) 
			{
				var.set(EventField_UserCtrlNum, (int)INVALID_CTRLNUM);
				var.set(EventField_ItemFileName,std::string(""));
			}
			else
			{
				var.set(EventField_UserCtrlNum,ZQ::common::Variant((int)prevItem->userCtrlNum ));
				var.set(EventField_ItemFileName,ZQ::common::Variant(prevItem->_rawItemName) );	
				strPrevItem = prevItem->_rawItemName;
				ctrlPrev = prevItem->userCtrlNum;
			}
			
			if ( nextItem>=listEnd() || nextItem<=listStart() ) 
			{
				var.set(EventField_NextUserCtrlNum,ZQ::common::Variant((int)INVALID_CTRLNUM));
				var.set(EventField_ItemOtherFileName,"");
			}
			else
			{
				var.set(EventField_NextUserCtrlNum,ZQ::common::Variant((int)nextItem->userCtrlNum));
				var.set(EventField_ItemOtherFileName,std::string(nextItem->_rawItemName));
				strNextItem = nextItem->_rawItemName;
				ctrlNext = nextItem->userCtrlNum;
			}			
#endif
			glog(Log::L_DEBUG,PLSESSID(OnItemStepped,"OnItemStepped() E_PLAYLIST_ITEMDONE is fired . ItemStepped from [%d][%s] to [%d][%s]"),
										ctrlPrev,strPrevItem.c_str(),ctrlNext,strNextItem.c_str());			
			m_pStreamSite->PostEventSink(E_PLAYLIST_ITEMDONE,var,_strGuid);
		}
		catch (...) 
		{
			ERRLOG(Log::L_ERROR,PLSESSID(OnItemStepped,"void Playlist::OnItemStepped() Unexpect exception was threw out when call PostEventSink"));
		}
	}
}
void Playlist::OnItemDoneDummy(int PrevCtrlNum ,const std::string& strFileName , iterator nextItemIter)
{
	if(!m_pStreamSite)
	{
		m_pStreamSite=(StreamSmithSite*)StreamSmithSite::getDefaultSite();
	}
	if(m_pStreamSite)
	{
		try
		{
#ifdef NEED_EVENTSINK_RAWDATA
			
#else
			ZQ::common::Variant var;
			var.set(EventField_PlaylistGuid,_strGuid);
			//completedItem->userCtrlNum
			var.set(EventField_UserCtrlNum,ZQ::common::Variant((int)PrevCtrlNum ));
			var.set(EventField_ItemFileName,ZQ::common::Variant(strFileName) );
			var.set(EventField_ClientSessId,m_strClientSessionID);
			if ( nextItemIter>=listEnd() || nextItemIter<=listStart() ) 
			{
				var.set(EventField_NextUserCtrlNum,ZQ::common::Variant((int)INVALID_CTRLNUM));
				var.set(EventField_ItemOtherFileName,"");
			}
			else
			{
				var.set(EventField_NextUserCtrlNum,ZQ::common::Variant((int)nextItemIter->userCtrlNum));
				var.set(EventField_ItemOtherFileName,std::string(nextItemIter->_rawItemName));
			}
			
#endif
			glog(Log::L_DEBUG,PLSESSID(OnItemDone,"OnItemDone()##E_PLAYLIST_ITEMDONE is fired with CtrlNum=%d objectName=%s"),
								PrevCtrlNum,"");
			m_pStreamSite->PostEventSink(E_PLAYLIST_ITEMDONE,var,_strGuid);
		}
		catch (...)
		{
			ERRLOG(Log::L_ERROR,PLSESSID(OnItemDone,"void Playlist::OnItemDone()## Unexpect exception was threw out when call PostEventSink with EVENTSINK_SESS_PROGRESS"));
		}
	}
	else
	{
		//ERRLOG(Log::L_ERROR,PLSESSID("void Playlist::OnVstrmSessProgress()## m_pStreamSite==NULL,can't send sink event"));
	}
}
void Playlist::OnItemDone(iterator completedItem,iterator itNext)
{
	
#if _USE_NEW_SESSION_MON
	//UnRegisterSessID(_lastSessionID);
#endif
//#pragma message(__MSGLOC__"�Ƿ��б�Ҫ�������鵱ǰ��vtrsm session�Ƿ���Ľ���?????")
	completedItem->sessionId=0;
	if(!m_pStreamSite)
	{
		m_pStreamSite=(StreamSmithSite*)StreamSmithSite::getDefaultSite();
	}
	if(m_pStreamSite)
	{
		try
		{
#ifdef NEED_EVENTSINK_RAWDATA
			
#else
			ZQ::common::Variant var;
			var.set(EventField_PlaylistGuid,_strGuid);
			var.set(EventField_UserCtrlNum,ZQ::common::Variant((int)completedItem->userCtrlNum));
			var.set(EventField_ItemFileName,ZQ::common::Variant(completedItem->_rawItemName));
			var.set(EventField_ClientSessId,m_strClientSessionID);
			
			if (itNext>=listEnd()||itNext<=listStart()) 
			{
				var.set(EventField_NextUserCtrlNum,ZQ::common::Variant((int)INVALID_CTRLNUM));
				var.set(EventField_ItemOtherFileName,std::string(""));
			}
			else
			{
				var.set(EventField_NextUserCtrlNum,ZQ::common::Variant((int)itNext->userCtrlNum));
				var.set(EventField_ItemOtherFileName,std::string(itNext->_rawItemName));
			}
			
#endif
			glog(Log::L_DEBUG,PLSESSID(OnItemDone,"OnItemDone()##E_PLAYLIST_ITEMDONE is fired with CtrlNum=%d objectName=%s"),
								completedItem->userCtrlNum,completedItem->objectName.string);
			m_pStreamSite->PostEventSink(E_PLAYLIST_ITEMDONE,var,_strGuid);
		}
		catch (...)
		{
			ERRLOG(Log::L_ERROR,PLSESSID(OnItemDone,"void Playlist::OnItemDone()## Unexpect exception was threw out when call PostEventSink with EVENTSINK_SESS_PROGRESS"));
		}
	}
	else
	{
		//ERRLOG(Log::L_ERROR,PLSESSID("void Playlist::OnVstrmSessProgress()## m_pStreamSite==NULL,can't send sink event"));
	}
}	


bool Playlist::PlayListInitOK()
{
	return _vstrmPortNum<(ULONG)_mgr._cls.getPortCount();
}
void Playlist::OnPlaylistDone()
{
	glog(Log::L_DEBUG,PLSESSID(OnPlaylistDone,"set playlist state to  PLAYLIST_STOP because playlist done"));
	endTimer64();
	ZQ::common::MutexGuard gd(_listOpLocker);
	FireStateChanged(PLAYLIST_STOP);
	//_currentStatus=PLAYLIST_STOP;
	//should send a event sink to plug in to announce that play list is done!	
	if(!m_pStreamSite)
	{
		m_pStreamSite=(StreamSmithSite*)StreamSmithSite::getDefaultSite();
	}
	if(m_pStreamSite)
	{
		try
		{//Post PlayList end event 
			ZQ::common::Variant var;
			var.set(EventField_ClientSessId,m_strClientSessionID);
//			char szBuf[128];
//			ZeroMemory(szBuf,sizeof(szBuf));
//			_guid.toString(szBuf,127);
			var.set(EventField_PlaylistGuid,_strGuid/*ZQ::common::Variant(szBuf)*/);
			if(_itCurrent>=listEnd())
			{
				glog(Log::L_DEBUG,PLSESSID(OnPlaylistDone,"OnPlaylistEnd()##E_PLAYLIST_END,reach the end of stream"));
				m_pStreamSite->PostEventSink(E_PLAYLIST_END,var,_strGuid);
			}
			else
			{
				glog(Log::L_DEBUG,PLSESSID(OnPlaylistDone,"OnPlaylistBegin()##E_PLAYLIST_BEGIN is fired,reach the beginning of the stream"));
				m_pStreamSite->PostEventSink(E_PLAYLIST_BEGIN,var,_strGuid);
			}
		}
		catch (...) 
		{
			ERRLOG(Log::L_ERROR,PLSESSID(OnPlaylistDone,"void Playlist::OnPlaylistDone()##unexpect exception was threw out when call "));
		}
	}

	_isGoodItemInfoData=true;
	SetTimerEx(gStreamSmithConfig.lPlaylistTimeout);
	//�������Ժ�ֱ�Ӹ�λ
	_crntSpeed=Playlist::SPEED_NORMAL;
	_b1stPlayStarted=false;
	_itCurrent=listBegin();
	_isReverseStreaming=false;
	_itNext=_itCurrent+1;
	_bCleared = false;
	
	glog(ZQ::common::Log::L_DEBUG, PLSESSID(OnPlaylistDone,"Playlist::OnPlaylistDone()"));		
}
void Playlist::setUserCtxIdx(const char* SessID)
{
	if(NULL==SessID)
		m_strClientSessionID="";
	else
		m_strClientSessionID=SessID;
	glog(Log::L_DEBUG,"setUserCtxIdx()##Current associate  Session ID =%s",m_strClientSessionID.c_str());
}
bool Playlist::getInfo(IN unsigned long mask,ZQ::common::Variant& var)
{
	glog(Log::L_DEBUG,PLSESSID(getInfo,"Enter getInfo"));
	switch(mask)
	{
	case IPlaylist::infoDVBCRESOURCE:
		{
			glog(Log::L_DEBUG,PLSESSID(getInfo,"Get dvbc resource information"));
			var=_varQamResource;
		}
		break;
	case IPlaylist::infoPLAYNPTPOS:
		{
			if(size()<=0)
			{
				ERRLOG(Log::L_ERROR,PLSESSID(getInfo,"No items in playlist"));
				_lastErrCode=ERR_PLAYLIST_INVALIDSTATE;
				return false;
			}
			if(_itCurrent<=listStart() || _itCurrent>=listEnd())
			{
				ERRLOG(Log::L_ERROR,PLSESSID(getInfo,"current item's stream is down"));
				_lastErrCode=ERR_PLAYLIST_INVALID_PARA;
				return false;
			}
			glog(Log::L_DEBUG,PLSESSID(getInfo,"get playposition info with ctrlNum=%u and filename=%s sessionid=%u "),
				_itCurrent->userCtrlNum,_itCurrent->objectName.string,_itCurrent->sessionId);
			int	cOffset=0,totalOffset=0;
			float scale=0.0f;
			if(_itCurrent->sessionId!=0)
			{
				if(!getStrmSessAttribute(_itCurrent,cOffset,scale,totalOffset))
				{
					ERRLOG(ZQ::common::Log::L_ERROR,PLSESSID(getInfo,"Can't get stream attribute"));
					_lastErrCode=ERR_PLAYLIST_SERVER_ERROR;
					return false;
				}
			}
			else
			{
				cOffset = 0;
				totalOffset=0;
				scale=0.0f;
			}
			int timeTemp =0;
			
			for(iterator itItem=listBegin();itItem!=listCurrent();itItem++)
			{
#pragma message(__MSGLOC__"TODO:Should I query content store before sum the playtime of each item")
				if (itItem->_itemPlaytime < 0) 
				{//the playtime is not available,query from Content Store
					if(!_mgr.m_contentChecker.GetItemAttribute(itItem->_rawItemName,
																	itItem->_itemPlaytime,
																	itItem->_itemBitrate,
																	_strGuid))
					{
						_lastErrCode =  ERR_PLAYLIST_SERVER_ERROR;
						ERRLOG(ZQ::common::Log::L_ERROR,PLSESSID(getInfo,"query item %s userCtrlNum[%u] playtime and bitrate failed"),
															itItem->_rawItemName,itItem->userCtrlNum);
						return false;
					}
					else
					{
						glog(ZQ::common::Log::L_INFO,PLSESSID(getInfo,"query item [%s] userCtrlNum[%u] playtime [%d] and bitrate [%d]"),
														itItem->_rawItemName,itItem->userCtrlNum, itItem->_itemPlaytime,itItem->_itemBitrate);
					}
				}
				timeTemp+=itItem->_itemPlaytime;
			}			
			totalOffset=0;
			for( itItem=listBegin() ; itItem!=listEnd() ; itItem++ )
			{
				if ( itItem == listCurrent() ) 
				{
					itItem->_itemPlaytime = totalOffset;					
				}
				else if ( itItem->_itemPlaytime < 0  || ( size() > 1 && itItem == listEnd()-1 ) ) 
				{//the playtime is not available,query from Content Store
					if(!_mgr.m_contentChecker.GetItemAttribute(itItem->_rawItemName,
																	itItem->_itemPlaytime,
																	itItem->_itemBitrate,
																	_strGuid))
					{
						_lastErrCode =  ERR_PLAYLIST_SERVER_ERROR;
						ERRLOG(ZQ::common::Log::L_ERROR,PLSESSID(getInfo,"query item %s's userCtrlNum[%u] playtime and bitrate failed"),
															itItem->_rawItemName,itItem->userCtrlNum);
						return false;
					}
					else
					{
						glog(ZQ::common::Log::L_INFO,PLSESSID(getInfo,"query item [%s] userCtrlNum[%u] ,get playtime [%d] and bitrate [%d]"),
														itItem->_rawItemName,itItem->userCtrlNum, itItem->_itemPlaytime,itItem->_itemBitrate);
					}
				}
				totalOffset+=itItem->_itemPlaytime;
			}
			char szBuf[24];
			sprintf(szBuf,"%f",scale);
			var.set(EventField_PlaylistGuid,_strGuid);
			var.set(EventField_CurrentTimeOffset,(int)cOffset+timeTemp);			
			var.set(EventField_PlayScale,std::string(szBuf));
			var.set(EventField_TotalTimeOffset,int(totalOffset));			
		}
		break;
	case IPlaylist::infoPLAYPOSITION:
		{
			if(size()<=0)
			{
				ERRLOG(Log::L_ERROR,PLSESSID(getInfo,"No items in playlist"));
				_lastErrCode=ERR_PLAYLIST_INVALIDSTATE;
				return false;
			}
			if(_itCurrent<=listStart() || _itCurrent>=listEnd())
			{
				ERRLOG(Log::L_ERROR,PLSESSID(getInfo,"current item's stream is down"));
				_lastErrCode=ERR_PLAYLIST_INVALID_PARA;
				return false;
			}
			glog(Log::L_DEBUG,PLSESSID(getInfo,"get playposition info with ctrlNum=%u and filename=%s sessionid=%u "),
				_itCurrent->userCtrlNum,_itCurrent->objectName.string,_itCurrent->sessionId);
			int	cOffset=0,totalOffset=0;
			float scale=0.0f;
			if(!getStrmSessAttribute(_itCurrent,cOffset,scale,totalOffset))
			{
				ERRLOG(ZQ::common::Log::L_ERROR,PLSESSID(getInfo,"Can't get stream attribute"));
				_lastErrCode=ERR_PLAYLIST_SERVER_ERROR;
				return false;
			}
			char szBuf[24];
			sprintf(szBuf,"%f",scale);
			var.set(EventField_UserCtrlNum,(int)_itCurrent->userCtrlNum);
			var.set(EventField_CurrentTimeOffset,(int)cOffset);			
			var.set(EventField_PlayScale,std::string(szBuf));
			var.set(EventField_TotalTimeOffset,int(totalOffset));
		}
		break;
	default:
		return false;
		break;
	}
	glog(Log::L_DEBUG,PLSESSID(getInfo,"Leave getInfo"));
	return true;
}
bool Playlist::getStrmSessAttribute(iterator it,int& cTimeOffset,float& scale,int& tTimeOffset)
{
	TIME_OFFSET	tOffset=0;
	LONGLONG	totalOffset=0;
	LONGLONG	curOffset=0;
	ULONG		bitRate=0;
	ESESSION_CHARACTERISTICS esessInfo;
	if(it->sessionId==0)
	{
		glog(Log::L_WARNING,PLSESSID(getStrmSessAttribute,"current item is not streaming"));
	}
	
	//#define _SCAN_RESULT_FOR_OFFSET
#ifdef _SCAN_RESULT_FOR_OFFSET
	else
	{
		glog(Log::L_DEBUG,PLSESSID(getSessAttr,"get vstrm session information from session scan first"));
		if(it->bitrate==0 || it->byteOffsetEOS==0 )
		{
			glog(Log::L_DEBUG,PLSESSID(getSessAttr,"invalid session scan result,turn to getVstrmSessInfo"));
			if(!getVstrmSessInfo(_itCurrent->sessionId,esessInfo))
			{
				ERRLOG(Log::L_ERROR,PLSESSID(getSessAttr,"Can't get vstrm SessInfo from getVstrmSessInfo with sessionId=%u"),
					it->sessionId);
				tOffset=it->timeOffset;
				totalOffset=it->byteOffsetEOS;
				bitRate=it->bitrate;
				curOffset=it->byteOffset;
				glog(Log::L_DEBUG,
					PLSESSID(getSessAttr,"get Iteminfo with CtrlNum=%u fileName=%s vstrmSessId=%u and timeOffset=%u  byteOffset=%I64d byteOffset=%I64d byteOffsetEOS=%I64d bitRate=%u from session scan result"),
					it->userCtrlNum,it->objectName.string,it->sessionId,
					tOffset,it->byteOffset,curOffset,totalOffset,bitRate);
			}
			else
			{
				SESSION_CHARACTERISTICS* pInfo=&(esessInfo.SessionCharacteristics);				
				tOffset=pInfo->PlayoutTimeOffset;
				totalOffset=pInfo->ObjectSize.QuadPart;
				bitRate=pInfo->MuxRate;
				curOffset=pInfo->ByteOffset.QuadPart;
				glog(Log::L_DEBUG,
					PLSESSID(getSessAttr,"get Iteminfo with CtrlNum=%u fileName=%s vstrmSessId=%u and timeOffset=%u  byteOffset=%I64d byteOffsetEOS=%I64d bitRate=%u from getVstrmSessInfo"),
					it->userCtrlNum,it->objectName.string,it->sessionId,
					tOffset,curOffset,totalOffset,bitRate);
				
			}
		}
		else
		{					
			tOffset=it->timeOffset;
			totalOffset=it->byteOffsetEOS;
			bitRate=it->bitrate;
			curOffset=it->byteOffset;
			glog(Log::L_DEBUG,
				PLSESSID(getSessAttr,"get Iteminfo with CtrlNum=%u fileName=%s vstrmSessId=%u and timeOffset=%u  byteOffset=%I64d byteOffsetEOS=%I64d bitRate=%u from session scan result"),
				it->userCtrlNum,it->objectName.string,it->sessionId,
				tOffset,curOffset,totalOffset,bitRate);
			
		}
	}
#else//_SCAN_RESULT_FOR_OFFSET
	glog(Log::L_DEBUG,PLSESSID(getSessAttr,"get vstrm session information from API first"));
	if(!getVstrmSessInfo(it->sessionId,esessInfo))
	{//call getVstrmSessInfo fail
		tOffset=it->timeOffset;
		totalOffset=it->byteOffsetEOS;
		bitRate=it->bitrate;
		curOffset=it->byteOffset;
		glog(Log::L_DEBUG,
			PLSESSID(getSessAttr,"get Iteminfo with CtrlNum=%u fileName=%s vstrmSessId=%u and timeOffset=%u  byteOffset=%I64d byteOffsetEOS=%I64d bitRate=%u from session scan result"),
			it->userCtrlNum,it->objectName.string,it->sessionId,
			tOffset,curOffset,totalOffset,bitRate);
	}		
	else
	{//call getVstrmSessInfo Success
		SESSION_CHARACTERISTICS* pInfo=&(esessInfo.SessionCharacteristics);				
		tOffset=pInfo->PlayoutTimeOffset;
		totalOffset=pInfo->ObjectSize.QuadPart;
		bitRate=pInfo->MuxRate;
		curOffset=pInfo->ByteOffset.QuadPart;
		glog(Log::L_DEBUG,PLSESSID(getSessAttr,"get Iteminfo with CtrlNum=%u fileName=%s vstrmSessId=%u and timeOffset=%u  byteOffset=%I64d byteOffsetEOS=%I64d bitRate=%u from getVstrmSessInfo"),
			it->userCtrlNum,it->objectName.string,it->sessionId,
			tOffset,curOffset,totalOffset,bitRate);
	}
	
#endif//_SCAN_RESULT_FOR_OFFSET
	
	//var.set(EventField_UserCtrlNum,(int)_itCurrent->userCtrlNum);
	//var.set(EventField_CurrentTimeOffset,(int)tOffset);
	cTimeOffset=tOffset;
	/*double scale=0.0f;*/
	if(_crntSpeed.denominator==0)
	{
		scale = 0.0f;
	}
	else
	{
		scale=(float) ( (double)_crntSpeed.numerator/(double)_crntSpeed.denominator );
	}
	
	long totalTime=1;
	if(bitRate==0)
	{
		glog(Log::L_ERROR,PLSESSID(getSessAttr,"invalid bitrate,set byteOffsetEOS to 1"));
		//var.set(EventField_TotalTimeOffset,int(1));
		tTimeOffset=1;
	}
	else
	{
		DWORD	dwStartTime = GetTickCount();
		//get total playtime from content store instead of using vsm_GetFileSize
		if(!_mgr.m_contentChecker.GetItemAttribute(it->_rawItemName,
													it->_itemPlaytime,
													it->_itemBitrate,
													_strGuid))	
		{
			
			tTimeOffset=(long)((totalOffset*1000*8*ABSOLUTEX(_crntSpeed.numerator))/(bitRate*ABSOLUTEX(_crntSpeed.denominator)));
			_lastErrCode =  ERR_PLAYLIST_SERVER_ERROR;
			ERRLOG(ZQ::common::Log::L_ERROR,
				PLSESSID(getSessAttr,"query item ]%s]'s userCtrlNum[%u] playtime and bitrate failed"),
				it->_rawItemName,it->userCtrlNum);
			return false;
		}
		else
		{
			tTimeOffset = it->_itemPlaytime;
			glog(ZQ::common::Log::L_INFO,
				PLSESSID(getSessAttr,"query item [%s] userCtrlNum[%u] ,get playtime [%d] and bitrate [%d]"),
				it->_rawItemName,it->userCtrlNum, it->_itemPlaytime,it->_itemBitrate);
		}
//		LONGLONG llFileSize=0;
//		std::string	strTemp=it->objectName.string;
//		int			iPos=0;
//		if((iPos=strTemp.find_last_of("\\"))==std::string::npos)
//		{			
//		}
//		else
//		{
//			strTemp=strTemp.substr(iPos+1);
//		}
//		
//		if(vsm_GetFileSize(strTemp.c_str(),llFileSize)!=0)
//		{
//			totalTime=(long)((totalOffset*1000*8*ABSOLUTEX(_crntSpeed.numerator))/(bitRate*ABSOLUTEX(_crntSpeed.denominator)));
//			glog(Log::L_INFO,PLSESSID(getSessAttr,"getinfo() can't get file size with file=%s"),strTemp.c_str());					
//		}
//		else
//		{
//			glog(Log::L_DEBUG,PLSESSID(getSessAttr,"getinfo() get filesize=%I64d with filename=%s"),llFileSize,strTemp.c_str());
//			totalTime=(int)(llFileSize*8000/bitRate);
//		}
//		
//		glog(Log::L_DEBUG,PLSESSID(getSessAttr,"getinfo() calculate totalplaytime=%d and current speed=(%d/%d)"),
//			totalTime,_crntSpeed.numerator,_crntSpeed.denominator);
//		//var.set(EventField_TotalTimeOffset,int(totalTime));
//		tTimeOffset = totalTime;
	}
	return true;
}
bool	Playlist::allocateResource(int serviceGroupID, ZQ::common::Variant& varOut,int bandwidth)
{
	glog(Log::L_DEBUG,PLSESSID(allocateResource,"Enter allocResource with serviceGroupID=%d and needBandwidth=%d(kbps)"),
										serviceGroupID,	bandwidth);
	//walk play list item and detect the max bitrate of the specify file
	//iterator	it;
	VvxParser	parser;
	//vsm_ParseVvxFile
	ULONG		maxRate=0;
	

	if(bandwidth== -1)
	{
		glog(Log::L_DEBUG,PLSESSID(allocateResource,"Bandwidth is -1"));
		maxRate=_dvbAttrs.MaxMuxRate/1000;
	}
	else
	{
		
		maxRate=bandwidth;//kbps
	}
	
	glog(Log::L_DEBUG,PLSESSID(allocateResource,"alloc resource with bandwidth=%d(kbps)"),maxRate);
	if(!_ResourceGuid.isNil())
		releaseResource(_ResourceGuid);
	//maxRate/=1024*1024;
	
	std::string		TargetMac;
	std::string		TargetIP;
	int				TargetPort=0;
	int				TargetFrequency=0;
	int				TargetProNum=0;
	int				TargetChannelID=0;
	int				QamMode=0;
	if(!_mgr.GetResource(serviceGroupID,maxRate,TargetIP,TargetPort,TargetMac,
		TargetProNum,TargetFrequency,TargetChannelID,_ResourceGuid,QamMode) || _ResourceGuid.isNil())
	{
		ERRLOG(Log::L_ERROR,PLSESSID(allocateResource,"Can't get resource for service group ID=%d and band width =%d(kbps)"),
								serviceGroupID,maxRate);
		return false;
	}
	else
	{
		glog(Log::L_DEBUG,PLSESSID(allocateResource,"Get resource OK with grpId=%d maxRate=%d return ip=%s port=%d TargetMac=%s proNum=%d frequency=%d chanlId=%d"),
									serviceGroupID,maxRate,TargetIP.c_str(),TargetPort,TargetMac.c_str(),
									TargetProNum,TargetFrequency,TargetChannelID);
	}
	char	szBuf[128];
	ZeroMemory(szBuf,128);
	_ResourceGuid.toString(szBuf,127);
	varOut.set(Playlist::RES_GUID,szBuf);
	varOut.set(Playlist::RES_FRENQENCY,(int)TargetFrequency);
	varOut.set(Playlist::RES_PROGRAMNUMBER,(int)TargetProNum);
	varOut.set(Playlist::RES_DESTIP,TargetIP);
	varOut.set(Playlist::RES_DESTPORT,TargetPort);
	varOut.set(Playlist::RES_DESTMAC,TargetMac);
	varOut.set(Playlist::RES_QAMMODE,QamMode);
	
	varOut.set(Playlist::RES_CHANNEL,TargetChannelID);

	_varQamResource=varOut;

	//OK I get a program number
	//set it to vstrm
	//setProgramNumber(TargetProNum);
	setDestination((char*)TargetIP.c_str(),TargetPort);
	if(!TargetMac.empty())
	{
		setDestMac((char*)TargetMac.c_str());
	}	

	glog(Log::L_DEBUG,PLSESSID(allocateResource,"Leave allocResource"));
	return true;
}
bool	Playlist::releaseResource(ZQ::common::Guid& uid)
{
	 _mgr.FreeResource(uid);
	 uid.create(true);
	 return true;
}

//////////////////////////////////////////////////////////////////////////
#ifdef _ICE_INTERFACE_SUPPORT
void Playlist::copyList(List& l)
{
	ZQ::common::MutexGuard gd(_listOpLocker,__MSGLOC__);
	l=_list;
}
void	Playlist::VstrmSessNotifyWhenStartup(const PVOD_SESSION_INFORMATION sessinfo)
{
	if(sessinfo->sessionId==_vstrmSessioIDForFailOver)
	{
		glog(Log::L_DEBUG,PLSESSID(VstrmSessNotifyWhenStartup,"void	Playlist::VstrmSessNotifyWhenStartup()##Current vStrmSessID was found"));
		_itCurrent=findInternalCtrlNum(_currentItemDist);
		if(_itCurrent!=listEnd())
			_itNext=_itCurrent+1;
		else
			_itNext=listEnd();
		
		m_bCurrentSessionIsONLine=true;
		RegisterSessID(sessinfo->sessionId);
		updateItem(sessinfo,true);
		glog(Log::L_DEBUG,PLSESSID(VstrmSessNotifyWhenStartup,"now playlist state=%d"),_currentStatus);
	}
}
void	Playlist::vstrmSessNotifyOverWhenStartup()
{
	if(!m_bCurrentSessionIsONLine)
	{
		glog(Log::L_DEBUG,PLSESSID(vstrmSessNotifyOverWhenStartup,"void	Playlist::vstrmSessNotifyOverWhenStartup()##No current vstrm SessionID"));
		_itCurrent=findInternalCtrlNum(_currentItemDist);
		if(_itCurrent!=listEnd())
			_itNext=_itCurrent+1;
		else
			_itNext=listEnd();

		if(_itNext!=listEnd())
		{
			skipToItem(_itNext,true);
		}
		else
		{
			glog(Log::L_DEBUG,PLSESSID(vstrmSessNotifyOverWhenStartup,"set playlist state to PLAYLIST_STOP because playlist complete in fail over start up"));
			FireStateChanged(PLAYLIST_STOP);
			//_currentStatus=PLAYLIST_STOP;
			updateTimer();
		}
		glog(Log::L_DEBUG,"now playlist state=%d",_currentStatus);
	}
	else
	{
		//primeNext();
	}
}
#endif//_ICE_INTERFACE_SUPPORT

void Playlist::DisplaySessionAttr(iterator it)
{
	if(it<=listStart() || it>=listEnd())
	{
		glog(Log::L_ERROR,PLSESSID(DisplaySessionAttr,"Invalid iterator"));
		return;
	}
	if(it->sessionId==0)
	{
		glog(Log::L_ERROR,PLSESSID(DisplaySessionAttr,"no sessionID is binded with current iterator"));
		return;			 
	}
	ESESSION_CHARACTERISTICS	buffer;
	ULONG						returnSize;	
	VSTATUS status=VstrmClassGetSessionChars(_mgr.classHandle(),it->sessionId,&buffer,sizeof(buffer),&returnSize);
	if(VSTRM_SUCCESS==status)
	{
		glog(Log::L_DEBUG,PLSESSID(DisplaySessAttr,"display session %d attribute start"),it->sessionId);

		glog(Log::L_DEBUG,PLSESSID(DisplaySessAttr,"session attribute  ObjectSize=%I64d"),buffer.SessionCharacteristics.ObjectSize);
		glog(Log::L_DEBUG,PLSESSID(DisplaySessAttr,"session attribute  byteOffset=%I64d"),buffer.SessionCharacteristics.ByteOffset);
		glog(Log::L_DEBUG,PLSESSID(DisplaySessAttr,"session attribute  TimePlayStarted =%I64d"),buffer.SessionCharacteristics.TimePlayStarted);
		glog(Log::L_DEBUG,PLSESSID(DisplaySessAttr,"session attribute  PlayoutByteOffset=%I64d"),buffer.SessionCharacteristics.PlayoutByteOffset);
		glog(Log::L_DEBUG,PLSESSID(DisplaySessAttr,"session attribute  PlayoutTimeOffset=%u"),buffer.SessionCharacteristics.PlayoutTimeOffset);
		glog(Log::L_DEBUG,PLSESSID(DisplaySessAttr,"session attribute  MuxRate=%u"),buffer.SessionCharacteristics.MuxRate);
		glog(Log::L_DEBUG,PLSESSID(DisplaySessAttr,"display session attribute End"));
	}
	else
	{
		glog(Log::L_ERROR,PLSESSID(DisplaySessAttr,"Can't get current session information"));
	}
}
bool Playlist::getVstrmSessInfo(SESSION_ID sessID, ESESSION_CHARACTERISTICS& valueOut)
{
	ULONG	returnSize;
	VSTATUS status=VstrmClassGetSessionChars(_mgr.classHandle(),sessID, &valueOut,
									sizeof(ESESSION_CHARACTERISTICS),&returnSize);
	if(VSTRM_SUCCESS==status)
	{
		return true;
	}
	else
	{
		char szBuf[1024];
		ZeroMemory(szBuf,sizeof(szBuf));
		glog(Log::L_DEBUG,PLSESSID(getVstrmSessInfo,"get session %u info fail with error description is %s"),
				sessID,_mgr.getErrorText(status,szBuf,sizeof(szBuf)-1));
		return false;
	}
}
const bool Playlist::distance(OUT int* dist, IN CtrlNum to, IN CtrlNum from /*= INVALID_CTRLNUM*/)
{
	return false;	
}
const CtrlNum Playlist::findItem(const CtrlNum userCtrlNum,const CtrlNum from /* = INVALID_CTRLNUM */)
{
	return INVALID_CTRLNUM;
}
const bool Playlist::isRunning()
{
	 return (!isCompleted() && (_itCurrent->sessionId !=0));
}
const bool Playlist::isCompleted()
{
	if( isReverseStreaming())
		return (bool)(_itCurrent <=listStart());
	else
		return (bool)(_itCurrent >=listEnd()); 
}
const CtrlNum Playlist::current()const
{
	if(_itCurrent==_list.end())
		return INVALID_CTRLNUM;
	else
		return _itCurrent->userCtrlNum;
}
void Playlist::SetTimerEx(timeout64_t t,bool bGoodData)
{	
	//renew ticket
	try
	{		
		int		iTime=0;
		//���ڲ�������������һ���̵߳ķ�ʽ��renew ticket
		if(t==FAKE_TIMER_TIMECOUNT)
		{
			iTime=-1;
			glog(Log::L_DEBUG,PLSESSID(SetTimerEx,"delete the ticket"));
		}
		else
		{
			glog(Log::L_DEBUG,PLSESSID(SetTimerEx,"update timer to %I64d"),t);
			setTimer64(t);
			if (0 ==t || t <= _mgr._timeout ||  (t >0 && _mgr._timeout ==_UI64_MAX))
				_mgr.wakeup();
			_lastUpdateTimer64=t+_GetTickCount64();
			iTime=(int)t+60*1000;
			glog(Log::L_DEBUG,PLSESSID(SetTimerEx,"renew the ticket with time =%d"),iTime);
		}
#ifdef _ICE_INTERFACE_SUPPORT

		if(!m_plePxStr.empty())
		{
			RenewTicketRequest* pRequest=new RenewTicketRequest(/*_mgr._cls.getThreadPool()*/_gThreadPool,m_plePxStr,_mgr.m_Adapter,iTime);		
			
			pRequest->start();
		}
#endif//_ICE_INTERFACE_SUPPORT
	}
	catch(...)
	{
		glog(Log::L_ERROR,PLSESSID(SetTimerEx,"unexpect error in settimerEx"));
	}
}
std::vector<ULONG>	Playlist::getItemSet()
{
	std::vector<ULONG>	vecRet;
	List::const_iterator it;
	ZQ::common::MutexGuard gd(_listOpLocker,__MSGLOC__);
	for(it=listBegin();it!=listEnd();it++)
	{
		vecRet.push_back(it->userCtrlNum);
	}
	return vecRet;
}
void Playlist::DumpItemInfo(iterator it)
{
	if(it>=listEnd() || it <=listStart())
		//out of range
		return;
	glog(Log::L_DEBUG,PLSESSID(DumpItemInfo,"Dump item info start"));
	glog(Log::L_DEBUG,PLSESSID(DumpItemInfo,"Item name (%s)\t Item CtrlNum=%d"),
												it->objectName.string,it->userCtrlNum);
	glog(Log::L_DEBUG,PLSESSID(DumpItemInfo,"splice in=%d\t splice out=%d\t forceSpeed=%d"),
												it->spliceIn,it->spliceOut,it->forceNormalSpeed);
	glog(Log::L_DEBUG,PLSESSID(DumpItemInfo,"inTimeOffset=%ld\t outTimeOffset=%ld"),
												it->inTimeOffset,it->outTimeOffset);
	glog(Log::L_DEBUG,PLSESSID(DumpItemInfo,"cirtical start=%ld"),
												it->criticalStart);
	glog(Log::L_DEBUG,PLSESSID(DumpItemInfo,"destination IP=%s\t dest Port=%d"),
												_destIP.c_str(),_dvbAttrs.udpPort);
	glog(Log::L_DEBUG,PLSESSID(DumpItemInfo,"current vtrsm port =%u"),
												_vstrmPortNum);
	glog(Log::L_DEBUG,PLSESSID(DumpItemInfo,"Dump item info End"));
}
void Playlist::DumpIOCTLCONTROLPARMSLONG(IOCTL_CONTROL_PARMS_LONG& para)
{
	glog(Log::L_DEBUG,PLSESSID(DumpIOCTLCONTROLPARMSLONG,"Dump IOCTL_CONTROL_PARMS_LONG start"));
	switch(para.controlCode)
	{
	case VSTRM_GEN_CONTROL_LOAD:
		{
			glog(Log::L_DEBUG,PLSESSID(DumpIOCTLCONTROLPARMSLONG,"dump VSTRM_GEN_CONTROL_LOAD"));
			DumpIOCTLLOADV2PARAMS(para.u.load);
		}
		break;		
			 
	default:
		break;
	}
	glog(Log::L_DEBUG,PLSESSID(DumpIOCTLCONTROLPARMSLONG,"Dump IOCTL_CONTROL_PARMS_LONG end"));
}
void Playlist::DumpIOCTLLOADV2PARAMS(IOCTL_LOADV2_PARAMS& para)
{
	for(int i=0;i<para.loadParamCount;i++)
	{
		if(para.loadParamArray[i].loadCode==LOAD_CODE_DVB_SESSION_ATTRIBUTES)
		{
			_DVB_SESSION_ATTR *pDvb=(_DVB_SESSION_ATTR*)para.loadParamArray[i].loadValueP;
			glog(Log::L_DEBUG,PLSESSID(DumpIOCTLLOADV2PARAMS,"current offset=%I64d EOSOffset=%I64d"),pDvb->CueOutOffset,pDvb->EndOfDataOffset);
		}	
	}	
}
void Playlist::OnItemAbnormal(SESSION_ID sessId)
{
	if(!m_pStreamSite)
	{
		m_pStreamSite=(StreamSmithSite*)StreamSmithSite::getDefaultSite();
	}		
	iterator it=listBegin();
	bool bFound=false;
	CtrlNum num;
	for(;it!=listEnd();it++)
	{
		if(it->sessionId==sessId)
		{
			num=it->userCtrlNum;
			bFound=true;
		}
	}
	if(m_pStreamSite&&bFound)
	{
		try
		{
#ifdef NEED_EVENTSINK_RAWDATA
			
#else
			ZQ::common::Variant	var;				
			var.set(EventField_PlaylistGuid,_strGuid);
			var.set(EventField_ClientSessId,m_strClientSessionID);
			var.set(EventField_UserCtrlNum,(long)num);
#endif
			glog(Log::L_DEBUG,PLSESSID(OnItemAbnormal,"OnItemAbnormal() E_PLAYLIST_SESSEXPIRED is fired with ctrlNum=%d"),num);
			DumpListInfo();
			m_pStreamSite->PostEventSink(E_PLAYLIST_SESSEXPIRED,var,_strGuid);
		}
		catch (...)
		{
			ERRLOG(Log::L_ERROR,PLSESSID(OnItemAbnormal,"void Playlist::ClearAllResource()##unexpect exception was threw out when call PostEventSink with EVENTSINK_SESS_SPEEDCHANGED"));
		}
	}
}
const char* getStateString(IPlaylist::State plState,char* szBuf,int size)
{
	memset(szBuf,0,size);
	switch(plState) 
	{
	case IPlaylist::PLAYLIST_SETUP:
		{
			return "PLAYLIST_SETUP";
		}
		break;
	case IPlaylist::PLAYLIST_PAUSE:
		{
			return	"PLAYLIST_PAUSE";
		}
		break;
	case IPlaylist::PLAYLIST_PLAY:
		{
			return "PLAYLIST_PLAY";
		}
		break;
	case IPlaylist::PLAYLIST_STOP:
		{
			return "PLAYLIST_STOP";
		}
		break;
	default:
		return "";
	}
}
void Playlist::FireStateChanged(IPlaylist::State plState , bool bFire)
{
	if(!m_pStreamSite)
	{
		m_pStreamSite=(StreamSmithSite*)StreamSmithSite::getDefaultSite();
	}
	if(m_pStreamSite)
	{
		try
		{
			
			ZQ::common::Variant	var;				
			var.set(EventField_PlaylistGuid,_strGuid);
			var.set(EventField_ClientSessId,m_strClientSessionID);
			//var.set(EventField_UserCtrlNum,(long)num);
			var.set(EventField_PrevState,(long)_currentStatus);
			var.set(EventField_CurrentState,(long)plState);
			if (!isCompleted()) 
			{				
				var.set(EventField_UserCtrlNum,(int)_itCurrent->userCtrlNum);
				var.set(EventField_ItemFileName,std::string(_itCurrent->_rawItemName));
			}
			else
			{
				var.set(EventField_UserCtrlNum,(int)INVALID_CTRLNUM);
				var.set(EventField_ItemFileName,std::string(""));
			}

			char szBuf1[256];
			char szBuf2[256];
			
//			glog(ZQ::common::Log::L_DEBUG,
//				PLSESSID(FireStateChanged,"playlist StateChanged , Current State is %s and last state is %s"),
//				getStateString(plState,szBuf1,sizeof(szBuf1)),getStateString(_currentStatus,szBuf2,sizeof(szBuf2)));
			if ( bFire && (plState!=_currentStatus) ) 
			{
				glog(ZQ::common::Log::L_DEBUG,
					PLSESSID(FireStateChanged,"E_PLAYLIST_STATECHANGED is fired last state is %s and current state is %s"),
					getStateString(_currentStatus,szBuf2,sizeof(szBuf2)),getStateString(plState,szBuf1,sizeof(szBuf1)));
				m_pStreamSite->PostEventSink(E_PLAYLIST_STATECHANGED,var,_strGuid);
			}
			_currentStatus		= plState;			
		}
		catch (...) 
		{
			ERRLOG(Log::L_ERROR,PLSESSID(FireStateChanged,"void Playlist::FireStateChanged() unexpect exception was threw out when call PostEventSink with E_PLAYLIST_STATECHANGED"));
		}
	}

}

void Playlist::ClearItemsState()
{
	ZQ::common::MutexGuard gd(_listOpLocker);
	iterator it=listBegin();
	for(;it!=listEnd();it++)
	{
		it->bitrate=0;
		it->timeOffset=0;
		it->byteOffset=0;
		it->byteOffset=0;
		it->stampLoad=0;
		it->stampLaunched=0;
		it->stampLastUpdate=0;
		it->stampUnload=0;
		it->_sessionDone=false;
	}
	_bCleared = false;
}
const int Playlist::size()
{
	if(_list.size()<=0)
		return 0;
	else
		return _list.size()-1; 
}
Playlist::iterator Playlist::listBegin() 
{
	/*ZQ::common::MutexGuard gd(_listOpLocker);*/
	iterator it=_list.begin() ; 
	if (_list.size()<=0)
		return it;
	else 
			return ++it;
}
Playlist::iterator Playlist::listEnd() 
{
	return _list.end(); 
}
Playlist::iterator Playlist::listStart() 
{
	return _list.begin(); 
}
Playlist::iterator Playlist::listCurrent() const	
{
	return _itCurrent; 
}
const bool	Playlist::empty()	const
{
	return _list.size()-1<=0; 
}

bool Playlist::skipToItem(const CtrlNum where, bool bPlay )
{
	const_iterator	it=findUserCtrlNum(where);
	return skipToItem(it,bPlay);
}
void Playlist::setPlaylistExProxy(std::string& prxStr)
{
	m_plePxStr=prxStr;
}
void Playlist::DumpDVBATTR(DVB_SESSION_ATTR* pData)
{
	glog(ZQ::common::Log::L_DEBUG,PLSESSID(DumpDVBATTR,"Dump DVB_SESSION_ATTR start"));

	glog(ZQ::common::Log::L_DEBUG,PLSESSID(DumpDVBATTR,"programNumber=%u TransportStreamId=%u MaxMuxRate=%u NowMuxRate=%u MinMuxRate=%u MagicNumber=%u AttrBlockVersion=%d AttrBlockRevision=%d"),
				pData->ProgramNumber,pData->TransportStreamId,pData->MaxMuxRate,pData->NowMuxRate,pData->MinMuxRate,pData->MagicNumber,pData->AttrBlockVersion,pData->AttrBlockRevision);
	glog(ZQ::common::Log::L_DEBUG,PLSESSID(DumpDVBATTR,"ForwardSpeedChangesDisabled=%d AllSpeedChangesDisabled=%d PauseResumeDisabled=%d spliceIn=%d spliceOut=%d failOnBadSpliceIn=%d failOnBadSpliceOut=%d "),
				pData->ForwardSpeedChangesDisabled,pData->AllSpeedChangesDisabled,pData->PauseResumeDisabled,pData->spliceIn,pData->spliceOut,pData->failOnBadSpliceIn,pData->failOnBadSpliceOut );
	glog(ZQ::common::Log::L_DEBUG,PLSESSID(DumpDVBATTR,"forceNormalSpeed=%d ppf=%u udpPort=%u audioudpPort=%u videoStreamId=%d audioStreamId=%d npt=%u"),
				pData->forceNormalSpeed,pData->ppf,pData->udpPort,pData->audioudpPort,pData->videoStreamId,pData->audioStreamId,pData->npt );
//	int a,b,c,d;
	in_addr ia;
	ia.S_un.S_addr= pData->ipAddr;	
	glog(ZQ::common::Log::L_DEBUG,PLSESSID(DumpDVBATTR,"TargetIP=%s mac=%x:%x:%x:%x:%x:%x udpSrcPort=%u" ),
				inet_ntoa(ia),pData->macAddr[0],pData->macAddr[1],pData->macAddr[2],
				pData->macAddr[3],pData->macAddr[4],pData->macAddr[5],
				pData->udpSrcPort);
	glog(ZQ::common::Log::L_DEBUG,PLSESSID(DumpDVBATTR,"Dump DVB_SESSION_ATTR end"));
}
void Playlist::setStreamServPort(unsigned short uPort)
{
	glog(ZQ::common::Log::L_DEBUG,PLSESSID(setStreamServPort,"Set Stream service port to %u"),uPort);
	_dvbAttrs.udpSrcPort = uPort;
}
void Playlist::enableEoT(bool bEnable)
{
	glog(ZQ::common::Log::L_DEBUG,PLSESSID(enableEoT,"Set EOT to [%s]"),bEnable?"Enable":"Disable");
	_bEnableEOT = bEnable;
}
ULONG Playlist::CalculatePastTime()
{
	ZQ::common::MutexGuard gd(_listOpLocker);
	ULONG ulPastTime = 0;
	iterator it  = listBegin();
	for ( ; it != _itCurrent ; it ++ ) 
	{
		if (it->_itemPlaytime < 0 )
		{
			if(!_mgr.m_contentChecker.GetItemAttribute(it->_rawItemName,it->_itemPlaytime,it->_itemBitrate,_strGuid))
			{
				glog(ZQ::common::Log::L_ERROR,
						PLSESSID(CalculatePastTime,"Can't get item playtime for [%s] ctrlNum[%u]"),
						it->_rawItemName,it->userCtrlNum);

				it->_itemPlaytime = -1;
				
			}
			else
			{
				glog(ZQ::common::Log::L_INFO,
					PLSESSID(CalculatePastTime,"Get item playtime [%d] for item[%s] ctrlNum[%u]"),
					it->_itemPlaytime,it->_rawItemName,it->userCtrlNum);
			}
		}
		ulPastTime += it->_itemPlaytime;
		glog(ZQ::common::Log::L_DEBUG,
						PLSESSID(CalculatePastTime,"Calculate item playtime [%u] with item[%s] ctrlNum[%u]"),
						it->_itemPlaytime,it->_rawItemName,it->userCtrlNum);
	}
	glog(ZQ::common::Log::L_INFO,PLSESSID(CalculatePastTime,"Calculated pasttime [%u]"),ulPastTime);
	return ulPastTime;
}

//������Ҫ������????

bool Playlist::exPause(OUT ULONG& timeOffset )
{
	ZQ::common::MutexGuard gd(_listOpLocker);
	if (_currentStatus == IPlaylist::PLAYLIST_PAUSE) 
	{
		glog(ZQ::common::Log::L_INFO,PLSESSID(exPause,"current playlist is in PAUSE state"));
		ESESSION_CHARACTERISTICS esc;
		SESSION_CHARACTERISTICS* pInfo =&esc.SessionCharacteristics;
		if(!getVstrmSessInfo(_itCurrent->sessionId,esc))
		{
			glog(ZQ::common::Log::L_ERROR,PLSESSID(exPause,"Get session [%u] item[%s] ctrlNum[%u] 's timeoffset failed set it to 0"),
				_itCurrent->sessionId,_itCurrent->_rawItemName ,_itCurrent->userCtrlNum);
			timeOffset = CalculatePastTime() + pInfo->PlayoutTimeOffset;			
			return true;
		}
		else
		{
			glog(ZQ::common::Log::L_INFO,PLSESSID(exPause,"Get session [%u] item[%s] ctrlNum[%u] 's timeoffset[%u] speed[%d/%d]"),
				_itCurrent->sessionId,_itCurrent->_rawItemName ,_itCurrent->userCtrlNum,
				pInfo->PlayoutTimeOffset ,pInfo->Speed.numerator,pInfo->Speed.denominator);
		
			timeOffset = CalculatePastTime() + pInfo->PlayoutTimeOffset;			
			return true;
		}		
	}
	else
	{
		if (pause()) 
		{
			timeOffset = CalculatePastTime() + _itCurrent->timeOffset;
			return true;
		}
		else
		{
			return false;			
		}
	}
}

bool Playlist::exPlay( OUT ULONG& timeOffset , OUT float& speed)
{
	ZQ::common::MutexGuard gd(_listOpLocker);
	if (_currentStatus == IPlaylist::PLAYLIST_PLAY) 
	{
		glog(ZQ::common::Log::L_INFO,PLSESSID(exPlay,"current playlist is in PLAY state"));
		ESESSION_CHARACTERISTICS esc;
		SESSION_CHARACTERISTICS* pInfo =&esc.SessionCharacteristics;
		if(!getVstrmSessInfo(_itCurrent->sessionId,esc))
		{
			glog(ZQ::common::Log::L_ERROR,PLSESSID(exPlay,"Get session [%u] item[%s] ctrlNum[%u] 's timeoffset failed set it to 0"),
				_itCurrent->sessionId,_itCurrent->_rawItemName ,_itCurrent->userCtrlNum);
			timeOffset = CalculatePastTime() + pInfo->PlayoutTimeOffset;
			speed = (float)(_crntSpeed.numerator) / (float)(_crntSpeed.denominator);
			return true;
		}
		else
		{
			glog(ZQ::common::Log::L_INFO,PLSESSID(exPlay,"Get session [%u] item[%s] ctrlNum[%u] 's timeoffset[%u] speed[%d/%d]"),
				_itCurrent->sessionId,_itCurrent->_rawItemName ,_itCurrent->userCtrlNum,
				pInfo->PlayoutTimeOffset ,pInfo->Speed.numerator,pInfo->Speed.denominator);
		
			timeOffset = CalculatePastTime() + pInfo->PlayoutTimeOffset;
			speed = (float)(pInfo->Speed.numerator) / (float)(pInfo->Speed.denominator);
			return true;
		}		
	}
	else
	{
		if(play())
		{
			timeOffset = CalculatePastTime() + _itCurrent->timeOffset;
			speed = (float)(_crntSpeed.numerator) / (float)(_crntSpeed.denominator);
			return true;
		}
		else
		{
			return false;
		}
	}
}

bool Playlist::exSetspeed(const float& newSpeed , OUT ULONG& timeOffset  ,OUT float& realSpeed )
{
	ZQ::common::MutexGuard gd(_listOpLocker);
	float curSpeed =  (float)(_crntSpeed.numerator)/(float)(_crntSpeed.denominator);
	if ( curSpeed == newSpeed ) //��֪�����м����ж���ȷ^_^
	{
		if(_currentStatus == IPlaylist::PLAYLIST_SETUP)
			return true;//right ????
		if(isCompleted())
		{
			_lastErrCode=ERR_PLAYLIST_INVALIDSTATE;
			ERRLOG(ZQ::common::Log::L_ERROR,PLSESSID(exSetspeed,"no playable item,can't set speed"));
			return false;				 
		}

		glog(ZQ::common::Log::L_INFO,PLSESSID(exSetspeed,"new Speed is the same as current speed[%d/%d]"),
			_crntSpeed.numerator,_crntSpeed.denominator);
		ESESSION_CHARACTERISTICS esc;
		SESSION_CHARACTERISTICS* pInfo =&esc.SessionCharacteristics;
		if(!getVstrmSessInfo(_itCurrent->sessionId,esc))
		{
			glog(ZQ::common::Log::L_WARNING,
				PLSESSID(exSetspeed,"Get session [%u] item[%s] ctrlNum[%u] 's timeoffset and speed failed "),
				_itCurrent->sessionId,_itCurrent->_rawItemName ,_itCurrent->userCtrlNum);
			timeOffset = CalculatePastTime() + pInfo->PlayoutTimeOffset;
			realSpeed = (float)_crntSpeed.numerator / (float)_crntSpeed.denominator;
			return true;
		}
		else
		{
			glog(ZQ::common::Log::L_INFO,PLSESSID(exSetspeed,"Get session [%u] item[%s] ctrlNum[%u] 's timeoffset[%u] speed[%d/%d]"),
				_itCurrent->sessionId,_itCurrent->_rawItemName ,_itCurrent->userCtrlNum,
				pInfo->PlayoutTimeOffset,pInfo->Speed.numerator,pInfo->Speed.denominator );
			
			timeOffset = CalculatePastTime() + pInfo->PlayoutTimeOffset;
			realSpeed = (float)(pInfo->Speed.numerator) / (float)(pInfo->Speed.denominator);
			return true;
		}	
	}
	else
	{
		if (setSpeed(newSpeed)) 
		{
			timeOffset = CalculatePastTime() + _itCurrent->timeOffset;
			realSpeed = (float)_crntSpeed.numerator / (float)_crntSpeed.denominator;
			return true;
		}
		else
		{
			return false;
		}
	}
}


}}//namespace
